//! Runtime tree kinematics without a generalized mass matrix.
use bevy_math::{DMat3, DVec3};
use mechanic_core::CompiledCreation;
use crate::{BodyPose, SpatialMotion, MachineDynamics, PhysicsError, DynamicsFactor, DynamicsFactorization};

/// Pose-local tree kinematics with linear body storage and ancestor-path rows.
pub struct MachineKinematics<'a> {
    /// Exact reconstructed body poses.
    pub poses: Vec<BodyPose>,
    creation: &'a CompiledCreation,
    centers: Vec<DVec3>,
    relative: Vec<SpatialMotion>,
    size: usize,
}
impl<'a> MachineKinematics<'a> {
    /// Reconstructs a tree without the dense reference capacity limit.
    ///
    /// # Errors
    /// Rejects malformed or non-finite configurations.
    pub fn assemble(creation: &'a CompiledCreation, roots: &[BodyPose], coordinates: &[f64]) -> Result<Self, PhysicsError> {
        let poses = MachineDynamics::reconstruct_poses(creation, roots, coordinates)?;
        let centers = poses.iter().zip(&creation.dynamics.inertias).map(|(p, i)| p.position + p.rotation * i.center.as_dvec3()).collect::<Vec<_>>();
        let mut relative = vec![SpatialMotion::default(); poses.len()];
        for &body in &creation.dynamics.preorder {
            let topology = creation.loop_topology.body_parents[body];
            if topology.is_root { continue; }
            let parent = topology.parent_body as usize;
            let bearing = creation.bearings[creation.dynamics.body_bearings[body].ok_or(PhysicsError::InvalidDynamics)?];
            let (anchor, axis, sign) = if topology.bearing_direction == 0 {
                (bearing.local_anchor_a, bearing.local_axis_a, 1.0)
            } else { (bearing.local_anchor_b, bearing.local_axis_b, -1.0) };
            let axis = poses[parent].rotation * axis.as_dvec3().normalize() * sign;
            relative[body] = if bearing.kind.is_translational() {
                SpatialMotion { linear: axis, angular: DVec3::ZERO }
            } else {
                let anchor = poses[parent].position + poses[parent].rotation * anchor.as_dvec3();
                SpatialMotion { linear: axis.cross(centers[body] - anchor), angular: axis }
            };
        }
        Ok(Self { poses, creation, centers, relative, size: creation.dynamics.elimination_parent.len() })
    }

    /// World COM velocities from one root-before-child pass.
    ///
    /// # Errors
    /// Rejects invalid generalized velocities.
    pub fn body_motions(&self, velocities: &[f64]) -> Result<Vec<SpatialMotion>, PhysicsError> {
        MachineDynamics::reconstruct_motions(self.creation, &self.poses, velocities)
    }

    /// Directional point row using only the body's ancestor path.
    ///
    /// # Errors
    /// Rejects unknown bodies or non-finite geometry.
    pub fn point_row(&self, body: usize, point: DVec3, direction: DVec3) -> Result<Vec<f64>, PhysicsError> {
        self.row(body, point, direction, DVec3::ZERO)
    }

    /// Angular impulse row using only the body's ancestor path.
    ///
    /// # Errors
    /// Rejects unknown bodies or non-finite directions.
    pub fn angular_row(&self, body: usize, direction: DVec3) -> Result<Vec<f64>, PhysicsError> {
        self.row(body, DVec3::ZERO, DVec3::ZERO, direction)
    }

    fn row(&self, mut body: usize, point: DVec3, force: DVec3, torque: DVec3) -> Result<Vec<f64>, PhysicsError> {
        if body >= self.poses.len() || !point.is_finite() || !force.is_finite() || !torque.is_finite() { return Err(PhysicsError::InvalidConstraints); }
        let mut result = vec![0.0; self.size];
        loop {
            let topology = self.creation.loop_topology.body_parents[body];
            let rows = self.creation.dynamics.body_velocities[body].clone();
            if topology.is_root {
                if !rows.is_empty() {
                    result[rows.start..rows.start + 3].copy_from_slice(&force.to_array());
                    result[rows.start + 3..rows.end].copy_from_slice(&(torque + (point - self.poses[body].position).cross(force)).to_array());
                }
                break;
            }
            let motion = self.relative[body];
            result[rows.start] = force.dot(motion.linear + motion.angular.cross(point - self.centers[body])) + torque.dot(motion.angular);
            body = topology.parent_body as usize;
        }
        Ok(result)
    }

    // Project body COM wrenches by accumulating children before their parents.
    fn project(&self, mut wrenches: Vec<SpatialMotion>) -> Vec<f64> {
        let mut result = vec![0.0; self.size];
        for &body in &self.creation.dynamics.postorder {
            let topology = self.creation.loop_topology.body_parents[body];
            let rows = self.creation.dynamics.body_velocities[body].clone();
            let wrench = wrenches[body];
            if topology.is_root {
                if !rows.is_empty() {
                    result[rows.start..rows.start + 3].copy_from_slice(&wrench.linear.to_array());
                    result[rows.start + 3..rows.end].copy_from_slice(&(wrench.angular + (self.centers[body] - self.poses[body].position).cross(wrench.linear)).to_array());
                }
            } else {
                let motion = self.relative[body];
                result[rows.start] = motion.linear.dot(wrench.linear) + motion.angular.dot(wrench.angular);
                let parent = topology.parent_body as usize;
                wrenches[parent].linear += wrench.linear;
                wrenches[parent].angular += wrench.angular + (self.centers[body] - self.centers[parent]).cross(wrench.linear);
            }
        }
        result
    }

    pub(crate) fn gravity_force(&self, creation: &CompiledCreation, gravity: DVec3) -> Result<Vec<f64>, PhysicsError> {
        if !gravity.is_finite() { return Err(PhysicsError::InvalidDynamics); }
        Ok(self.project(creation.compounds.iter().map(|body| SpatialMotion {
            linear: if body.is_static { DVec3::ZERO } else { gravity * f64::from(body.mass_properties.mass) }, angular: DVec3::ZERO
        }).collect()))
    }

    pub(crate) fn inertial_bias(&self, creation: &CompiledCreation, velocities: &[f64]) -> Result<Vec<f64>, PhysicsError> {
        let motions = self.body_motions(velocities)?;
        let bias = self.bias_accelerations(creation, &motions, velocities);
        let wrenches = creation.dynamics.inertias.iter().enumerate().map(|(body, inertia)| {
            if creation.compounds[body].is_static { return SpatialMotion::default(); }
            let rotation = DMat3::from_quat(self.poses[body].rotation);
            let world = rotation * inertia.rotational.as_dmat3() * rotation.transpose();
            let omega = motions[body].angular;
            SpatialMotion { linear: f64::from(inertia.mass) * bias[body].linear, angular: world * bias[body].angular + omega.cross(world * omega) }
        }).collect();
        let result = self.project(wrenches);
        if result.iter().any(|v| !v.is_finite()) { return Err(PhysicsError::InvalidDynamics); }
        Ok(result)
    }

    pub(crate) fn factor(&self, selection: DynamicsFactorization, coordinates: &[f64], diagonal: &[f64]) -> Result<DynamicsFactor, PhysicsError> {
        match selection {
            DynamicsFactorization::DenseReference => MachineDynamics::assemble(self.creation, &self.poses, coordinates)?.factor(diagonal),
            DynamicsFactorization::Articulated => DynamicsFactor::articulated(self.creation, &self.poses, coordinates, diagonal),
        }
    }
    fn bias_accelerations(
        &self,
        creation: &CompiledCreation,
        motions: &[SpatialMotion],
        velocities: &[f64],
    ) -> Vec<SpatialMotion> {
        let mut bias = vec![SpatialMotion::default(); self.poses.len()];
        for &body in &creation.dynamics.preorder {
            let topology = creation.loop_topology.body_parents[body];
            let omega = motions[body].angular;
            if topology.is_root {
                bias[body].linear =
                    omega.cross(omega.cross(self.centers[body] - self.poses[body].position));
            } else {
                let parent = topology.parent_body as usize;
                let column = creation.dynamics.body_velocities[body].start;
                let relative = self.relative[body];
                let speed = velocities[column];
                let linear = relative.linear * speed;
                let angular = relative.angular * speed;
                let omega_parent = motions[parent].angular;
                let arm = self.centers[body] - self.centers[parent];
                bias[body] = SpatialMotion {
                    linear: bias[parent].linear
                        + bias[parent].angular.cross(arm)
                        + omega_parent.cross(omega_parent.cross(arm))
                        + 2.0 * omega_parent.cross(linear)
                        + angular.cross(linear),
                    angular: bias[parent].angular + omega_parent.cross(angular),
                };
            }
        }
        bias
    }

}
