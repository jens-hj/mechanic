use std::f32::consts::{FRAC_PI_2, PI, TAU};

use bevy::{
    input::mouse::AccumulatedMouseMotion,
    prelude::*,
    window::{CursorGrabMode, CursorOptions, PrimaryWindow},
};
#[cfg(test)]
use mechanic_core::ConstructionMaterial;
use mechanic_core::PartId;
#[cfg(test)]
use mechanic_world::TerrainMaterial;

#[cfg(test)]
use crate::hotbar::PlaceableItem;
use crate::{
    EditorState,
    builder::GROUND_HALF_SIZE,
    control_panel::ControlPanelState,
    controls::GameAction,
    creation_menu::CreationMenuState,
    garage,
    hotbar::{
        MainTool, MatterMode, SelectedMaterial, SelectedTerrainMaterial, SelectedTool, WheelChoice,
    },
    pause_menu::PauseMenuState,
    ui::UiInput,
    world::{AppSpace, WorldListState},
};

pub(crate) const EYE_HEIGHT: f32 = 1.65;
pub(crate) const SEATED_EYE_HEIGHT: f32 = 0.475;
pub(crate) const MAX_PULLBACK: f32 = 12.0;
pub(crate) const AVATAR_HIDDEN_PULLBACK: f32 = 0.35;
pub(crate) const AVATAR_OPAQUE_PULLBACK: f32 = 1.0;
pub(crate) const MAX_PITCH: f32 = FRAC_PI_2 - 0.08;
pub(crate) const MIN_PITCH: f32 = -MAX_PITCH;
pub(crate) const WALK_SPEED: f32 = 4.0;
pub(crate) const SPRINT_SPEED: f32 = 7.0;
pub(crate) const MOUSE_SENSITIVITY: f32 = 0.0025;
pub(crate) const PULLBACK_DAMPING_SECONDS: f32 = 0.120;
pub(crate) const MAX_CAMERA_LIFT: f32 = 0.35;
pub(crate) const MATERIAL_WHEEL_RADIUS: f32 = 104.0;
pub(crate) const MATERIAL_WHEEL_DEAD_ZONE: f32 = 24.0;

#[derive(Component, Debug, Default)]
pub(crate) struct MainCamera;

#[derive(Resource, Clone, Copy, Debug, PartialEq)]
pub(crate) struct PlayerState {
    pub(crate) position: Vec3,
    pub(crate) seat: Option<PartId>,
    pub(crate) input_captured: bool,
}

impl Default for PlayerState {
    fn default() -> Self {
        Self {
            position: Vec3::new(0.0, garage::BUILD_MIN_Y, -6.0),
            seat: None,
            input_captured: false,
        }
    }
}

impl PlayerState {
    pub(crate) const fn world_input_active(&self) -> bool {
        self.input_captured
    }

    pub(crate) fn leave_seat_at(&mut self, position: Vec3) {
        self.position = clamp_to_platform(Vec3::new(position.x, 0.0, position.z));
        self.seat = None;
    }

    pub(crate) fn place_outside_bounds(
        &mut self,
        camera: &mut PlayerCamera,
        minimum: Vec3,
        maximum: Vec3,
    ) {
        let centre = (minimum + maximum) * 0.5;
        let positive_z = maximum.z + 2.0;
        let negative_z = minimum.z - 2.0;
        let z = if positive_z <= GROUND_HALF_SIZE {
            positive_z
        } else {
            negative_z.max(-GROUND_HALF_SIZE)
        };
        self.position = clamp_to_platform(Vec3::new(
            centre.x.clamp(-GROUND_HALF_SIZE, GROUND_HALF_SIZE),
            0.0,
            z,
        ));
        let toward = centre - self.position;
        camera.yaw = toward.x.atan2(toward.z);
        camera.pitch = 0.0;
        self.seat = None;
    }
}

#[derive(Component, Clone, Copy, Debug, PartialEq)]
pub(crate) struct PlayerCamera {
    pub(crate) yaw: f32,
    pub(crate) pitch: f32,
    foot_pullback: f32,
    seated_pullback: f32,
    current_pullback: f32,
}

impl Default for PlayerCamera {
    fn default() -> Self {
        Self {
            yaw: 0.0,
            pitch: 0.0,
            foot_pullback: 0.0,
            seated_pullback: 4.0,
            current_pullback: 0.0,
        }
    }
}

impl PlayerCamera {
    pub(crate) fn target_pullback(&self, seated: bool) -> f32 {
        if seated {
            self.seated_pullback
        } else {
            self.foot_pullback
        }
    }

    pub(crate) const fn current_pullback(&self) -> f32 {
        self.current_pullback
    }

    pub(crate) fn set_target_pullback(&mut self, seated: bool, pullback: f32) {
        let value = clamp_pullback(pullback);
        if seated {
            self.seated_pullback = value;
        } else {
            self.foot_pullback = value;
        }
    }

    pub(crate) fn add_scroll(&mut self, seated: bool, scroll: f32) {
        self.set_target_pullback(seated, self.target_pullback(seated) - scroll);
    }

    pub(crate) fn damp_pullback(&mut self, seated: bool, delta_seconds: f32) {
        self.current_pullback = damp(
            self.current_pullback,
            self.target_pullback(seated),
            delta_seconds,
        );
    }

    pub(crate) fn look_rotation(&self) -> Quat {
        free_look_rotation(Quat::IDENTITY, self.yaw, self.pitch)
    }

    pub(crate) fn apply_pullback(&self, eye: Vec3, rotation: Quat) -> Transform {
        camera_transform(eye, rotation, self.current_pullback)
    }
}

#[derive(Resource, Clone, Copy, Debug, Default, PartialEq)]
pub(crate) struct MaterialWheelState {
    pub(crate) open: bool,
    pub(crate) chroma_config: bool,
    pub(crate) selector: Vec2,
    pub(crate) highlighted: Option<WheelChoice>,
    context: Option<WheelChoice>,
    aimed: bool,
}

impl MaterialWheelState {
    pub(crate) fn open(&mut self, current: WheelChoice) {
        self.open = true;
        self.chroma_config = false;
        self.selector = Vec2::ZERO;
        self.highlighted = Some(current);
        self.context = Some(current);
        self.aimed = false;
    }

    /// The choice a Tab release commits. A two-choice selector released
    /// without aiming switches to the other choice, so a tap toggles.
    pub(crate) fn released_choice(&self) -> Option<WheelChoice> {
        if !self.aimed
            && let Some(current) = self.context
            && current.context().count() == 2
        {
            return current
                .context()
                .choices()
                .find(|&choice| choice != current);
        }
        self.highlighted
    }

    pub(crate) fn open_chroma_config(&mut self) {
        self.open = true;
        self.chroma_config = true;
        self.selector = Vec2::ZERO;
        self.highlighted = None;
        self.context = None;
    }

    fn move_selector(&mut self, delta: Vec2) {
        self.selector = (self.selector + delta).clamp_length_max(MATERIAL_WHEEL_RADIUS);
        self.aimed |= self.selector.length() >= MATERIAL_WHEEL_DEAD_ZONE;
        if let Some(choice) = choice_at_selector(self.selector, self.context) {
            self.highlighted = Some(choice);
        }
    }

    pub(crate) fn close(&mut self) {
        *self = Self::default();
    }
}

pub(crate) fn seated_view_rotation(seat_rotation: Quat, yaw: f32, pitch: f32) -> Quat {
    free_look_rotation(seat_rotation, yaw, pitch)
}

pub(crate) fn free_look_rotation(base: Quat, yaw: f32, pitch: f32) -> Quat {
    base * Quat::from_rotation_y(PI) * Quat::from_rotation_y(yaw) * Quat::from_rotation_x(pitch)
}

pub(crate) const fn clamp_pullback(value: f32) -> f32 {
    value.clamp(0.0, MAX_PULLBACK)
}

#[cfg(test)]
pub(crate) fn normalized_scroll(delta: Vec2, unit: bevy::input::mouse::MouseScrollUnit) -> f32 {
    delta.y
        * match unit {
            bevy::input::mouse::MouseScrollUnit::Line => 1.0,
            bevy::input::mouse::MouseScrollUnit::Pixel => 0.02,
        }
}

pub(crate) fn damp(current: f32, target: f32, delta_seconds: f32) -> f32 {
    let blend = 1.0 - (-delta_seconds.max(0.0) / PULLBACK_DAMPING_SECONDS).exp();
    current + (target - current) * blend
}

pub(crate) fn camera_transform(eye: Vec3, rotation: Quat, pullback: f32) -> Transform {
    let pullback = clamp_pullback(pullback);
    let lift = MAX_CAMERA_LIFT * pullback / MAX_PULLBACK;
    let forward = rotation * -Vec3::Z;
    Transform::from_translation(eye - forward * pullback + Vec3::Y * lift).with_rotation(rotation)
}

pub(crate) fn viewport_center(size: Vec2) -> Vec2 {
    size * 0.5
}

pub(crate) fn ray_drag_started(start: Vec3, current: Vec3) -> bool {
    start.angle_between(current) > crate::DRAG_DEAD_ZONE_RADIANS
}

pub(crate) fn seat_entry_allowed(hit_distance: f32, is_seat: bool) -> bool {
    is_seat && hit_distance <= 3.0
}

pub(crate) fn movement_axis(actions: &ButtonInput<GameAction>) -> Vec2 {
    let mut axis = Vec2::ZERO;
    if actions.pressed(GameAction::MoveLeft) {
        axis.x -= 1.0;
    }
    if actions.pressed(GameAction::MoveRight) {
        axis.x += 1.0;
    }
    if actions.pressed(GameAction::MoveForward) {
        axis.y += 1.0;
    }
    if actions.pressed(GameAction::MoveBackward) {
        axis.y -= 1.0;
    }
    axis.normalize_or_zero()
}

#[cfg(test)]
pub(crate) fn camera_relative_movement(axis: Vec2, yaw: f32) -> Vec3 {
    let forward = Vec3::new(yaw.sin(), 0.0, yaw.cos());
    let right = Vec3::new(-forward.z, 0.0, forward.x);
    (right * axis.x + forward * axis.y).normalize_or_zero()
}

#[cfg(test)]
pub(crate) fn walking_step(axis: Vec2, yaw: f32, delta_seconds: f32, sprinting: bool) -> Vec3 {
    let speed = if sprinting { SPRINT_SPEED } else { WALK_SPEED };
    camera_relative_movement(axis, yaw) * speed * delta_seconds
}

pub(crate) fn flight_step(
    axis: Vec2,
    look_rotation: Quat,
    vertical: f32,
    delta_seconds: f32,
    sprinting: bool,
) -> Vec3 {
    let speed = if sprinting { SPRINT_SPEED } else { WALK_SPEED };
    let forward = look_rotation * Vec3::NEG_Z;
    let right = look_rotation * Vec3::X;
    (right * axis.x + forward * axis.y + Vec3::Y * vertical).normalize_or_zero()
        * speed
        * delta_seconds
}

pub(crate) fn clamp_to_garage(position: Vec3) -> Vec3 {
    let half = garage::SIDE_LENGTH * 0.5;
    Vec3::new(
        position.x.clamp(-half, half),
        position.y.clamp(0.0, garage::HEIGHT - EYE_HEIGHT),
        position.z.clamp(-half, half),
    )
}

pub(crate) fn clamp_to_platform(position: Vec3) -> Vec3 {
    Vec3::new(
        position.x.clamp(-GROUND_HALF_SIZE, GROUND_HALF_SIZE),
        0.0,
        position.z.clamp(-GROUND_HALF_SIZE, GROUND_HALF_SIZE),
    )
}

pub(crate) fn avatar_alpha(pullback: f32) -> f32 {
    ((pullback - AVATAR_HIDDEN_PULLBACK) / (AVATAR_OPAQUE_PULLBACK - AVATAR_HIDDEN_PULLBACK))
        .clamp(0.0, 1.0)
}

#[allow(
    clippy::cast_possible_truncation,
    clippy::cast_precision_loss,
    clippy::cast_sign_loss
)]
pub(crate) fn choice_at_selector(
    selector: Vec2,
    current: Option<WheelChoice>,
) -> Option<WheelChoice> {
    if selector.length() < MATERIAL_WHEEL_DEAD_ZONE {
        return None;
    }
    let context = current?.context();
    let count = context.count();
    let angle = selector.x.atan2(-selector.y).rem_euclid(TAU);
    let sector = TAU / count as f32;
    let centred = (angle + sector * 0.5).rem_euclid(TAU);
    let index = (centred / sector).floor() as usize % count;
    context.choice(index)
}

pub(crate) const fn material_wheel_may_open(
    simulating: bool,
    interactive_panel: bool,
    world_drag: bool,
) -> bool {
    !simulating && !interactive_panel && !world_drag
}

pub(crate) const fn committed_choice(
    tab_released: bool,
    highlighted: Option<WheelChoice>,
) -> Option<WheelChoice> {
    if tab_released { highlighted } else { None }
}

const fn chroma_config_should_close(
    selector_pressed: bool,
    another_panel_open: bool,
    chroma_active: bool,
) -> bool {
    selector_pressed || another_panel_open || !chroma_active
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn update_material_wheel(
    actions: Res<ButtonInput<GameAction>>,
    motion: Res<AccumulatedMouseMotion>,
    menu: Res<CreationMenuState>,
    panel: Res<ControlPanelState>,
    pause: Res<PauseMenuState>,
    overlay: Res<UiInput>,
    state: Res<EditorState>,
    mut wheel: ResMut<MaterialWheelState>,
    mut material: ResMut<SelectedMaterial>,
    mut terrain_material: ResMut<SelectedTerrainMaterial>,
    mut selection: ResMut<SelectedTool>,
    mut shape_mode: ResMut<crate::shape_tool::ShapeEditMode>,
) {
    if wheel.open {
        let chroma_active = selection.tool == Some(MainTool::MatterManipulator)
            && selection.matter_mode == MatterMode::Chroma;
        if wheel.chroma_config {
            if chroma_config_should_close(
                actions.just_pressed(GameAction::MaterialWheel),
                menu.is_open() || panel.is_open() || pause.blocks_world_input(),
                chroma_active,
            ) {
                wheel.close();
            }
            return;
        }
        wheel.move_selector(motion.delta);
        if actions.just_released(GameAction::MaterialWheel)
            || menu.is_open()
            || panel.is_open()
            || pause.blocks_world_input()
        {
            if let Some(highlighted) = committed_choice(
                actions.just_released(GameAction::MaterialWheel),
                wheel.released_choice(),
            ) {
                match highlighted {
                    WheelChoice::ConstructionMaterial(next) => material.0 = next,
                    WheelChoice::Item(next) => selection.select_item(next),
                    WheelChoice::TerrainMaterial(next) => terrain_material.0 = next,
                    WheelChoice::ShapeMode(next) => *shape_mode = next,
                    WheelChoice::WeldMode(next) => selection.weld_mode = next,
                }
            }
            wheel.close();
        }
        return;
    }
    let interactive_panel =
        menu.is_open() || panel.is_open() || overlay.blocks_pointer() || overlay.blocks_keyboard();
    let current = match (selection.tool, selection.matter_mode) {
        (Some(MainTool::MatterManipulator), MatterMode::Block | MatterMode::Cylinder) => {
            Some(Some(WheelChoice::ConstructionMaterial(material.0)))
        }
        (Some(MainTool::MatterManipulator), MatterMode::Item) => {
            Some(Some(WheelChoice::Item(selection.item)))
        }
        (Some(MainTool::MatterManipulator), MatterMode::Terrain) => {
            Some(Some(WheelChoice::TerrainMaterial(terrain_material.0)))
        }
        (Some(MainTool::MatterManipulator), MatterMode::Chroma) => Some(None),
        (Some(MainTool::MatterManipulator), MatterMode::Manipulate) => {
            Some(Some(WheelChoice::ShapeMode(*shape_mode)))
        }
        (Some(MainTool::Welder), _) => Some(Some(WheelChoice::WeldMode(selection.weld_mode))),
        _ => None,
    };
    if actions.just_pressed(GameAction::MaterialWheel)
        && material_wheel_may_open(
            false,
            interactive_panel,
            state.contextual_selector_blocked(),
        )
        && let Some(current) = current
    {
        if let Some(choice) = current {
            wheel.open(choice);
        } else {
            wheel.open_chroma_config();
        }
    }
}

#[allow(clippy::too_many_arguments)]
pub(crate) fn update_player_camera(
    time: Res<Time>,
    actions: Res<ButtonInput<GameAction>>,
    motion: Res<AccumulatedMouseMotion>,
    menu: Res<CreationMenuState>,
    panel: Res<ControlPanelState>,
    pause: Res<PauseMenuState>,
    worlds: Res<WorldListState>,
    wheel: Res<MaterialWheelState>,
    editor: Res<EditorState>,
    selection: Res<SelectedTool>,
    space: Res<State<AppSpace>>,
    mut player: ResMut<PlayerState>,
    mut cursor: Single<&mut CursorOptions, With<PrimaryWindow>>,
    mut camera: Single<(&mut PlayerCamera, &mut Transform, &mut GlobalTransform), With<MainCamera>>,
) {
    let panel_open = crate::automation::enabled()
        || wheel.chroma_config
        || player_controls_blocked([
            menu.is_open(),
            panel.is_open(),
            pause.is_open(),
            worlds.is_open(),
        ]);
    update_cursor_capture(panel_open, &mut cursor);
    player.input_captured = !panel_open && !pause.blocks_world_input();

    let (view, transform, global) = &mut *camera;
    let world_active = player.input_captured && !wheel.open;
    if world_active
        && editor.suspension.controls.gesture.is_none()
        && !(editor.suspension.controls.aim.is_some() && actions.just_pressed(GameAction::Primary))
    {
        view.yaw -= motion.delta.x * MOUSE_SENSITIVITY;
        view.pitch = (view.pitch - motion.delta.y * MOUSE_SENSITIVITY).clamp(MIN_PITCH, MAX_PITCH);
        let terrain_mode = selection.tool == Some(MainTool::MatterManipulator)
            && selection.matter_mode == MatterMode::Terrain;
        let zoom = contextual_zoom_delta(
            actions.just_pressed(GameAction::ZoomIn),
            actions.just_pressed(GameAction::ZoomOut),
            editor.pipe_bend_active()
                || terrain_mode
                || editor.smart_snap.range_adjusted_this_frame
                || editor.free_placement.range_adjusted_this_frame,
        );
        view.add_scroll(player.seat.is_some(), zoom);
    }
    view.damp_pullback(player.seat.is_some(), time.delta_secs());
    if player.seat.is_none() {
        if world_active && space.get().uses_garage_flight() {
            let vertical = f32::from(actions.pressed(GameAction::Jump))
                - f32::from(actions.pressed(GameAction::Descend));
            player.position += flight_step(
                movement_axis(&actions),
                view.look_rotation(),
                vertical,
                time.delta_secs(),
                actions.pressed(GameAction::Sprint),
            );
            player.position = clamp_to_garage(player.position);
        }
        **transform =
            view.apply_pullback(player.position + Vec3::Y * EYE_HEIGHT, view.look_rotation());
        **global = GlobalTransform::from(**transform);
    }
}

fn contextual_zoom_delta(zoom_in: bool, zoom_out: bool, wheel_consumed: bool) -> f32 {
    if wheel_consumed {
        0.0
    } else {
        f32::from(zoom_in) - f32::from(zoom_out)
    }
}

fn player_controls_blocked(open_panels: [bool; 4]) -> bool {
    open_panels.into_iter().any(core::convert::identity)
}

fn update_cursor_capture(
    panel_open: bool,
    cursor: &mut Single<&mut CursorOptions, With<PrimaryWindow>>,
) {
    let grab_mode = if panel_open {
        CursorGrabMode::None
    } else {
        CursorGrabMode::Locked
    };
    // Changed<CursorOptions> makes winit call the OS even for identical values.
    // Read the actual component so external releases are still recaptured.
    if cursor.grab_mode != grab_mode {
        cursor.grab_mode = grab_mode;
    }
    if cursor.visible != panel_open {
        cursor.visible = panel_open;
    }
}

#[cfg(test)]
#[allow(clippy::float_cmp)]
mod tests {
    use super::*;
    use bevy::input::mouse::MouseScrollUnit;

    #[test]
    fn cursor_options_change_only_when_capture_state_changes() {
        #[derive(Resource, Default)]
        struct PanelOpen(bool);
        let mut app = App::new();
        app.init_resource::<PanelOpen>().add_systems(
            Update,
            |panel: Res<PanelOpen>, mut cursor: Single<&mut CursorOptions, With<PrimaryWindow>>| {
                update_cursor_capture(panel.0, &mut cursor);
            },
        );
        let window = app
            .world_mut()
            .spawn((PrimaryWindow, CursorOptions::default()))
            .id();
        app.update();
        let cursor = app.world().get::<CursorOptions>(window).unwrap();
        assert_eq!(cursor.grab_mode, CursorGrabMode::Locked);
        assert!(!cursor.visible);
        let changed = app
            .world()
            .entity(window)
            .get_ref::<CursorOptions>()
            .unwrap()
            .last_changed();
        app.update();
        assert_eq!(
            app.world()
                .entity(window)
                .get_ref::<CursorOptions>()
                .unwrap()
                .last_changed(),
            changed
        );
        app.world_mut().resource_mut::<PanelOpen>().0 = true;
        app.update();
        let cursor = app.world().get::<CursorOptions>(window).unwrap();
        assert_eq!(cursor.grab_mode, CursorGrabMode::None);
        assert!(cursor.visible);
        app.world_mut().resource_mut::<PanelOpen>().0 = false;
        app.update();
        assert_eq!(
            app.world().get::<CursorOptions>(window).unwrap().grab_mode,
            CursorGrabMode::Locked
        );
        // External release must be noticed even if the desired state is unchanged.
        app.world_mut()
            .get_mut::<CursorOptions>(window)
            .unwrap()
            .grab_mode = CursorGrabMode::None;
        app.update();
        assert_eq!(
            app.world().get::<CursorOptions>(window).unwrap().grab_mode,
            CursorGrabMode::Locked
        );
    }

    #[test]
    fn contextual_wheel_adjustments_suppress_zoom_only_when_consumed() {
        assert_eq!(contextual_zoom_delta(true, false, false), 1.0);
        assert_eq!(contextual_zoom_delta(false, true, false), -1.0);
        assert_eq!(contextual_zoom_delta(true, false, true), 0.0);
    }

    #[test]
    fn pullback_is_clamped_and_zoom_memories_are_independent() {
        let mut camera = PlayerCamera::default();
        camera.set_target_pullback(false, 99.0);
        camera.set_target_pullback(true, -2.0);
        assert_eq!(camera.target_pullback(false), MAX_PULLBACK);
        assert_eq!(camera.target_pullback(true), 0.0);
    }

    #[test]
    fn world_picker_releases_character_controls() {
        assert!(player_controls_blocked([false, false, false, true]));
        assert!(!player_controls_blocked([false; 4]));
    }

    #[test]
    fn line_and_pixel_scroll_are_normalized() {
        assert_eq!(
            normalized_scroll(Vec2::new(0.0, 2.0), MouseScrollUnit::Line),
            2.0
        );
        assert_eq!(
            normalized_scroll(Vec2::new(0.0, 100.0), MouseScrollUnit::Pixel),
            2.0
        );
    }

    #[test]
    fn damping_is_frame_rate_independent() {
        let one_step = damp(0.0, 10.0, 0.120);
        let two_steps = damp(damp(0.0, 10.0, 0.060), 10.0, 0.060);
        assert!((one_step - two_steps).abs() < 1.0e-5);
    }

    #[test]
    fn zero_pullback_preserves_seated_first_person_transform() {
        let rotation = seated_view_rotation(Quat::from_rotation_y(0.4), 0.2, -0.1);
        let eye = Vec3::new(2.0, 3.0, 4.0);
        let transform = camera_transform(eye, rotation, 0.0);
        assert_eq!(transform.translation, eye);
        assert_eq!(transform.rotation, rotation);
    }

    #[test]
    fn diagonal_camera_relative_movement_has_unit_speed() {
        let movement = camera_relative_movement(Vec2::ONE.normalize(), 0.0);
        assert!((movement.length() - 1.0).abs() < 1.0e-6);
    }

    #[test]
    fn a_and_d_strafe_to_the_cameras_left_and_right() {
        let camera = PlayerCamera {
            yaw: 0.7,
            ..default()
        };
        let camera_right = camera.look_rotation() * Vec3::X;
        let mut keyboard = ButtonInput::default();

        keyboard.press(GameAction::MoveRight);
        let right = camera_relative_movement(movement_axis(&keyboard), camera.yaw);
        assert!(right.abs_diff_eq(camera_right, 1.0e-6));

        keyboard.release(GameAction::MoveRight);
        keyboard.press(GameAction::MoveLeft);
        let left = camera_relative_movement(movement_axis(&keyboard), camera.yaw);
        assert!(left.abs_diff_eq(-camera_right, 1.0e-6));
    }

    #[test]
    fn walking_step_remains_available_to_world_gestures() {
        let step = walking_step(Vec2::Y, 0.0, 0.25, false);
        assert!((step - Vec3::Z).length() < 1.0e-6);
    }

    #[test]
    fn sprinting_uses_the_faster_movement_speed() {
        let walking = walking_step(Vec2::Y, 0.0, 1.0, false);
        let sprinting = walking_step(Vec2::Y, 0.0, 1.0, true);
        assert!((walking.length() - WALK_SPEED).abs() < 1.0e-6);
        assert!((sprinting.length() - SPRINT_SPEED).abs() < 1.0e-6);
    }

    #[test]
    fn platform_clamp_keeps_feet_on_ground() {
        assert_eq!(
            clamp_to_platform(Vec3::new(30.0, 8.0, -40.0)),
            Vec3::new(GROUND_HALF_SIZE, 0.0, -GROUND_HALF_SIZE)
        );
    }

    #[test]
    fn player_lifecycle_starts_standing_and_exit_returns_to_safe_ground() {
        let mut player = PlayerState::default();
        assert!(player.seat.is_none());
        assert_eq!(player.position.y, 5.0);
        player.leave_seat_at(Vec3::new(30.0, 8.0, -40.0));
        assert_eq!(
            player.position,
            Vec3::new(GROUND_HALF_SIZE, 0.0, -GROUND_HALF_SIZE)
        );
        assert!(player.seat.is_none());
    }

    #[test]
    fn loaded_bounds_place_player_outside_and_facing_the_creation() {
        let mut player = PlayerState::default();
        let mut camera = PlayerCamera::default();
        player.place_outside_bounds(
            &mut camera,
            Vec3::new(-2.0, 0.0, -2.0),
            Vec3::new(2.0, 3.0, 2.0),
        );
        assert_eq!(player.position.y, 0.0);
        let forward = camera_relative_movement(Vec2::Y, camera.yaw);
        let toward = (Vec3::ZERO - player.position).normalize_or_zero();
        assert!(forward.dot(toward) > 0.99);
    }

    #[test]
    #[allow(clippy::cast_precision_loss)] // Test sector counts are small.
    fn material_sectors_run_clockwise_from_the_top_and_centre_cancels() {
        let context = Some(WheelChoice::ConstructionMaterial(
            ConstructionMaterial::Steel,
        ));
        assert_eq!(choice_at_selector(Vec2::ZERO, context), None);
        for (index, material) in ConstructionMaterial::ALL.into_iter().enumerate() {
            let angle = TAU * index as f32 / ConstructionMaterial::ALL.len() as f32;
            let direction = Vec2::new(angle.sin(), -angle.cos()) * 80.0;
            assert_eq!(
                choice_at_selector(direction, context),
                Some(WheelChoice::ConstructionMaterial(material))
            );
        }
    }

    #[test]
    #[allow(clippy::cast_precision_loss)] // Test sector counts are small.
    fn item_and_terrain_selectors_cover_every_contextual_sector() {
        for (index, item) in PlaceableItem::ALL.into_iter().enumerate() {
            let angle = TAU * index as f32 / PlaceableItem::ALL.len() as f32;
            let direction = Vec2::new(angle.sin(), -angle.cos()) * 80.0;
            assert_eq!(
                choice_at_selector(direction, Some(WheelChoice::Item(PlaceableItem::Bearing))),
                Some(WheelChoice::Item(item)),
            );
        }
        for (index, mode) in crate::shape_tool::ShapeEditMode::ALL
            .into_iter()
            .enumerate()
        {
            let angle = TAU * index as f32 / crate::shape_tool::ShapeEditMode::ALL.len() as f32;
            let direction = Vec2::new(angle.sin(), -angle.cos()) * 80.0;
            assert_eq!(
                choice_at_selector(
                    direction,
                    Some(WheelChoice::ShapeMode(
                        crate::shape_tool::ShapeEditMode::Vertex,
                    )),
                ),
                Some(WheelChoice::ShapeMode(mode)),
            );
        }
        let materials = TerrainMaterial::ALL;
        for (index, material) in materials.into_iter().enumerate() {
            let angle = TAU * index as f32 / materials.len() as f32;
            let direction = Vec2::new(angle.sin(), -angle.cos()) * 80.0;
            assert_eq!(
                choice_at_selector(
                    direction,
                    Some(WheelChoice::TerrainMaterial(TerrainMaterial::Soil)),
                ),
                Some(WheelChoice::TerrainMaterial(material)),
            );
        }
    }

    #[test]
    fn avatar_fades_between_first_and_third_person_thresholds() {
        assert_eq!(avatar_alpha(AVATAR_HIDDEN_PULLBACK), 0.0);
        assert_eq!(avatar_alpha(AVATAR_OPAQUE_PULLBACK), 1.0);
        assert!((avatar_alpha(0.675) - 0.5).abs() < 1.0e-5);
    }

    #[test]
    fn reticle_ray_uses_the_viewport_centre() {
        assert_eq!(
            viewport_center(Vec2::new(1600.0, 900.0)),
            Vec2::new(800.0, 450.0)
        );
    }

    #[test]
    fn drag_dead_zone_is_angular() {
        let start = Vec3::Z;
        assert!(!ray_drag_started(
            start,
            Quat::from_rotation_y(0.002) * start
        ));
        assert!(ray_drag_started(
            start,
            Quat::from_rotation_y(0.008) * start
        ));
    }

    #[test]
    fn seat_entry_requires_a_seat_inside_three_metres() {
        assert!(seat_entry_allowed(3.0, true));
        assert!(!seat_entry_allowed(3.001, true));
        assert!(!seat_entry_allowed(1.0, false));
    }

    #[test]
    fn material_wheel_respects_input_ownership_and_commits_only_on_release() {
        assert!(material_wheel_may_open(false, false, false));
        assert!(!material_wheel_may_open(true, false, false));
        assert!(!material_wheel_may_open(false, true, false));
        assert!(!material_wheel_may_open(false, false, true));
        assert_eq!(
            committed_choice(
                true,
                Some(WheelChoice::ConstructionMaterial(
                    ConstructionMaterial::Rubber
                ))
            ),
            Some(WheelChoice::ConstructionMaterial(
                ConstructionMaterial::Rubber
            ))
        );
        assert_eq!(
            committed_choice(
                false,
                Some(WheelChoice::ConstructionMaterial(
                    ConstructionMaterial::Rubber
                ))
            ),
            None
        );
        assert_eq!(committed_choice(true, None), None);
    }

    #[test]
    fn material_wheel_opens_on_and_retains_the_current_material_in_its_dead_zone() {
        let mut wheel = MaterialWheelState::default();
        wheel.open(WheelChoice::ConstructionMaterial(
            ConstructionMaterial::Wood,
        ));

        assert!(wheel.open);
        assert_eq!(
            wheel.highlighted,
            Some(WheelChoice::ConstructionMaterial(
                ConstructionMaterial::Wood
            ))
        );

        wheel.move_selector(Vec2::new(1.0, 1.0));
        assert_eq!(
            wheel.highlighted,
            Some(WheelChoice::ConstructionMaterial(
                ConstructionMaterial::Wood
            ))
        );

        wheel.move_selector(Vec2::new(0.0, -100.0));
        assert_eq!(
            wheel.highlighted,
            Some(WheelChoice::ConstructionMaterial(
                ConstructionMaterial::Aluminium
            ))
        );
        wheel.move_selector(Vec2::new(-1.0, 99.0));
        assert_eq!(
            wheel.highlighted,
            Some(WheelChoice::ConstructionMaterial(
                ConstructionMaterial::Aluminium
            ))
        );
    }

    #[test]
    fn tapping_a_two_choice_selector_toggles_and_aiming_commits_the_highlight() {
        use crate::hotbar::WeldMode;
        let mut wheel = MaterialWheelState::default();
        wheel.open(WheelChoice::WeldMode(WeldMode::Join));
        wheel.move_selector(Vec2::new(2.0, -3.0));
        assert_eq!(
            wheel.released_choice(),
            Some(WheelChoice::WeldMode(WeldMode::Place))
        );

        wheel.open(WheelChoice::WeldMode(WeldMode::Place));
        wheel.move_selector(Vec2::new(0.0, -80.0));
        wheel.move_selector(Vec2::new(0.0, 78.0));
        assert_eq!(
            wheel.released_choice(),
            Some(WheelChoice::WeldMode(WeldMode::Join))
        );

        wheel.open(WheelChoice::ShapeMode(
            crate::shape_tool::ShapeEditMode::Chamfer,
        ));
        assert_eq!(
            wheel.released_choice(),
            Some(WheelChoice::ShapeMode(
                crate::shape_tool::ShapeEditMode::Chamfer
            ))
        );
    }

    #[test]
    fn chroma_configuration_uses_the_selector_without_a_radial_choice() {
        let mut wheel = MaterialWheelState::default();
        wheel.open_chroma_config();

        assert!(wheel.open);
        assert!(wheel.chroma_config);
        assert_eq!(wheel.highlighted, None);
        assert_eq!(wheel.selector, Vec2::ZERO);

        wheel.close();
        assert_eq!(wheel, MaterialWheelState::default());
    }

    #[test]
    fn chroma_configuration_toggles_on_press_instead_of_release() {
        assert!(!chroma_config_should_close(false, false, true));
        assert!(chroma_config_should_close(true, false, true));
        assert!(chroma_config_should_close(false, false, false));
    }
}
