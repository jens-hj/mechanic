//! Packed median-split bounds trees, following the world's construction BVH.
use super::overlaps;
use bevy_math::DVec3;

type Bounds = [DVec3; 2];

pub(super) struct Tree {
    nodes: Vec<Node>,
}
struct Node {
    children: Option<[usize; 2]>,
    item: usize,
}
impl Tree {
    pub(super) fn new(mut items: Vec<usize>, bounds: &[Bounds]) -> Self {
        let mut tree = Self { nodes: Vec::new() };
        if !items.is_empty() {
            tree.build(&mut items, bounds);
        }
        tree
    }
    fn build(&mut self, items: &mut [usize], bounds: &[Bounds]) -> usize {
        let index = self.nodes.len();
        self.nodes.push(Node {
            children: None,
            item: items[0],
        });
        if items.len() > 1 {
            let aggregate = items
                .iter()
                .fold([DVec3::INFINITY, DVec3::NEG_INFINITY], |[lo, hi], &row| {
                    [lo.min(bounds[row][0]), hi.max(bounds[row][1])]
                });
            let extent = aggregate[1] - aggregate[0];
            let axis = if extent.x >= extent.y && extent.x >= extent.z {
                0
            } else if extent.y >= extent.z {
                1
            } else {
                2
            };
            items.sort_unstable_by(|&a, &b| {
                (bounds[a][0][axis] + bounds[a][1][axis])
                    .total_cmp(&(bounds[b][0][axis] + bounds[b][1][axis]))
                    .then(a.cmp(&b))
            });
            let (a, b) = items.split_at_mut(items.len() / 2);
            let children = [self.build(a, bounds), self.build(b, bounds)];
            self.nodes[index].children = Some(children);
        }
        index
    }
    pub(super) fn refit(&self, bounds: &[Bounds], output: &mut Vec<Bounds>) {
        output.resize(self.nodes.len(), [DVec3::ZERO; 2]);
        for (index, node) in self.nodes.iter().enumerate().rev() {
            output[index] = node.children.map_or(bounds[node.item], |[a, b]| {
                [
                    output[a][0].min(output[b][0]),
                    output[a][1].max(output[b][1]),
                ]
            });
        }
    }
    pub(super) fn query(
        &self,
        bounds: &[Bounds],
        query: Bounds,
        stack: &mut Vec<usize>,
        output: &mut Vec<usize>,
    ) -> usize {
        let mut tests = 0;
        stack.clear();
        if !self.nodes.is_empty() {
            stack.push(0);
        }
        while let Some(index) = stack.pop() {
            tests += 1;
            if !overlaps(bounds[index], query) {
                continue;
            }
            let node = &self.nodes[index];
            if let Some([a, b]) = node.children {
                stack.extend([b, a]);
            } else {
                output.push(node.item);
            }
        }
        tests
    }
}
