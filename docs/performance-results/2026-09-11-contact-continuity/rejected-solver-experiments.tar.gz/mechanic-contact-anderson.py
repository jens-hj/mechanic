exec(open('/private/tmp/mechanic-contact-reference.py').read().split('x=np.array(warm)')[0])
def project_all(x):
    x=x.copy()
    for b,(first,size,_) in zip(blocks,layout): x[first:first+size]=project(b,x[first:first+size],False)
    return x
def sweep(x):
    x=x.copy()
    for b,(first,size,s) in zip(blocks,layout):
        sl=slice(first,first+size); x[sl]=project(b,x[sl]+(target[sl]-W[sl]@x)/s,False)
    return x
for history in [4,8,16,24]:
    for feasible in [False,True]:
        x=project_all(np.array(warm)); xs=[]; fs=[]; errors=[]
        for it in range(256):
            g=sweep(x); f=g-x
            xs.append(x.copy()); fs.append(f.copy())
            if len(xs)>history+1: xs.pop(0);fs.pop(0)
            error=max(abs(evaluate(g)[0])); errors.append(error)
            if len(xs)>1:
                dx=np.diff(np.array(xs),axis=0).T; df=np.diff(np.array(fs),axis=0).T
                gamma=np.linalg.lstsq(df*scale[:,None],f*scale,rcond=1e-12)[0]
                p=g-(dx+df)@gamma
                if feasible:p=project_all(p)
                for k in range(16):
                    trial=g+(p-g)*.5**k
                    if max(abs(evaluate(trial)[0]))<max(errors[-16:]):g=trial;break
            x=g
            if max(abs(evaluate(x)[0]))<1e-9:break
        print('anderson',history,feasible,it+1,max(abs(evaluate(x)[0])), 'staticfraction',np.linalg.norm(x[7:9])/(blocks[6][3][0][0]*x[6]),flush=True)
