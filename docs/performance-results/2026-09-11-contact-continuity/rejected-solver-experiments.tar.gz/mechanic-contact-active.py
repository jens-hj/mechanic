exec(open('/private/tmp/mechanic-contact-reference.py').read().split('x=np.array(warm)')[0])
def active(x):
    v=W@x-target; at=x-v/scale; E=v.copy(); A=W.copy()
    for b,(first,size,s) in zip(blocks,layout):
        for i,(lo,hi) in enumerate(b[2]):
            j=first+i
            if at[j]<=lo or at[j]>=hi:
                E[j]=(x[j]-np.clip(at[j],lo,hi))*s; A[j]=0;A[j,j]=s
        k=first
        for mus,muk,sliding,rolling in b[3]:
            for off,mu in [(1,muk if sliding else mus)]+([(3,rolling)] if rolling is not None else []):
                i=k+off;j=i+1
                if np.linalg.norm(at[i:j+1])>=mu*max(at[k],0):
                    length=max(np.linalg.norm(x[i:j+1]),1e-10)
                    E[i]=(x[i]**2+x[j]**2-mu**2*x[k]**2)*s/(2*length)
                    A[i]=0;A[i,i]=x[i]*s/length;A[i,j]=x[j]*s/length;A[i,k]=-mu**2*x[k]*s/length
                    E[j]=(x[i]*v[j]-x[j]*v[i])/length
                    A[j]=(x[i]*W[j]-x[j]*W[i])/length;A[j,i]+=v[j]/length;A[j,j]-=v[i]/length
            k+=5 if rolling is not None else 3
    return E,A
for merit_kind in ['physical','active']:
    x=np.array(warm); history=[]
    for it in range(256):
        E,A=active(x); F,_=evaluate(x); err=max(abs(F))
        if it%20==0:print(merit_kind,it,err,flush=True)
        if err<1e-9:break
        measure=lambda trial:np.linalg.norm(evaluate(trial)[0] if merit_kind=='physical' else active(trial)[0])
        norm=measure(x);history.append(norm);best=(norm,x)
        for damping in [0,1e-12,1e-10,1e-8,1e-6]:
            delta=np.linalg.lstsq(A,-E,rcond=1e-14)[0] if damping==0 else np.linalg.solve(A.T@A+damping*np.eye(len(x)),-A.T@E)
            for power in range(24):
                trial=x+delta*.5**power;m=measure(trial)
                if m<best[0]:best=(m,trial)
                if m<norm*(1-1e-4*.5**power):break
        if best[0]>=norm:print('stalled');break
        x=best[1]
    print('final',merit_kind,it+1,max(abs(evaluate(x)[0])), x.tolist(),flush=True)
