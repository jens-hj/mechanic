use super::*;

type RecordedBlock = (
    Vec<Vec<f64>>,
    Vec<f64>,
    Vec<(f64, f64)>,
    Vec<(f64, f64, bool, Option<f64>)>,
);

#[test]
fn captured_cold_car_impact_converges_without_relaxing_its_velocity_residual() {
    let (mass, recorded): (Vec<f64>, Vec<RecordedBlock>) =
        ron::from_str(include_str!("fixtures/cold_car_impact.ron")).unwrap();
    let blocks = blocks(recorded);
    let factor = DynamicsFactor::new(&mass, blocks[0].jacobian[0].len()).unwrap();
    let solution = solve_constraints(&factor, &blocks, 256, 1e-9).unwrap();
    assert!(solution.converged, "residual={:e}", solution.residual);
    assert!(solution.residual <= 1e-9);
    assert!(solution.iterations <= 256);
    // Independently check every original contact, including the inactive
    // hypothesis. No normal row may be hidden by the trial's temporary bound.
    let mut first = 0;
    for block in &blocks {
        let mut row = 0;
        for contact in &block.contacts {
            let normal = solution.impulses[first + row];
            let slack = dot(&block.jacobian[row], &solution.velocity_change) - block.target[row];
            assert!(normal >= 0.0 && slack >= -1e-9);
            if normal > 0.0 {
                assert!(slack.abs() <= 1e-9);
            }
            let tangent =
                solution.impulses[first + row + 1].hypot(solution.impulses[first + row + 2]);
            assert!(tangent <= contact.kinetic_coefficient * normal + 1e-12);
            if let Some(length) = contact.rolling_length {
                let rolling =
                    solution.impulses[first + row + 3].hypot(solution.impulses[first + row + 4]);
                assert!(rolling <= length * normal + 1e-12);
            }
            row += contact.rows();
        }
        first += block.target.len();
    }
    let repeated = solve_constraints(&factor, &blocks, 256, 1e-9).unwrap();
    assert_eq!(solution.impulses, repeated.impulses);
    assert_eq!(solution.velocity_change, repeated.velocity_change);
    println!(
        "captured_impact residual={:e} iterations={} inactive_trials={}",
        solution.residual, solution.iterations, solution.active_set_trials
    );
}

fn blocks(recorded: Vec<RecordedBlock>) -> Vec<ConstraintBlock> {
    recorded
        .into_iter()
        .map(|(jacobian, target, bounds, contacts)| ConstraintBlock {
            jacobian,
            target,
            bounds: bounds
                .into_iter()
                .map(|(minimum, maximum)| ImpulseBounds { minimum, maximum })
                .collect(),
            contacts: contacts
                .into_iter()
                .map(
                    |(static_coefficient, kinetic_coefficient, sliding, rolling_length)| {
                        ContactFriction {
                            static_coefficient,
                            kinetic_coefficient,
                            sliding,
                            rolling_length,
                        }
                    },
                )
                .collect(),
        })
        .collect::<Vec<_>>()
}

#[test]
fn a_wrong_inactive_contact_trial_is_discarded_without_losing_the_original_solution() {
    let (lower, recorded, initial): (Vec<f64>, Vec<RecordedBlock>, Option<Vec<f64>>) =
        ron::from_str(include_str!("fixtures/rejected_contact_trial.ron")).unwrap();
    let blocks = blocks(recorded);
    let size = blocks[0].jacobian[0].len();
    assert_eq!(lower.len(), size * size);
    let factor = DynamicsFactor { size, lower };
    let targets = blocks
        .iter()
        .flat_map(|b| b.target.clone())
        .collect::<Vec<_>>();
    let mut response = PreparedConstraints::new(&factor, &blocks).unwrap();
    let original = response
        .solve_with_contact_trial(&targets, initial.as_deref(), 256, 1e-9, false)
        .unwrap();
    let actual = response
        .solve_from(&targets, initial.as_deref(), 256, 1e-9)
        .unwrap();
    println!("rejected_trial original={original:?} actual={actual:?}");
    assert!(original.converged && actual.converged);
    assert!(actual.active_set_trial_rejections > 0);
    assert!(actual.iterations <= 256);
    for (a, b) in actual.velocity_change.iter().zip(&original.velocity_change) {
        assert!((a - b).abs() < 1e-8);
    }
}

// Captured finite-duration car solve: the warm guess reaches the static cone
// only at sweep 241, leaving too little of its 256-sweep budget after breakaway.
#[test]
fn stalled_warm_contact_restarts_within_the_original_budget_and_proves_breakaway() {
    let (lower, recorded, initial): (Vec<f64>, Vec<RecordedBlock>, Option<Vec<f64>>) =
        ron::from_str(include_str!("fixtures/cold_settling.ron")).unwrap();
    let blocks = blocks(recorded);
    let factor = DynamicsFactor {
        size: blocks[0].jacobian[0].len(),
        lower,
    };
    let targets = blocks
        .iter()
        .flat_map(|b| b.target.clone())
        .collect::<Vec<_>>();
    let mut response = PreparedConstraints::new(&factor, &blocks).unwrap();
    let cold = response.solve_from(&targets, None, 256, 1e-9).unwrap();
    let actual = response
        .solve_from(&targets, initial.as_deref(), 256, 1e-9)
        .unwrap();
    assert!(cold.converged && actual.converged);
    assert_eq!(cold.warm_start_restarts, 0);
    assert_eq!(actual.warm_start_restarts, 1);
    assert!(actual.iterations > cold.iterations && actual.iterations <= 256);
    assert_eq!(actual.impulses, cold.impulses);
    assert_eq!(actual.velocity_change, cold.velocity_change);
    assert_eq!(actual.sliding, [true; 4]);
    assert_eq!(actual.friction_transitions, 1);
    check_contact_laws(&blocks, &actual.impulses, &actual.velocity_change, true);
    let repeated = response
        .solve_from(&targets, initial.as_deref(), 256, 1e-9)
        .unwrap();
    assert_eq!(actual.impulses, repeated.impulses);
    assert_eq!(actual.velocity_change, repeated.velocity_change);
    let limited = response
        .solve_from(&targets, initial.as_deref(), 64, 1e-9)
        .unwrap();
    assert_eq!(limited.warm_start_restarts, 1);
    assert_eq!(limited.iterations, 64);
    assert!(!limited.converged && limited.residual > 1e-9);
    println!(
        "cold_settling warm_sweeps={} cold_sweeps={} residual={:e} restarts={}",
        actual.iterations, cold.iterations, actual.residual, actual.warm_start_restarts
    );

    // Independent NumPy reference retained in the evidence checkpoint. Before
    // promotion it satisfies every recorded static-mode equation, yet the first
    // point has nonzero slip at its static impulse limit. This establishes the
    // existing breakaway rule without inferring it from an unfinished iterate.
    let static_impulses: Vec<f64> =
        ron::from_str(include_str!("fixtures/cold_settling_static.ron")).unwrap();
    let rows = blocks.iter().flat_map(|b| &b.jacobian).collect::<Vec<_>>();
    let (velocity, _) = response_motion(&factor, &rows, &static_impulses).unwrap();
    check_contact_laws(&blocks, &static_impulses, &velocity, false);
    let slip = (dot(rows[7], &velocity) - targets[7]).hypot(dot(rows[8], &velocity) - targets[8]);
    assert!(slip > 5e-6);
    assert!(
        (static_impulses[7].hypot(static_impulses[8])
            - blocks[6].contacts[0].static_coefficient * static_impulses[6])
            .abs()
            < 1e-8
    );
}

// Checks bounds, normal complementarity, and disk direction/complementarity
// directly in physical row velocities, without using the solver's projection.
fn check_contact_laws(
    blocks: &[ConstraintBlock],
    impulses: &[f64],
    velocity: &[f64],
    kinetic: bool,
) {
    let mut first = 0;
    for block in blocks {
        let slack = block
            .jacobian
            .iter()
            .zip(&block.target)
            .map(|(row, target)| dot(row, velocity) - target)
            .collect::<Vec<_>>();
        for (local, bounds) in block.bounds.iter().enumerate() {
            let impulse = impulses[first + local];
            assert!(impulse >= bounds.minimum - 1e-8 && impulse <= bounds.maximum + 1e-8);
            if block.contacts.is_empty() {
                if impulse > bounds.minimum + 1e-8 {
                    assert!(slack[local] <= 1e-8);
                }
                if impulse < bounds.maximum - 1e-8 {
                    assert!(slack[local] >= -1e-8);
                }
            }
        }
        let mut local = 0;
        for law in &block.contacts {
            let normal = impulses[first + local];
            assert!(normal >= 0.0 && slack[local] >= -1e-9);
            if normal > 1e-8 {
                assert!(slack[local].abs() <= 1e-9);
            }
            let coefficient = if kinetic || law.sliding {
                law.kinetic_coefficient
            } else {
                law.static_coefficient
            };
            for (offset, coefficient) in std::iter::once((1, coefficient))
                .chain(law.rolling_length.map(|length| (3, length)))
            {
                let a = impulses[first + local + offset];
                let b = impulses[first + local + offset + 1];
                let u = slack[local + offset];
                let v = slack[local + offset + 1];
                let radius = coefficient * normal;
                assert!(a.hypot(b) <= radius + 1e-8);
                if u.hypot(v) > 1e-8 {
                    assert!((a.hypot(b) - radius).abs() < 1e-8);
                    // Sliding friction opposes motion, including rolling motion.
                    assert!(a * u + b * v <= 0.0);
                    assert!((a * v - b * u).abs() / radius.max(1e-12) < 1e-8);
                }
            }
            local += law.rows();
        }
        first += block.target.len();
    }
}
