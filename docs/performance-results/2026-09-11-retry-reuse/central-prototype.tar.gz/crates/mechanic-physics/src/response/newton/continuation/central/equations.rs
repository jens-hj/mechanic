//! Barrier equations for search only; no compliance enters physical acceptance.

use super::{Problem, dot};

pub(super) struct Local {
    pub first: usize,
    pub size: usize,
    pub matrix: Vec<f64>,
    pub velocity: Vec<f64>,
    pub parameter: Vec<f64>,
    pub rhs: Vec<f64>,
}

pub(super) struct Evaluation {
    pub locals: Vec<Local>,
    pub residual: Vec<f64>,
    pub norm: f64,
    pub maximum: f64,
}

#[allow(clippy::too_many_lines)]
pub(super) fn evaluate(
    problem: &Problem<'_>,
    x: &[f64],
    epsilon: f64,
    stable: bool,
) -> Option<Evaluation> {
    let velocity = problem.motion(x);
    let motion = problem
        .rows
        .iter()
        .zip(&problem.targets)
        .map(|(row, target)| dot(row, &velocity) - target)
        .collect::<Vec<_>>();
    let mut result = Evaluation {
        locals: Vec::new(),
        residual: Vec::new(),
        norm: 0.0,
        maximum: 0.0,
    };
    for point in &problem.points {
        let first = point.first;
        let size = point.size;
        let normal = x[first];
        if normal <= 0.0 || !normal.is_finite() {
            return None;
        }
        let mut local = Local {
            first,
            size,
            matrix: vec![0.0; size * size],
            velocity: vec![0.0; size * problem.size],
            parameter: vec![0.0; size],
            rhs: vec![0.0; size],
        };
        let mut residual = motion[first..first + size].to_vec();
        residual[0] -= epsilon / normal;
        local.matrix[0] = epsilon / (normal * normal);
        local.velocity[..problem.size].copy_from_slice(problem.rows[first]);
        local.parameter[0] = -epsilon / normal;
        for (offset, coefficient) in
            std::iter::once((1, point.friction)).chain(point.rolling.map(|length| (3, length)))
        {
            let tangent = [x[first + offset], x[first + offset + 1]];
            let radius = coefficient * normal;
            if stable {
                let slip = [motion[first + offset], motion[first + offset + 1]];
                let squared = dot(&slip, &slip);
                let root = epsilon.hypot(radius * squared.sqrt());
                let denominator = epsilon + root;
                let beta = radius * radius / denominator;
                let derivative_normal = coefficient
                    * (2.0 * radius / denominator
                        - radius.powi(3) * squared / (root * denominator * denominator));
                let derivative_slip = -radius.powi(4) / (root * denominator * denominator);
                let scale = problem.scales[first];
                let divisor = 1.0 + scale * beta;
                let leading = scale / divisor;
                for row in 0..2 {
                    let at = offset + row;
                    let multiplier =
                        scale * (slip[row] - scale * tangent[row]) / (divisor * divisor);
                    residual[at] = leading * (tangent[row] + beta * slip[row]);
                    local.matrix[at * size + at] = leading;
                    local.matrix[at * size] = multiplier * derivative_normal;
                    local.parameter[at] = multiplier * (-epsilon / root * beta);
                    for axis in 0..problem.size {
                        local.velocity[at * problem.size + axis] =
                            leading * beta * problem.rows[first + at][axis]
                                + multiplier
                                    * derivative_slip
                                    * (slip[0] * problem.rows[first + offset][axis]
                                        + slip[1] * problem.rows[first + offset + 1][axis]);
                    }
                }
            } else {
                let length = tangent[0].hypot(tangent[1]);
                let gap = (radius - length) * (radius + length);
                if gap <= 0.0 {
                    return None;
                }
                for row in 0..2 {
                    let at = offset + row;
                    local.parameter[at] = 2.0 * epsilon * tangent[row] / gap;
                    residual[at] += local.parameter[at];
                    local.matrix[at * size] =
                        -4.0 * epsilon * coefficient * coefficient * normal * tangent[row]
                            / (gap * gap);
                    for column in 0..2 {
                        local.matrix[at * size + offset + column] = 2.0 * epsilon / gap
                            * f64::from(row == column)
                            + 4.0 * epsilon * tangent[row] * tangent[column] / (gap * gap);
                    }
                    local.velocity[at * problem.size..(at + 1) * problem.size]
                        .copy_from_slice(problem.rows[first + at]);
                }
            }
        }
        if residual
            .iter()
            .chain(&local.matrix)
            .chain(&local.velocity)
            .chain(&local.parameter)
            .any(|v| !v.is_finite())
        {
            return None;
        }
        for (rhs, value) in local.rhs.iter_mut().zip(&residual) {
            *rhs = -value;
            result.norm = result.norm.hypot(*value);
            result.maximum = result.maximum.max(value.abs());
        }
        result.residual.extend(residual);
        result.locals.push(local);
    }
    Some(result)
}
