//! CPU experiments for compiled machine dynamics.
//!
//! Numerical factors, pose-dependent response, and transactional free-motion
//! reference ticks. This is not yet an authoritative world runtime: collision,
//! constrained ticks, drive integration, and cross-backend acceptance remain open.

mod free_motion;
mod machine;
mod response;

pub use free_motion::{CpuFreeMotion, CpuSnapshot, ExternalImpulse, MachineState, TICK_SECONDS};
pub use machine::{BodyPose, MachineDynamics, SpatialMotion};
pub use response::{
    ConstraintBlock, ConstraintSolution, DENSE_CONTACT_ROWS, DynamicsFactor, ImpulseBounds,
    solve_constraints,
};

/// Explicit failures from the compiled dynamics experiment. Failed results must
/// never be published as a completed physics tick.
#[derive(Clone, Debug, thiserror::Error, PartialEq, Eq)]
pub enum PhysicsError {
    /// A command targets another tick/topology or contains an invalid impulse.
    #[error("invalid tick-indexed external impulse")]
    InvalidCommand,
    /// The free-motion reference cannot discard authored constraints or forces.
    #[error("free-motion reference requires passive unbounded revolute trees without loops")]
    UnsupportedFreeMotion,
    /// Malformed or non-positive effective dynamics.
    #[error("effective dynamics are non-finite, asymmetric, or not positive definite")]
    InvalidDynamics,
    /// Invalid constraint dimensions, bounds, or solver settings.
    #[error("invalid constraint rows or solver settings")]
    InvalidConstraints,
    /// Rank-revealing elimination found incompatible dependent equations.
    #[error("dependent constraint rows have inconsistent targets")]
    InconsistentConstraints,
    /// The reference experiment deliberately bounds its dense generalized matrix.
    #[error("dense reference experiment supports at most 512 generalized velocities")]
    ReferenceCapacity,
}
