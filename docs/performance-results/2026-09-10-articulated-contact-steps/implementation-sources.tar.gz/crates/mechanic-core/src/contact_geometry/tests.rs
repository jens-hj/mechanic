use super::*;
use crate::{BuildCommand, BuildPose, CompiledConvex, ConstructionGraph, CuboidSpec};

fn cube() -> ContactPolytope {
    let mut graph = ConstructionGraph::new();
    graph
        .apply(BuildCommand::Spawn(
            CuboidSpec::new([4, 4, 4], BuildPose::default()).unwrap(),
        ))
        .unwrap();
    ContactPolytope::from_collider(&graph.compile().unwrap().colliders[0]).unwrap()
}

fn floor() -> [DVec3; 3] {
    [
        DVec3::new(-10.0, 0.0, -10.0),
        DVec3::new(0.0, 0.0, 10.0),
        DVec3::new(10.0, 0.0, -10.0),
    ]
}

#[test]
fn resting_box_retains_four_finite_supports_with_measured_depth() {
    let body = cube()
        .transformed(DVec3::Y * 0.499, DQuat::IDENTITY)
        .unwrap();
    let points = body.triangle_contacts(floor()).unwrap();
    assert_eq!(points.len(), 4);
    for point in points {
        assert!((point.depth - 0.001).abs() < 1e-12);
        assert!(point.normal.abs_diff_eq(DVec3::Y, 1e-12));
        assert!(point.body_point.y.abs() <= 0.001 + 1e-12);
        assert!(point.triangle_point.y.abs() < 1e-12);
    }
}

#[test]
fn finite_edges_holes_and_below_surface_separation_produce_no_contact() {
    let triangle = [DVec3::ZERO, DVec3::Z, DVec3::X];
    for position in [
        DVec3::new(4.0, 0.0, 0.0),
        DVec3::new(0.1, -2.0, 0.1),
        DVec3::new(0.1, 2.0, 0.1),
    ] {
        let body = cube().transformed(position, DQuat::IDENTITY).unwrap();
        assert!(body.triangle_contacts(triangle).unwrap().is_empty());
    }
    let body = cube()
        .transformed(DVec3::new(4.0, 2.0, 0.0), DQuat::IDENTITY)
        .unwrap();
    assert!(
        body.translation_interval(triangle, -DVec3::Y * 4.0)
            .unwrap()
            .is_none()
    );
}

#[test]
fn oblique_contacts_have_points_on_both_actual_surfaces() {
    let body = cube()
        .transformed(DVec3::Y * 0.2, DQuat::from_rotation_z(0.67))
        .unwrap();
    let triangle = [
        DVec3::new(-0.3, 0.0, -1.0),
        DVec3::new(0.0, 0.0, 1.0),
        DVec3::new(0.3, 0.0, -1.0),
    ];
    let contacts = body.triangle_contacts(triangle).unwrap();
    assert!(contacts.len() >= 3);
    for point in contacts {
        let mut on_surface = false;
        for plane in &body.planes {
            let error = plane.truncate().dot(point.body_point) - plane.w;
            assert!(error <= 1e-12, "body point outside convex: {error}");
            on_surface |= error.abs() < 1e-12;
        }
        assert!(on_surface);
        for edge in 0..3 {
            assert!(
                (triangle[(edge + 1) % 3] - triangle[edge])
                    .cross(point.triangle_point - triangle[edge])
                    .dot(point.normal)
                    >= -1e-12
            );
        }
    }
}

#[test]
fn continuous_translation_finds_fast_crossing_even_when_both_endpoints_are_clear() {
    let body = cube()
        .transformed(DVec3::Y * 10.0, DQuat::IDENTITY)
        .unwrap();
    assert!(body.triangle_contacts(floor()).unwrap().is_empty());
    let [entry, exit] = body
        .translation_interval(floor(), -DVec3::Y * 20.0)
        .unwrap()
        .unwrap();
    assert!((entry - 0.475).abs() < 1e-12);
    assert!((exit - 0.525).abs() < 1e-12);
    let impact = cube()
        .transformed(DVec3::Y * (10.0 - 20.0 * entry), DQuat::IDENTITY)
        .unwrap();
    assert_eq!(impact.triangle_contacts(floor()).unwrap().len(), 4);
}

#[test]
fn convex_plane_offsets_and_local_box_rotation_give_equivalent_queries() {
    let mut graph = ConstructionGraph::new();
    graph
        .apply(BuildCommand::Spawn(
            CuboidSpec::new([4, 4, 4], BuildPose::default()).unwrap(),
        ))
        .unwrap();
    let mut collider = graph.compile().unwrap().colliders[0].clone();
    let reference = cube();
    collider.shape = ColliderShape::Convex(CompiledConvex {
        vertices: reference.vertices.iter().map(|v| v.as_vec3()).collect(),
        face_planes: reference.planes.iter().map(|v| v.as_vec4()).collect(),
        edge_directions: reference.edges.iter().map(|v| v.as_vec3()).collect(),
    });
    let convex = ContactPolytope::from_collider(&collider).unwrap();
    let position = DVec3::new(0.1, 0.49, -0.1);
    let rotation = DQuat::from_rotation_z(0.1);
    let a = reference.transformed(position, rotation).unwrap();
    let b = convex.transformed(position, rotation).unwrap();
    assert_eq!(
        a.triangle_contacts(floor()).unwrap(),
        b.triangle_contacts(floor()).unwrap()
    );
    assert_eq!(
        a.translation_interval(floor(), DVec3::Y).unwrap(),
        b.translation_interval(floor(), DVec3::Y).unwrap()
    );
}

#[test]
fn invalid_triangle_and_motion_are_errors_instead_of_missing_contacts() {
    assert_eq!(
        cube().triangle_contacts([DVec3::ZERO; 3]),
        Err(ContactGeometryError)
    );
    assert_eq!(
        cube().translation_interval(floor(), DVec3::splat(f64::NAN)),
        Err(ContactGeometryError)
    );
}

#[test]
fn rotational_sweep_finds_an_impact_hidden_by_identical_endpoint_poses() {
    let mut graph = ConstructionGraph::new();
    graph
        .apply(BuildCommand::Spawn(
            CuboidSpec::new([16, 1, 1], BuildPose::default()).unwrap(),
        ))
        .unwrap();
    let bar = ContactPolytope::from_collider(&graph.compile().unwrap().colliders[0]).unwrap();
    let position = DVec3::Y;
    assert!(
        bar.transformed(position, DQuat::IDENTITY)
            .unwrap()
            .triangle_contacts(floor())
            .unwrap()
            .is_empty()
    );
    let motion = RigidContactSweep {
        translation: DVec3::ZERO,
        angular_displacement: DVec3::Z * std::f64::consts::TAU,
    };
    let SweepOutcome::Impact {
        fraction,
        separation,
        ..
    } = bar
        .rigid_triangle_sweep(floor(), position, DQuat::IDENTITY, motion, 1e-9, 128)
        .unwrap()
    else {
        panic!("full rotation must hit the floor");
    };
    let angle = (1.0 / 2.0_f64.hypot(0.125)).asin() - (0.125_f64 / 2.0).atan();
    assert!((fraction - angle / std::f64::consts::TAU).abs() < 1e-9);
    assert!(separation <= 1e-9);
    assert!(fraction > 0.0 && fraction < 0.25);
}

#[test]
fn conservative_sweep_matches_exact_translation_and_reports_exhaustion() {
    let position = DVec3::Y * 10.0;
    let motion = RigidContactSweep {
        translation: -DVec3::Y * 20.0,
        angular_displacement: DVec3::ZERO,
    };
    let SweepOutcome::Impact { fraction, .. } = cube()
        .rigid_triangle_sweep(floor(), position, DQuat::IDENTITY, motion, 1e-10, 16)
        .unwrap()
    else {
        panic!("translation crosses floor");
    };
    assert!((fraction - 0.475).abs() < 1e-12);
    assert!(matches!(
        cube()
            .rigid_triangle_sweep(floor(), position, DQuat::IDENTITY, motion, 1e-10, 1)
            .unwrap(),
        SweepOutcome::Unconverged { .. }
    ));
    let finite = [DVec3::ZERO, DVec3::Z, DVec3::X];
    assert!(matches!(
        cube()
            .rigid_triangle_sweep(
                finite,
                position + DVec3::X * 4.0,
                DQuat::IDENTITY,
                motion,
                1e-10,
                128
            )
            .unwrap(),
        SweepOutcome::Separated { .. }
    ));
}
