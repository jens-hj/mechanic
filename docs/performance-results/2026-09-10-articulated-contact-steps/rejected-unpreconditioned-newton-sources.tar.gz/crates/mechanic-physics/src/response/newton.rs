//! Matrix-free Newton proposal for the unchanged projected contact equations.

use super::{BlockLayout, ConstraintBlock, block_scale, project};

const KRYLOV_ROWS: usize = 32;

pub(super) struct NewtonWork {
    pub direction: Option<Vec<f64>>,
    pub applications: usize,
}

pub(super) fn direction(
    blocks: &[ConstraintBlock],
    layout: &[BlockLayout],
    impulses: &[f64],
    row_change: &[f64],
    modes: &[Vec<bool>],
    mut response: impl FnMut(&[f64]) -> Option<Vec<f64>>,
) -> NewtonWork {
    let mut at = impulses.to_vec();
    let mut steps = vec![0.0; impulses.len()];
    for (block, info) in blocks.iter().zip(layout) {
        let step = block_scale(&info.diagonal, block.jacobian.len()).recip();
        for row in 0..block.jacobian.len() {
            let index = info.first + row;
            steps[index] = step;
            at[index] += step * (block.target[row] - row_change[index]);
        }
    }
    let mut projected = at.clone();
    for ((block, info), modes) in blocks.iter().zip(layout).zip(modes) {
        project(
            block,
            modes,
            &mut projected[info.first..info.first + block.jacobian.len()],
        );
    }
    let rhs = projected
        .iter()
        .zip(impulses)
        .map(|(value, old)| value - old)
        .collect::<Vec<_>>();
    let mut applications = 0;
    let direction = gmres(&rhs, |trial| {
        applications += 1;
        let applied = response(trial)?;
        let input = trial
            .iter()
            .zip(applied.iter().zip(&steps))
            .map(|(v, (w, step))| v - step * w)
            .collect::<Vec<_>>();
        let mut derivative = input.clone();
        for ((block, info), modes) in blocks.iter().zip(layout).zip(modes) {
            let range = info.first..info.first + block.jacobian.len();
            projection_derivative(
                block,
                modes,
                &at[range.clone()],
                &input[range.clone()],
                &mut derivative[range],
            );
        }
        let result = trial
            .iter()
            .zip(derivative)
            .map(|(value, projected)| value - projected)
            .collect::<Vec<_>>();
        result.iter().all(|v| v.is_finite()).then_some(result)
    });
    NewtonWork {
        direction,
        applications,
    }
}

fn projection_derivative(
    block: &ConstraintBlock,
    modes: &[bool],
    at: &[f64],
    input: &[f64],
    output: &mut [f64],
) {
    for (row, bounds) in block.bounds.iter().enumerate() {
        output[row] = if at[row] > bounds.minimum && at[row] < bounds.maximum {
            input[row]
        } else {
            0.0
        };
    }
    let mut first = 0;
    for (law, &sliding) in block.contacts.iter().zip(modes) {
        let normal = at[first].clamp(block.bounds[first].minimum, block.bounds[first].maximum);
        let normal_derivative = output[first];
        let coefficient = if sliding {
            law.kinetic_coefficient
        } else {
            law.static_coefficient
        };
        disk_derivative(
            &at[first + 1..first + 3],
            &input[first + 1..first + 3],
            coefficient * normal,
            coefficient * normal_derivative,
            &mut output[first + 1..first + 3],
        );
        if let Some(length) = law.rolling_length {
            disk_derivative(
                &at[first + 3..first + 5],
                &input[first + 3..first + 5],
                length * normal,
                length * normal_derivative,
                &mut output[first + 3..first + 5],
            );
        }
        first += law.rows();
    }
}

fn disk_derivative(
    at: &[f64],
    input: &[f64],
    radius: f64,
    radius_derivative: f64,
    output: &mut [f64],
) {
    let length = at[0].hypot(at[1]);
    if length < radius {
        output.copy_from_slice(input);
    } else if length > 0.0 {
        let unit = [at[0] / length, at[1] / length];
        let radial = unit[0] * input[0] + unit[1] * input[1];
        for row in 0..2 {
            output[row] =
                radius / length * (input[row] - unit[row] * radial) + unit[row] * radius_derivative;
        }
    } else {
        output.fill(0.0);
    }
}

// Restart-free bounded GMRES with two-pass Arnoldi orthogonalization and Givens
// rotations. Workspace is O(32 * constraint_rows), not a dense contact matrix.
fn gmres(rhs: &[f64], mut apply: impl FnMut(&[f64]) -> Option<Vec<f64>>) -> Option<Vec<f64>> {
    let length = norm(rhs);
    if length == 0.0 || !length.is_finite() {
        return None;
    }
    let maximum = KRYLOV_ROWS.min(rhs.len());
    let mut basis = vec![rhs.iter().map(|value| value / length).collect::<Vec<_>>()];
    let mut hessenberg = vec![0.0; (maximum + 1) * maximum];
    let mut cosines = vec![0.0; maximum];
    let mut sines = vec![0.0; maximum];
    let mut transformed = vec![0.0; maximum + 1];
    transformed[0] = length;
    let mut count = 0;
    for column in 0..maximum {
        let mut vector = apply(&basis[column])?;
        for _ in 0..2 {
            for row in 0..=column {
                let component = dot(&basis[row], &vector);
                hessenberg[row * maximum + column] += component;
                for (value, axis) in vector.iter_mut().zip(&basis[row]) {
                    *value -= component * axis;
                }
            }
        }
        let remainder = norm(&vector);
        hessenberg[(column + 1) * maximum + column] = remainder;
        for row in 0..column {
            let a = hessenberg[row * maximum + column];
            let b = hessenberg[(row + 1) * maximum + column];
            hessenberg[row * maximum + column] = cosines[row] * a + sines[row] * b;
            hessenberg[(row + 1) * maximum + column] = -sines[row] * a + cosines[row] * b;
        }
        let diagonal = hessenberg[column * maximum + column];
        let hypotenuse = diagonal.hypot(hessenberg[(column + 1) * maximum + column]);
        if hypotenuse <= 1e-14 || !hypotenuse.is_finite() {
            break;
        }
        cosines[column] = diagonal / hypotenuse;
        sines[column] = hessenberg[(column + 1) * maximum + column] / hypotenuse;
        hessenberg[column * maximum + column] = hypotenuse;
        transformed[column + 1] = -sines[column] * transformed[column];
        transformed[column] *= cosines[column];
        count = column + 1;
        if transformed[column + 1].abs() <= length * 0.05 || remainder <= 1e-14 {
            break;
        }
        basis.push(vector.iter().map(|value| value / remainder).collect());
    }
    if count == 0 {
        return None;
    }
    let mut coefficients = vec![0.0; count];
    for row in (0..count).rev() {
        let later = (row + 1..count)
            .map(|column| hessenberg[row * maximum + column] * coefficients[column])
            .sum::<f64>();
        coefficients[row] = (transformed[row] - later) / hessenberg[row * maximum + row];
    }
    let mut result = vec![0.0; rhs.len()];
    for (column, coefficient) in basis.iter().zip(coefficients) {
        for (out, value) in result.iter_mut().zip(column) {
            *out += coefficient * value;
        }
    }
    result.iter().all(|v| v.is_finite()).then_some(result)
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}
fn norm(values: &[f64]) -> f64 {
    values
        .iter()
        .fold(0.0_f64, |length, value| length.hypot(*value))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{ContactFriction, ImpulseBounds};

    #[test]
    fn cone_derivative_matches_differentiated_normal_tangent_and_rolling_projection() {
        let block = ConstraintBlock {
            jacobian: vec![vec![0.0]; 5],
            target: vec![0.0; 5],
            bounds: vec![
                ImpulseBounds {
                    minimum: 0.0,
                    maximum: f64::INFINITY,
                },
                ImpulseBounds {
                    minimum: f64::NEG_INFINITY,
                    maximum: f64::INFINITY,
                },
                ImpulseBounds {
                    minimum: f64::NEG_INFINITY,
                    maximum: f64::INFINITY,
                },
                ImpulseBounds {
                    minimum: f64::NEG_INFINITY,
                    maximum: f64::INFINITY,
                },
                ImpulseBounds {
                    minimum: f64::NEG_INFINITY,
                    maximum: f64::INFINITY,
                },
            ],
            contacts: vec![ContactFriction {
                static_coefficient: 0.8,
                kinetic_coefficient: 0.5,
                sliding: true,
                rolling_length: Some(0.1),
            }],
        };
        let at = [2.0, 3.0, 4.0, 5.0, -7.0];
        let direction = [0.3, -0.7, 0.2, 0.1, -0.5];
        let mut analytic = [0.0; 5];
        projection_derivative(&block, &[true], &at, &direction, &mut analytic);
        let epsilon = 1e-6;
        let mut plus = std::array::from_fn::<_, 5, _>(|row| at[row] + epsilon * direction[row]);
        let mut minus = std::array::from_fn::<_, 5, _>(|row| at[row] - epsilon * direction[row]);
        project(&block, &[true], &mut plus);
        project(&block, &[true], &mut minus);
        for row in 0..5 {
            assert!((analytic[row] - (plus[row] - minus[row]) / (2.0 * epsilon)).abs() < 1e-9);
        }
    }

    #[test]
    fn matrix_free_gmres_solves_a_nonsymmetric_system() {
        let matrix = [[3.0, 2.0, -1.0], [0.0, 1.0, 0.5], [1.0, 0.0, 2.0]];
        let rhs = [4.0, 1.0, -2.0];
        let solution = gmres(&rhs, |value| {
            Some(matrix.iter().map(|row| dot(row, value)).collect())
        })
        .unwrap();
        for (row, target) in matrix.iter().zip(rhs) {
            assert!((dot(row, &solution) - target).abs() < 1e-10);
        }
    }
}
