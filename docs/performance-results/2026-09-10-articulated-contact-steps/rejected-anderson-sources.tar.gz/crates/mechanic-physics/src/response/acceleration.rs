//! Bounded deterministic Anderson history for a safeguarded fixed-point proposal.

use std::collections::VecDeque;

const HISTORY_DIFFERENCES: usize = 8;

#[derive(Default)]
pub(super) struct AndersonHistory {
    entries: VecDeque<Entry>,
}

struct Entry {
    mapped: Vec<f64>,
    residual: Vec<f64>,
}

impl AndersonHistory {
    pub(super) fn clear(&mut self) {
        self.entries.clear();
    }

    pub(super) fn propose(&mut self, initial: &[f64], mapped: &[f64]) -> Option<Vec<f64>> {
        self.entries.push_back(Entry {
            mapped: mapped.to_vec(),
            residual: mapped.iter().zip(initial).map(|(a, b)| a - b).collect(),
        });
        if self.entries.len() > HISTORY_DIFFERENCES + 1 {
            self.entries.pop_front();
        }
        let columns = self
            .entries
            .iter()
            .zip(self.entries.iter().skip(1))
            .map(|(a, b)| {
                b.residual
                    .iter()
                    .zip(&a.residual)
                    .map(|(new, old)| new - old)
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
        let latest = self.entries.back()?;
        let coefficients = least_squares(columns, &latest.residual)?;
        let mut result = mapped.to_vec();
        for ((a, b), coefficient) in self
            .entries
            .iter()
            .zip(self.entries.iter().skip(1))
            .zip(coefficients)
        {
            for (out, (new, old)) in result.iter_mut().zip(b.mapped.iter().zip(&a.mapped)) {
                *out -= coefficient * (new - old);
            }
        }
        result.iter().all(|v| v.is_finite()).then_some(result)
    }
}

// Column-pivoted, twice-orthogonalized QR. Dependent history directions are
// dropped; no regularization changes the physical constraint problem.
fn least_squares(mut columns: Vec<Vec<f64>>, rhs: &[f64]) -> Option<Vec<f64>> {
    let size = columns.len();
    if size == 0 {
        return None;
    }
    let mut permutation = (0..size).collect::<Vec<_>>();
    let mut upper = vec![0.0; size * size];
    let mut transformed = vec![0.0; size];
    let initial_norm = columns
        .iter()
        .map(|column| norm(column))
        .fold(0.0, f64::max);
    if initial_norm == 0.0 || !initial_norm.is_finite() {
        return None;
    }
    let mut rank = 0;
    for pivot in 0..size {
        let mut selected = pivot;
        for column in pivot + 1..size {
            if norm(&columns[column]) > norm(&columns[selected]) {
                selected = column;
            }
        }
        columns.swap(pivot, selected);
        permutation.swap(pivot, selected);
        for row in 0..pivot {
            upper.swap(row * size + pivot, row * size + selected);
        }
        let length = norm(&columns[pivot]);
        if length <= initial_norm * 1e-10 {
            break;
        }
        upper[pivot * size + pivot] = length;
        let basis = columns[pivot]
            .iter()
            .map(|value| value / length)
            .collect::<Vec<_>>();
        transformed[pivot] = dot(&basis, rhs);
        for column in pivot + 1..size {
            for _ in 0..2 {
                let component = dot(&basis, &columns[column]);
                upper[pivot * size + column] += component;
                for (value, axis) in columns[column].iter_mut().zip(&basis) {
                    *value -= component * axis;
                }
            }
        }
        rank += 1;
    }
    if rank == 0 {
        return None;
    }
    let mut solution = vec![0.0; size];
    for row in (0..rank).rev() {
        let remaining = (row + 1..rank)
            .map(|column| upper[row * size + column] * solution[column])
            .sum::<f64>();
        solution[row] = (transformed[row] - remaining) / upper[row * size + row];
    }
    let mut ordered = vec![0.0; size];
    for row in 0..rank {
        ordered[permutation[row]] = solution[row];
    }
    ordered.iter().all(|v| v.is_finite()).then_some(ordered)
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}
fn norm(values: &[f64]) -> f64 {
    values
        .iter()
        .fold(0.0_f64, |length, value| length.hypot(*value))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rank_deficient_history_is_reduced_without_modifying_its_least_squares_problem() {
        let columns = vec![
            vec![1.0, 2.0, 0.0],
            vec![2.0, 4.0, 0.0],
            vec![0.0, 0.0, 1.0],
        ];
        let solution = least_squares(columns.clone(), &[3.0, 6.0, 4.0]).unwrap();
        for (row, expected) in [3.0, 6.0, 4.0].into_iter().enumerate() {
            let actual = columns
                .iter()
                .zip(&solution)
                .map(|(column, coefficient)| column[row] * coefficient)
                .sum::<f64>();
            assert!((actual - expected).abs() < 1e-12);
        }
    }
}
