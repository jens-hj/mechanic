#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, hashlib, json, math, sys
from pathlib import Path

script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
for b in blocks:
    rows=sum(5 if r is not None else 3 for mus,muk,sliding,r in b[3])
    if not b[3] or rows!=len(b[0]) or rows!=len(b[1]) or rows!=len(b[2]):
        raise ValueError('reference requires complete contact-only blocks')
    cursor=0
    for mus,muk,sliding,r in b[3]:
        count=5 if r is not None else 3
        if not all(math.isfinite(c) and c>=0 for c in [mus,muk]+([r] if r is not None else [])):
            raise ValueError('invalid friction coefficients')
        if b[2][cursor]!=[0,math.inf] or any(bounds!=[-math.inf,math.inf] for bounds in b[2][cursor+1:cursor+count]):
            raise ValueError('reference requires unbounded unilateral contact laws')
        cursor+=count
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n)
if not np.all(np.isfinite(H)) or not np.all(np.isfinite(J)) or not np.allclose(H,H.T,rtol=0,atol=1e-12):
    raise ValueError('invalid dynamics')
np.linalg.cholesky(H)
W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
if not np.all(np.isfinite(y)):raise ValueError('invalid targets')
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e)
        # Preserve the small positive root and its derivative when a < 0.
        # Direct subtraction cancels both at late smoothing stages.
        p[k]=0.5*(a+root) if a>=0 else 0.5*e*(e/(root-a))
        P[k,k]=p[k]/root
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]


K=np.linalg.solve(H,J.T);normal_rows=np.array([k for k,mu,r in points]);count=len(points);width=n+count
work=0
def reduced(z,eps):
    if max(abs(z[n:]))>600:return None,None,None,None
    velocity=z[:n];normal=np.exp(z[n:]);slip=J@velocity-y
    lam=np.zeros(m);eta=np.zeros((m,count));dv=np.zeros((m,n));de=np.zeros(m)
    for index,(k,mu,r) in enumerate(points):
        load=normal[index];lam[k]=load;eta[k,index]=load
        for o,c in [(1,mu),(3,r)]:
            sl=slice(k+o,k+o+2);u=slip[sl];speed=np.linalg.norm(u);R=c*load;root=np.hypot(eps,R*speed);beta=R*R/(eps+root)
            lam[sl]=-beta*u;eta[sl,index]=lam[sl]*(1+eps/root);de[sl]=-eps/root*lam[sl]
            derivative=-beta*np.eye(2)
            if speed>0:
                unit=u/speed;derivative+=beta*(1-eps/root)*np.outer(unit,unit)
            dv[sl]=derivative@J[sl]
    F=np.r_[velocity-K@lam,slip[normal_rows]-eps/normal]
    A=np.block([[np.eye(n)-K@dv,-K@eta],[J[normal_rows],np.diag(eps/normal)]])
    E=np.r_[-K@de,-eps/normal]
    return F,A,E,lam
z=np.r_[np.zeros(n),np.full(count,np.log(10.))]
for eps in [1.,.1,.01,.001,.0001,.00001]:
    for it in range(64):
        F,A,E,lam=reduced(z,eps);norm=np.linalg.norm(F)
        if max(abs(F))<1e-10:break
        work+=1;pre=A.copy();pf=F.copy();pf[:n]=np.linalg.solve(A[:n,:n],F[:n]);pre[:n]=np.linalg.solve(A[:n,:n],A[:n]);row=np.max(abs(pre),axis=1);delta=np.linalg.lstsq(pre/row[:,None],-pf/row,rcond=1e-14)[0];best=(norm,z)
        for p in range(32):
            t=z+delta*.5**p;f,*_=reduced(t,eps)
            if f is None:continue
            merit=np.linalg.norm(f)
            if merit<best[0]:best=merit,t
            if merit<norm*(1-1e-4*.5**p):break
        if best[0]>=norm:break
        z=best[1]
    print('reduced_initial',eps,it,'residual',max(abs(reduced(z,eps)[0])),flush=True)
state=np.r_[z,np.log(eps)];previous=np.zeros(width+1);previous[-1]=-1;h=.5
for step in range(200):
    z=state[:-1];eps=np.exp(state[-1]);F,A,E,lam=reduced(z,eps);M=np.column_stack((A,E));M[:n]=np.linalg.solve(A[:n,:n],M[:n]);row=np.max(abs(M),axis=1)
    _,_,vt=np.linalg.svd(M/row[:,None],full_matrices=True);tangent=vt[-1]
    if tangent@previous<0:tangent=-tangent
    success=False
    for retry in range(12):
        predicted=state+h*tangent;trial=predicted.copy()
        for it in range(24):
            if abs(trial[-1])>100:break
            F,A,E,lam=reduced(trial[:-1],np.exp(trial[-1]))
            if F is None:break
            arc=tangent@(trial-predicted);res=np.r_[F,arc]
            if max(abs(F))<1e-10 and abs(arc)<1e-10:success=True;break
            work+=1;mat=np.vstack((np.column_stack((A,E)),tangent));mat[:n]=np.linalg.solve(A[:n,:n],mat[:n]);res[:n]=np.linalg.solve(A[:n,:n],res[:n]);rs=np.max(abs(mat),axis=1);delta=np.linalg.lstsq(mat/rs[:,None],-res/rs,rcond=1e-14)[0];norm=np.linalg.norm(res/rs);found=False
            for p in range(32):
                test=trial+delta*.5**p
                if abs(test[-1])>100:continue
                f,*_=reduced(test[:-1],np.exp(test[-1]))
                if f is None:continue
                f[:n]=np.linalg.solve(A[:n,:n],f[:n]);merit=np.linalg.norm(np.r_[f,tangent@(test-predicted)]/rs)
                if merit<norm:trial=test;found=True;break
            if not found:break
        if success:break
        h*=.5
    if not success:print('reduced_arc_failed',step,h,'work',work,flush=True);break
    state=trial;previous=tangent;F,A,E,x=reduced(state[:-1],np.exp(state[-1]));err=max(abs(original(x)[0]))
    print('reduced_arc',step,'epsilon',np.exp(state[-1]),'h',h,'newton',it,'work',work,'original',err,flush=True)
    args.output.write_text(repr(x.tolist()))
    if err<1e-9:break
    if it<5:h=min(2.,h*1.5)
