#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, hashlib, json, math, sys
from pathlib import Path

script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
for b in blocks:
    rows=sum(5 if r is not None else 3 for mus,muk,sliding,r in b[3])
    if not b[3] or rows!=len(b[0]) or rows!=len(b[1]) or rows!=len(b[2]):
        raise ValueError('reference requires complete contact-only blocks')
    cursor=0
    for mus,muk,sliding,r in b[3]:
        count=5 if r is not None else 3
        if not all(math.isfinite(c) and c>=0 for c in [mus,muk]+([r] if r is not None else [])):
            raise ValueError('invalid friction coefficients')
        if b[2][cursor]!=[0,math.inf] or any(bounds!=[-math.inf,math.inf] for bounds in b[2][cursor+1:cursor+count]):
            raise ValueError('reference requires unbounded unilateral contact laws')
        cursor+=count
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n)
if not np.all(np.isfinite(H)) or not np.all(np.isfinite(J)) or not np.allclose(H,H.T,rtol=0,atol=1e-12):
    raise ValueError('invalid dynamics')
np.linalg.cholesky(H)
W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
if not np.all(np.isfinite(y)):raise ValueError('invalid targets')
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e)
        # Preserve the small positive root and its derivative when a < 0.
        # Direct subtraction cancels both at late smoothing stages.
        p[k]=0.5*(a+root) if a>=0 else 0.5*e*(e/(root-a))
        P[k,k]=p[k]/root
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]


groups={}
for index,(k,mu,r) in enumerate(points):
    key=(tuple(J[k+3]),tuple(J[k+4]),y[k+3],y[k+4]);groups.setdefault(key,[]).append(index)
groups=list(groups.values());ids=[k+o for k,mu,r in points for o in [0,1,2]]+[points[g[0]][0]+o for g in groups for o in [3,4]]
Wr=W[np.ix_(ids,ids)];yr=y[ids];sr=scale[ids];mr=len(ids);print('aggregated_rows',mr,'rolling_groups',len(groups),flush=True)
def reduced_friction(x,eps):
    at=x+(yr-Wr@x)/sr;p=at.copy();P=np.zeros((mr,mr))
    def disk(k,c,dc,epsilon):
        sl=slice(k,k+2);v=at[sl];length=np.linalg.norm(v)
        if epsilon:
            e=epsilon/sr[k];root=np.hypot(length-c,e);den=.5*(c+length+root);dl=.5*(1+(length-c)/root);dr=1-dl
            p[sl]=v*c/den;P[sl,sl]=c/den*np.eye(2)-c/den**2*dl*np.outer(v,v)/max(length,1e-300)
            P[sl]+=np.outer(v*(1/den-c*dr/den**2),dc)
        elif length>c:
            u=v/length;p[sl]=u*c;P[sl,sl]=c/length*(np.eye(2)-np.outer(u,u));P[sl]+=np.outer(u,dc)
        else:P[sl,sl]=np.eye(2)
    for i,(old,mu,r) in enumerate(points):
        k=3*i;a=at[k];e=eps/sr[k]
        if eps:
            root=np.hypot(a,e);p[k]=.5*(a+root) if a>=0 else .5*e*(e/(root-a));P[k,k]=p[k]/root
        else:p[k]=max(0,a);P[k,k]=float(a>0)
        dc=np.zeros(mr);dc[k]=mu*P[k,k];disk(k+1,mu*p[k],dc,eps)
    for group,g in enumerate(groups):
        k=3*len(points)+2*group;c=sum(points[i][2]*p[3*i] for i in g);dc=np.zeros(mr)
        for i in g:dc[3*i]=points[i][2]*P[3*i,3*i]
        disk(k,c,dc,eps)
    return (x-p)*sr,(np.eye(mr)-P@(np.eye(mr)-Wr/sr[:,None]))*sr[:,None],p

def expand(x):
    full=np.zeros(m)
    for i,(k,mu,r) in enumerate(points):full[k:k+3]=x[3*i:3*i+3]
    for group,g in enumerate(groups):
        total=sum(points[i][2]*max(0,x[3*i]) for i in g);rolling=x[3*len(points)+2*group:3*len(points)+2*group+2]
        if total>0:
            for i in g:full[points[i][0]+3:points[i][0]+5]=rolling*(points[i][2]*max(0,x[3*i])/total)
    return full
for seed in ['zero','warm']:
    x=np.zeros(mr);work=0
    if seed=='warm':
        old=np.array(ast.literal_eval(Path('/private/tmp/mechanic-third-seed.ron').read_text()))
        for i,(k,mu,r) in enumerate(points):x[3*i:3*i+3]=old[k:k+3]
        for group,g in enumerate(groups):x[3*len(points)+2*group:3*len(points)+2*group+2]=sum((old[points[i][0]+3:points[i][0]+5] for i in g),np.zeros(2))
    print('seed',seed,flush=True)
    for eps in [max(1e-10,max(abs(y))*.01*.1**k) for k in range(10)]:
        for it in range(64):
            F,A,p=reduced_friction(x,eps);norm=np.linalg.norm(F)
            if max(abs(F))<max(1e-11,eps*.01):break
            work+=1;d=np.linalg.lstsq(A,-F,rcond=1e-14)[0];best=(norm,x)
            for power in range(32):
                trial=x+d*.5**power;f,*_=reduced_friction(trial,eps);merit=np.linalg.norm(f)
                if merit<best[0]:best=merit,trial
                if merit<norm*(1-1e-4*.5**power):break
            if best[0]>=norm:break
            x=best[1]
        candidate=expand(reduced_friction(x,0)[2]);err=max(abs(original(candidate)[0]));print('aggregate',eps,it,'work',work,'original',err,flush=True)
        args.output.with_suffix('.'+seed+'.ron').write_text(repr(candidate.tolist()))
        if err<1e-9:break
