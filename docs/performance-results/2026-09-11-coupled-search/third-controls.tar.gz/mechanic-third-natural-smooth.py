#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, json, math
from pathlib import Path

def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n); W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def natural(x):
    velocity=W@x-y; modified=velocity.copy(); T=np.eye(m)
    for k,mu,r in points:
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=velocity[sl]; length=np.sqrt(v@v+smoothing*smoothing)
            modified[k]+=c*length
            if length>0:T[k,sl]=c*v/length
    at=x-modified/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        disks=[(1,mu)]+([(3,r)] if r is not None else [])
        lengths=[np.linalg.norm(at[k+o:k+o+2]) for o,c in disks]
        candidates=[0.0]
        for mask in range(1<<len(disks)):
            chosen=[i for i in range(len(disks)) if mask>>i&1]
            candidates.append(max(0,(at[k]+sum(disks[i][1]*lengths[i] for i in chosen))/(1+sum(disks[i][1]**2 for i in chosen))))
        n=min(candidates,key=lambda n:(n-at[k])**2+sum(max(0,l-c*n)**2 for l,(o,c) in zip(lengths,disks)))
        p[k]=n
        if n==0:
            for o,c in disks:p[k+o:k+o+2]=0
            continue
        active=[i for i,(l,(o,c)) in enumerate(zip(lengths,disks)) if l>c*n]
        denominator=1+sum(disks[i][1]**2 for i in active); P[k,k]=1/denominator
        for i in active:
            o,c=disks[i]; P[k,k+o:k+o+2]=c*at[k+o:k+o+2]/lengths[i]/denominator
        for i,(o,c) in enumerate(disks):
            sl=slice(k+o,k+o+2)
            if i in active:
                u=at[sl]/lengths[i];p[sl]=u*c*n
                P[sl]=np.outer(c*u,P[k]);P[sl,sl]+=c*n/lengths[i]*(np.eye(2)-np.outer(u,u))
            else:P[sl,sl]=np.eye(2)
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-T@W/scale[:,None]))*scale[:,None]

for smoothing in [1e-2,1e-3,1e-4,1e-5,1e-6,1e-7,1e-8,1e-9,1e-10]:
    print('smooth',smoothing,flush=True)
    for iteration in range(32):
        F,A=natural(x); norm=np.linalg.norm(F)
        if iteration%10==0 or max(abs(F))<1e-9:print('iter',iteration,'natural',max(abs(F)),'original',max(abs(original(x)[0])),flush=True)
        if max(abs(original(x)[0]))<1e-10:break
        d=np.linalg.lstsq(A,-F,rcond=1e-14)[0];best=(norm,x)
        for power in range(32):
            trial=x+d*0.5**power;f,_=natural(trial);merit=np.linalg.norm(f)
            if merit<best[0]:best=merit,trial
            if merit<norm*(1-1e-4*0.5**power):break
        if best[0]>=norm:print('stalled',flush=True);break
        x=best[1]
print('final_original',max(abs(original(x)[0])),flush=True)
args.output.write_text(repr(x.tolist()))
