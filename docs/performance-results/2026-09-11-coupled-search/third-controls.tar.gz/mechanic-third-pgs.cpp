#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <algorithm>
#include <fstream>
int main(){
 int m,n;std::cin>>m>>n; std::vector<double> J(m*n),K(m*n),y(m),x(m),v(n);
 for(auto* a:{&J,&K,&y,&x})for(double& q:*a)std::cin>>q;
 int count;std::cin>>count;struct Point{int k;double mu,r,dn,dt,dr,s;};std::vector<Point>points(count);
 for(auto& p:points)std::cin>>p.k>>p.mu>>p.r>>p.dn>>p.dt>>p.dr>>p.s;
 auto recalc=[&](){std::fill(v.begin(),v.end(),0);for(int k=0;k<m;k++)for(int j=0;j<n;j++)v[j]+=K[k*n+j]*x[k];};recalc();
 auto gap=[&](int k){double q=-y[k];for(int j=0;j<n;j++)q+=J[k*n+j]*v[j];return q;};
 auto update=[&](int k,double q){double delta=q-x[k];x[k]=q;for(int j=0;j<n;j++)v[j]+=K[k*n+j]*delta;};
 for(int it=0;it<2000000;it++){
  for(auto p:points){
   int k=p.k;update(k,std::max(0.,x[k]-gap(k)/p.dn));
   for(int d=0;d<2;d++){int o=k+1+2*d;double rate=d?p.dr:p.dt,c=d?p.r:p.mu;
    double a=x[o]-gap(o)/rate,b=x[o+1]-gap(o+1)/rate,len=std::hypot(a,b),rad=c*x[k];
    double t=len>rad?rad/len:1;update(o,t*a);update(o+1,t*b);
   }
  }
  if(it%10000==0){recalc();double err=0;
   for(auto p:points){int k=p.k;double normal=std::max(0.,x[k]-gap(k)/p.s);err=std::max(err,std::abs(x[k]-normal)*p.s);
    for(int d=0;d<2;d++){int o=k+1+2*d;double c=d?p.r:p.mu,a=x[o]-gap(o)/p.s,b=x[o+1]-gap(o+1)/p.s,len=std::hypot(a,b),rad=c*normal,t=len>rad?rad/len:1;
     err=std::max({err,std::abs(x[o]-a*t)*p.s,std::abs(x[o+1]-b*t)*p.s});}
   }
   std::cout<<std::setprecision(17)<<it<<" "<<err<<std::endl;
   std::ofstream file("/private/tmp/mechanic-third-pgs.ron");file<<std::setprecision(17)<<"[";for(int k=0;k<m;k++)file<<(k?",":"")<<x[k];file<<"]";
   if(err<1e-11)break;
  }
 }
}
