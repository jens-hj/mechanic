#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, json, math
from pathlib import Path

def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n); W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e); p[k]=0.5*(a+root); P[k,k]=0.5*(1+a/root)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]


x=np.array(ast.literal_eval(Path('/private/tmp/mechanic-third-cone-qp.ron').read_text()));normals=np.array([k for k,mu,r in points]);best=(float('inf'),x.copy())
for cycle in range(64):
    for iteration in range(32):
        F,A=original(x);norm=np.linalg.norm(F);err=max(abs(F))
        if err<best[0]:best=err,x.copy();args.output.write_text(repr(x.tolist()))
        if err<1e-10:break
        d=np.linalg.lstsq(A,-F,rcond=1e-14)[0];candidate=(norm,x)
        for power in range(24):
            trial=x+0.5**power*d;f,_=original(trial);merit=np.linalg.norm(f)
            if merit<candidate[0]:candidate=merit,trial
            if merit<norm*(1-1e-4*0.5**power):break
        if candidate[0]>=norm:break
        x=candidate[1]
    print('cycle',cycle,'residual',max(abs(original(x)[0])),'best',best[0],flush=True)
    if best[0]<1e-10:break
    F,A=original(x);u,d,vt=np.linalg.svd(A);basis=vt[d<d[0]*1e-14];v=W@x-y
    options=[]
    for k in normals:
        if x[k]<1e-6 or v[k]<=1e-10:continue
        direction=-basis.T@basis[:,k]
        if direction[k]>=-1e-12:continue
        limits=[(-x[j]/direction[j],j) for j in normals if x[j]>1e-6 and direction[j]<-1e-12]
        alpha,limiter=min(limits);trial=x+alpha*direction
        f,_=original(trial);merit=np.linalg.norm(f)
        options.append((merit,limiter,trial,np.linalg.norm(A@direction),np.linalg.norm(J.T@direction)))
    if not options: print('no null direction',flush=True);break
    merit,limiter,x,linear,physical=min(options,key=lambda a:a[0])
    print('null boundary',limiter,'merit',merit,'linear',linear,'physical',physical,flush=True)
