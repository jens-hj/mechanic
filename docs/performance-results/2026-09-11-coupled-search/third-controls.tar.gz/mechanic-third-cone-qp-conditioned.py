#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, json, math
from pathlib import Path

def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n); W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e); p[k]=0.5*(a+root); P[k,k]=0.5*(1+a/root)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]


# Convex cone QP control with a De Saxce outer fixed point. Exact original
# residual is still the only success condition. Dense offline oracle only.
coeff=np.array([[mu,r] for k,mu,r in points]); assert all(r is not None for k,mu,r in points)
def cone(a):
    a=a.reshape(-1,5); lengths=np.stack((np.linalg.norm(a[:,1:3],axis=1),np.linalg.norm(a[:,3:5],axis=1)),axis=1)
    candidates=[np.zeros(len(a))]
    for mask in range(4):
        chosen=np.array([mask&1,(mask>>1)&1]); candidates.append(np.maximum(0,(a[:,0]+np.sum(coeff*lengths*chosen,axis=1))/(1+np.sum(coeff**2*chosen,axis=1))))
    candidates=np.array(candidates).T
    cost=(candidates-a[:,0,None])**2+np.sum(np.maximum(0,lengths[:,None,:]-candidates[:,:,None]*coeff[:,None,:])**2,axis=2)
    normal=candidates[np.arange(len(a)),np.argmin(cost,axis=1)]
    result=a.copy();result[:,0]=normal
    for disk,off in enumerate([1,3]):result[:,off:off+2]*=np.minimum(1,coeff[:,disk]*normal/np.maximum(lengths[:,disk],1e-300))[:,None]
    return result.ravel()
eigen,Q=np.linalg.eigh(W); rho=0.00001
z=cone(x); dual=x.copy(); correction=np.zeros(m)
for outer in range(40):
    inverse=1/(np.maximum(eigen,0)+rho)
    for inner in range(4000):
        x=Q@(inverse*(Q.T@(y-correction+rho*(z-dual))))
        old=z;relaxed=1.6*x-0.6*old;z=cone(relaxed+dual);dual+=relaxed-z
        primal=np.max(np.abs(x-z)); dr=rho*np.max(np.abs(z-old))
        if max(primal*rho,dr)<1e-12:break
    x=z.copy();args.output.write_text(repr(x.tolist()));velocity=W@x-y; err=max(abs(original(x)[0])); print('outer',outer,'inner',inner,'original',err,'velocity',max(abs(velocity)), 'primal',primal,'dual',dr,flush=True)
    if err<1e-10:break
    new=np.zeros(m)
    for k,mu,r in points:new[k]=mu*np.linalg.norm(velocity[k+1:k+3])+r*np.linalg.norm(velocity[k+3:k+5])
    correction=0.5*correction+0.5*new
args.output.write_text(repr(x.tolist()))
for eps in [1e-8,1e-9,1e-10,1e-11,0.0]:
    for iteration in range(64):
        F,A=smooth(x,eps) if eps else original(x); norm=np.linalg.norm(F)
        if max(abs(F))<1e-11:break
        d=np.linalg.lstsq(A,-F,rcond=1e-14)[0];best=(norm,x)
        for power in range(32):
            trial=x+0.5**power*d;f,_=smooth(trial,eps) if eps else original(trial);merit=np.linalg.norm(f)
            if merit<best[0]:best=merit,trial
            if merit<norm*(1-1e-4*0.5**power):break
        if best[0]>=norm:break
        x=best[1]
    print('polish',eps,iteration,'original',max(abs(original(x)[0])),flush=True)
args.output.with_suffix('.polished.ron').write_text(repr(x.tolist()))
