#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, json, math
from pathlib import Path

def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n); W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
full_J,full_y,full_W,full_scale,full_points=J.copy(),y.copy(),W.copy(),scale.copy(),points.copy()
seed=np.array(ast.literal_eval(Path('/private/tmp/mechanic-third-normal-seed.ron').read_text()))
def normal_support(held):
    normals=np.arange(0,len(full_y),5); matrix=full_W[np.ix_(normals,normals)]
    target=full_y[normals]-full_W[normals]@held
    lam=np.zeros(len(normals));v=np.zeros(len(normals));active=[]
    for _ in range(128):
        selected=int(np.argmax(target-v))
        if target[selected]-v[selected]<=1e-10:
            result=np.zeros(len(full_y));result[normals]=lam;return result
        while True:
            dual=np.linalg.solve(matrix[np.ix_(active,active)],matrix[active,selected]) if active else np.array([])
            direction=matrix[:,selected]-(matrix[:,active]@dual if active else 0)
            primal=(target[selected]-v[selected])/direction[selected] if direction[selected]>32*np.finfo(float).eps*matrix[selected,selected] else np.inf
            leaving=min(((lam[j]/d,i) for i,(j,d) in enumerate(zip(active,dual)) if d>0),default=(np.inf,None))
            step=min(primal,leaving[0])
            if not np.isfinite(step):raise ValueError('inconsistent normals')
            v+=step*direction;lam[active]-=step*dual;lam[selected]+=step
            if primal<=leaving[0]:active.append(selected);break
            lam[active[leaving[1]]]=0;del active[leaving[1]]
    raise ValueError('normal budget')
selected=[k for k,_,_ in points if seed[k]>0]
full_x=seed.copy()
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e); p[k]=0.5*(a+root); P[k,k]=0.5*(1+a/root)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]

for outer in range(12):
    indices=np.array([k+i for k in selected for i in range(5)])
    J=full_J[indices];y=full_y[indices];W=full_W[np.ix_(indices,indices)];scale=full_scale[indices];m=len(indices)
    points=[(5*i,full_points[k//5][1],full_points[k//5][2]) for i,k in enumerate(selected)]
    x=full_x[indices]
    print('outer',outer,'selected',selected,flush=True)
    for eps in [max(1e-10, max(abs(y))*0.01*0.1**k) for k in range(10)]:
        for it in range(32):
            F,A=smooth(x,eps); norm=np.linalg.norm(F)
            if max(abs(F))<max(1e-11,eps*0.01):break
            d=np.linalg.lstsq(A,-F,rcond=1e-14)[0]; best=(norm,x)
            for power in range(32):
                trial=x+d*0.5**power; f,_=smooth(trial,eps); merit=np.linalg.norm(f)
                if merit<best[0]: best=merit,trial
                if merit<norm*(1-1e-4*0.5**power):break
            if best[0]>=norm:break
            x=best[1]
        print('eps',eps,'iterations',it,'res',max(abs(smooth(x,eps)[0])),'original',max(abs(original(x)[0])),flush=True)

    full_x=np.zeros(len(full_y));full_x[indices]=x
    J,y,W,scale,points=full_J,full_y,full_W,full_scale,full_points;m=len(full_y)
    residual=max(abs(evaluate(full_x)[0])); print('all_original_residual',residual,flush=True)
    if residual<1e-9:break
    slack=W@full_x-y
    held=full_x.copy();held[::5]=0
    normal=normal_support(held)
    selected=[k for k,_,_ in points if normal[k]>0]
    full_x=held+normal
    for k,mu,r in points:
        if normal[k]==0:full_x[k:k+5]=0
args.output.write_text(repr(full_x.tolist()))
