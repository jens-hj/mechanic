#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, hashlib, json, math, sys
from pathlib import Path

script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
for b in blocks:
    rows=sum(5 if r is not None else 3 for mus,muk,sliding,r in b[3])
    if not b[3] or rows!=len(b[0]) or rows!=len(b[1]) or rows!=len(b[2]):
        raise ValueError('reference requires complete contact-only blocks')
    cursor=0
    for mus,muk,sliding,r in b[3]:
        count=5 if r is not None else 3
        if not all(math.isfinite(c) and c>=0 for c in [mus,muk]+([r] if r is not None else [])):
            raise ValueError('invalid friction coefficients')
        if b[2][cursor]!=[0,math.inf] or any(bounds!=[-math.inf,math.inf] for bounds in b[2][cursor+1:cursor+count]):
            raise ValueError('reference requires unbounded unilateral contact laws')
        cursor+=count
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n)
if not np.all(np.isfinite(H)) or not np.all(np.isfinite(J)) or not np.allclose(H,H.T,rtol=0,atol=1e-12):
    raise ValueError('invalid dynamics')
np.linalg.cholesky(H)
W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
if not np.all(np.isfinite(y)):raise ValueError('invalid targets')
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e)
        # Preserve the small positive root and its derivative when a < 0.
        # Direct subtraction cancels both at late smoothing stages.
        p[k]=0.5*(a+root) if a>=0 else 0.5*e*(e/(root-a))
        P[k,k]=p[k]/root
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]


K=np.linalg.solve(H,J.T);normal_rows=np.array([k for k,mu,r in points]);count=len(points);width=n+count
work=0
def reduced(z,eps):
    if max(abs(z[n:]))>600:return None,None,None,None
    velocity=z[:n];normal=np.exp(z[n:]);slip=J@velocity-y
    lam=np.zeros(m);eta=np.zeros((m,count));dv=np.zeros((m,n));de=np.zeros(m)
    for index,(k,mu,r) in enumerate(points):
        load=normal[index];lam[k]=load;eta[k,index]=load
        for o,c in [(1,mu),(3,r)]:
            sl=slice(k+o,k+o+2);u=slip[sl];speed=np.linalg.norm(u);R=c*load;root=np.hypot(eps,R*speed);beta=R*R/(eps+root)
            lam[sl]=-beta*u;eta[sl,index]=lam[sl]*(1+eps/root);de[sl]=-eps/root*lam[sl]
            derivative=-beta*np.eye(2)
            if speed>0:
                unit=u/speed;derivative+=beta*(1-eps/root)*np.outer(unit,unit)
            dv[sl]=derivative@J[sl]
    F=np.r_[velocity-K@lam,slip[normal_rows]-eps/normal]
    A=np.block([[np.eye(n)-K@dv,-K@eta],[J[normal_rows],np.diag(eps/normal)]])
    E=np.r_[-K@de,-eps/normal]
    return F,A,E,lam

x=np.array(ast.literal_eval(Path('/private/tmp/mechanic-third-reduced-elimination.ron').read_text()));z=np.r_[K@x,np.log(x[normal_rows])];eps=1.1601092766159224e-6
F,A,E,_=reduced(z,eps);d=np.random.default_rng(17).normal(size=width);d[:n]*=1e-5
for h in [1e-3,1e-4,1e-5,1e-6,1e-7]:
    plus=reduced(z+h*d,eps)[0];minus=reduced(z-h*d,eps)[0];actual=(plus-minus)/(2*h);expected=A@d
    print('direction',h,'absolute',max(abs(actual-expected)),'relative',np.linalg.norm(actual-expected)/np.linalg.norm(expected),flush=True)
    actual=(reduced(z,eps*np.exp(h))[0]-reduced(z,eps*np.exp(-h))[0])/(2*h)
    print('epsilon',h,'absolute',max(abs(actual-E)),'relative',np.linalg.norm(actual-E)/np.linalg.norm(E),flush=True)
