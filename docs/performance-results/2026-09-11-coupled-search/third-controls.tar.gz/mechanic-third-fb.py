#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, json, math
from pathlib import Path

def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n); W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e); p[k]=0.5*(a+root); P[k,k]=0.5*(1+a/root)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]


def fb(x,eps):
    velocity=W@x-y;at=x-velocity/scale;F=np.zeros(m);A=np.zeros((m,m))
    for k,mu,r in points:
        a=scale[k]*x[k];b=velocity[k];root=np.sqrt(a*a+b*b+2*eps*eps)
        den=root+a+b
        F[k]=2*(eps*eps-a*b)/den if den>0 else root-a-b
        da=-(b*b+2*eps*eps)/(root*(root+a)) if a>0 else a/root-1
        db=-(a*a+2*eps*eps)/(root*(root+b)) if b>0 else b/root-1
        A[k]=db*W[k];A[k,k]+=scale[k]*da
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2);v=at[sl];l=np.linalg.norm(v);radius=c*max(0,x[k]);e=eps/scale[k]
            root=np.hypot(l-radius,e);den=0.5*(radius+l+root);dl=0.5*(1+(l-radius)/root);dr=1-dl
            p=v*radius/den;P=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            E=np.eye(m)[sl];A[sl]=(E-P@(E-W[sl]/scale[k]))*scale[k]
            if x[k]>0:A[sl,k]-=v*c*(1/den-radius/den**2*dr)*scale[k]
            F[sl]=(x[sl]-p)*scale[k]
    return F,A
for seed in ['zero','admm']:
    x=np.zeros(m) if seed=='zero' else np.array(ast.literal_eval(Path('/private/tmp/mechanic-third-cone-qp-conditioned.polished.ron').read_text()))
    for eps in ([.01,.001,.0001,.00001,.000001,1e-7,1e-8,1e-9,1e-10] if seed=='zero' else [1e-7,1e-8,1e-9,1e-10]):
        for iteration in range(64):
            F,A=fb(x,eps);norm=np.linalg.norm(F)
            if max(abs(F))<max(1e-11,eps*.01):break
            d=np.linalg.lstsq(A,-F,rcond=1e-14)[0];best=(norm,x)
            for power in range(32):
                trial=x+d*0.5**power;f,_=fb(trial,eps);merit=np.linalg.norm(f)
                if merit<best[0]:best=merit,trial
                if merit<norm*(1-1e-4*0.5**power):break
            if best[0]>=norm:break
            x=best[1]
        print(seed,eps,iteration,'FB',max(abs(fb(x,eps)[0])),'original',max(abs(original(x)[0])),flush=True)
    args.output.with_suffix('.'+seed+'.ron').write_text(repr(x.tolist()))
