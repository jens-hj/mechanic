#!/usr/bin/env python3
"""Independent dense NumPy search reference; no physical tick or speed acceptance.

The runtime's 128-row response limit does not apply to this offline control.
The smoothed contact equations only generate candidates. Rust regressions then
check original normal, tangent and rolling laws independently of this script.
"""
import argparse
import numpy as np
import ast, json, math
from pathlib import Path

def read(node):
    if isinstance(node, (ast.List, ast.Tuple)): return [read(x) for x in node.elts]
    if isinstance(node, ast.Constant): return node.value
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub): return -read(node.operand)
    if isinstance(node, ast.Name): return {'inf': math.inf, 'true': True, 'false': False}[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Some' and len(node.args) == 1: return read(node.args[0])
    raise ValueError(ast.dump(node))


arguments=argparse.ArgumentParser()
arguments.add_argument('--fixture',type=Path,required=True)
arguments.add_argument('--output',type=Path,required=True)
args=arguments.parse_args()
mass,blocks=read(ast.parse(args.fixture.read_text(),mode='eval').body)
J=np.array([r for b in blocks for r in b[0]]); n=J.shape[1]; m=len(J)
H=np.array(mass).reshape(n,n); W=J@np.linalg.solve(H,J.T)
y=np.array([t for b in blocks for t in b[1]])
scale=np.zeros(m); points=[]; k=0
for b in blocks:
    size=len(b[1]); scale[k:k+size]=np.max(np.sum(np.abs(W[k:k+size,k:k+size]),axis=1))
    for mus,muk,sliding,rolling in b[3]:
        points.append((k,muk if sliding else mus,rolling)); k+=5 if rolling is not None else 3

def evaluate(x):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.eye(m)
    for k,mu,r in points:
        p[k]=max(at[k],0); P[k,k]=float(at[k]>0)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; length=np.linalg.norm(v); radius=c*p[k]
            if length>radius:
                u=v/length; p[sl]=u*radius
                P[sl,sl]=radius/length*(np.eye(2)-np.outer(u,u)); P[sl,k]=c*u*P[k,k]
    F=(x-p)*scale
    A=(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]
    return F,A
x=np.zeros(m)
original=evaluate

def smooth(x,epsilon):
    at=x+(y-W@x)/scale; p=at.copy(); P=np.zeros((m,m))
    for k,mu,r in points:
        e=epsilon/scale[k]; a=at[k]; root=np.hypot(a,e); p[k]=0.5*(a+root); P[k,k]=0.5*(1+a/root)
        for offset,c in [(1,mu)]+([(3,r)] if r is not None else []):
            sl=slice(k+offset,k+offset+2); v=at[sl]; l=np.linalg.norm(v); radius=c*p[k]
            root=np.hypot(l-radius,e); den=0.5*(radius+l+root); dl=0.5*(1+(l-radius)/root); dr=1-dl
            p[sl]=v*radius/den
            P[sl,sl]=radius/den*np.eye(2)-radius/den**2*dl*np.outer(v,v)/max(l,1e-300)
            P[sl,k]=v*c*(1/den-radius/den**2*dr)*P[k,k]
    return (x-p)*scale,(np.eye(m)-P@(np.eye(m)-W/scale[:,None]))*scale[:,None]


def hull(points):
    order=sorted(range(len(points)),key=lambda i:tuple(points[i]))
    def cross(i,j,k):
        a=points[j]-points[i];b=points[k]-points[i];return a[0]*b[1]-a[1]*b[0]
    def half(order):
        q=[]
        for i in order:
            while len(q)>=2 and cross(q[-2],q[-1],i)<=0:q.pop()
            q.append(i)
        return q
    return half(order)[:-1]+half(order[::-1])[:-1]
selected=[]
for group in range(4):
    starts=[p[0] for p in points[group*12:group*12+12]];a=J[starts]-J[starts[0]];u,d,v=np.linalg.svd(a,full_matrices=False);projected=a@v[:2].T;chosen=[starts[i] for i in hull(projected)];selected+=chosen;print('group',group,'singular',d,'hull',chosen,flush=True)
ids=[k+o for k in selected for o in range(5)]
x=np.zeros(m)
for eps in [max(1e-10,max(abs(y))*.01*.1**k) for k in range(10)]+[0]:
    for iteration in range(64):
        F,A=smooth(x,eps) if eps else original(x);F=F[ids];A=A[np.ix_(ids,ids)];norm=np.linalg.norm(F)
        if max(abs(F))<1e-11:break
        d=np.linalg.lstsq(A,-F,rcond=1e-14)[0];best=(norm,x)
        for power in range(32):
            trial=x.copy();trial[ids]+=0.5**power*d;f,_=smooth(trial,eps) if eps else original(trial);merit=np.linalg.norm(f[ids])
            if merit<best[0]:best=merit,trial
            if merit<norm*(1-1e-4*0.5**power):break
        if best[0]>=norm:break
        x=best[1]
    print('polish',eps,iteration,'subset',max(abs(original(x)[0][ids])),'original',max(abs(original(x)[0])),flush=True)
args.output.write_text(repr(x.tolist()))
