//! Coupled, implicit joint ticks. Collision and loop rows are added separately.

use bevy_math::DVec3;
use mechanic_core::{CompiledCreation, CoordinateDrive, DriveMode};

use crate::{
    ConstraintBlock, CpuSnapshot, ExternalImpulse, ImpulseBounds, MachineDynamics, MachineState,
    PhysicsError, PreparedConstraints, TICK_SECONDS,
    free_motion::{advance_positions, apply_external_impulses},
    joint_forces::{PassiveForce, drive_budget, drive_target, validate_drive},
};

/// Tick-indexed replacement of one resolved actuator row (including gearing).
#[derive(Clone, Copy, Debug)]
pub struct DriveCommand {
    /// External tick that consumes the command.
    pub tick: u64,
    /// Generation identifying the coordinate rows.
    pub topology_generation: u64,
    /// Compiled joint coordinate.
    pub coordinate: usize,
    /// Resolved drive target, effort envelope, and authored coordinate limits.
    pub drive: CoordinateDrive,
}

/// Fixed quality bounds. Retry uses successively finer subdivisions, never frame time.
#[derive(Clone, Copy, Debug)]
pub struct JointTickSettings {
    /// Initial subdivisions of the external 60 Hz tick: 1, 2, 4, or 8.
    pub substeps: u32,
    /// Maximum subdivisions permitted during unpublished retries.
    pub maximum_substeps: u32,
    /// Bound on implicit spring/damper fixed-point updates per substep.
    pub force_iterations: usize,
    /// Bound on coupled projected constraint sweeps per force update.
    pub constraint_iterations: usize,
    /// Generalized velocity residual tolerance in SI coordinate units per second.
    pub tolerance: f64,
}

impl Default for JointTickSettings {
    fn default() -> Self {
        Self {
            substeps: 1,
            maximum_substeps: 8,
            force_iterations: 128,
            constraint_iterations: 256,
            tolerance: 1e-8,
        }
    }
}

/// Work and convergence for the most recent attempted external joint tick.
#[derive(Clone, Debug, Default)]
pub struct JointTickDiagnostics {
    /// Whether the candidate passed and was published.
    pub published: bool,
    /// Number of attempted subdivision policies, including the successful one.
    pub attempts: u32,
    /// Last attempted (or accepted) subdivision count.
    pub substeps: u32,
    /// Numerical factorizations, including external impulse preparation and retries.
    pub factorizations: usize,
    /// Response preparation applications across all attempts.
    pub response_preparation_solves: usize,
    /// Factor solves during constraint iteration/reconstruction across all attempts.
    pub constraint_factor_solves: usize,
    /// RHS and physical-force residual factor applications, including retries.
    pub force_factor_solves: usize,
    /// Number of nonlinear force updates, including rejected attempts.
    pub force_iterations: usize,
    /// Total constraint sweeps, including rejected attempts.
    pub constraint_iterations: usize,
    /// Maximum final residual within the last attempt, in generalized velocity units.
    pub residual: f64,
    /// Signed drive impulses summed over the last attempt, in N·s or N·m·s.
    pub drive_impulses: Vec<f64>,
}

/// CPU joint runtime with coupled inertia, implicit passive forces, bounded
/// drives, and predictive inelastic stops. Tree joints are exact by reconstruction.
/// This API evaluates no terrain or body contacts and currently rejects loops;
/// it must not be selected as the application's complete physics backend.
pub struct CpuJointMachine {
    creation: CompiledCreation,
    passive: Vec<PassiveForce>,
    drives: Vec<CoordinateDrive>,
    completed: CpuSnapshot,
    diagnostics: JointTickDiagnostics,
}

impl CpuJointMachine {
    /// Loads compiled joint forces without changing authored construction state.
    ///
    /// # Errors
    /// Rejects loop topology, invalid numerical state/drives, out-of-travel initial
    /// coordinates, and the dense reference's capacity limit.
    pub fn new(
        creation: CompiledCreation,
        topology_generation: u64,
        mut state: MachineState,
    ) -> Result<Self, PhysicsError> {
        if !creation.dynamics.loops.is_empty() {
            return Err(PhysicsError::UnsupportedJointLoops);
        }
        let drives = creation.coordinate_drives.clone();
        if drives.len() != creation.dynamics.coordinate_bearings.len() {
            return Err(PhysicsError::InvalidDynamics);
        }
        for &drive in &drives {
            validate_drive(drive)?;
        }
        let model = MachineDynamics::assemble(&creation, &state.poses, &state.coordinates)?;
        model.body_motions(&state.velocities)?;
        model.factor(&vec![0.0; state.velocities.len()])?;
        validate_positions(&creation, &drives, &state)?;
        let passive = creation
            .dynamics
            .coordinate_bearings
            .iter()
            .map(|&row| PassiveForce::from_kind(creation.bearings[row].kind))
            .collect();
        state.poses = model.poses;
        Ok(Self {
            creation,
            passive,
            drives,
            completed: CpuSnapshot {
                tick: 0,
                topology_generation,
                state,
            },
            diagnostics: JointTickDiagnostics::default(),
        })
    }

    /// Last complete state; a failed tick never mutates it.
    pub fn snapshot(&self) -> &CpuSnapshot {
        &self.completed
    }

    /// Last attempted tick's work, including unpublished retries.
    pub fn diagnostics(&self) -> &JointTickDiagnostics {
        &self.diagnostics
    }

    /// Advances one external tick, retrying only numerical non-convergence with
    /// bounded finer substeps. Every attempt restarts from the same post-command
    /// state. Resolved drive changes commit only with the completed snapshot.
    ///
    /// # Errors
    /// Rejects wrong tick/generation, duplicate drive coordinates, invalid settings,
    /// invalid drives/impulses, incompatible limits, and unconverged final attempts.
    pub fn step(
        &mut self,
        gravity: DVec3,
        settings: JointTickSettings,
        impulses: &[ExternalImpulse],
        commands: &[DriveCommand],
    ) -> Result<&CpuSnapshot, PhysicsError> {
        self.diagnostics = JointTickDiagnostics::default();
        let tick = self
            .completed
            .tick
            .checked_add(1)
            .ok_or(PhysicsError::InvalidCommand)?;
        if !gravity.is_finite()
            || !matches!(settings.substeps, 1 | 2 | 4 | 8)
            || !matches!(settings.maximum_substeps, 1 | 2 | 4 | 8)
            || settings.maximum_substeps < settings.substeps
            || settings.force_iterations == 0
            || settings.constraint_iterations == 0
            || !settings.tolerance.is_finite()
            || settings.tolerance <= 0.0
        {
            return Err(PhysicsError::InvalidConstraints);
        }
        if impulses.iter().any(|c| {
            c.tick != tick
                || c.topology_generation != self.completed.topology_generation
                || c.body >= self.creation.compounds.len()
                || !c.point.is_finite()
                || !c.impulse.is_finite()
        }) {
            return Err(PhysicsError::InvalidCommand);
        }
        let mut drives = self.drives.clone();
        let mut changed = vec![false; drives.len()];
        for command in commands {
            if command.tick != tick
                || command.topology_generation != self.completed.topology_generation
                || command.coordinate >= drives.len()
                || changed[command.coordinate]
            {
                return Err(PhysicsError::InvalidCommand);
            }
            validate_drive(command.drive)?;
            changed[command.coordinate] = true;
            drives[command.coordinate] = command.drive;
        }
        validate_positions(&self.creation, &drives, &self.completed.state)?;
        let mut initial = self.completed.state.clone();
        apply_external_impulses(&self.creation, &mut initial, impulses)?;
        self.diagnostics.factorizations += usize::from(!impulses.is_empty());
        let mut subdivisions = settings.substeps;
        loop {
            self.diagnostics.attempts += 1;
            self.diagnostics.substeps = subdivisions;
            self.diagnostics.residual = 0.0;
            self.diagnostics.drive_impulses = vec![0.0; drives.len()];
            let mut candidate = initial.clone();
            let mut result = Ok(());
            for _ in 0..subdivisions {
                result = substep(
                    &self.creation,
                    &self.passive,
                    &drives,
                    &mut candidate,
                    gravity,
                    TICK_SECONDS / f64::from(subdivisions),
                    settings,
                    &mut self.diagnostics,
                );
                if result.is_err() {
                    break;
                }
            }
            match result {
                Ok(()) => {
                    self.completed = CpuSnapshot {
                        tick,
                        topology_generation: self.completed.topology_generation,
                        state: candidate,
                    };
                    self.drives = drives;
                    self.diagnostics.published = true;
                    return Ok(&self.completed);
                }
                Err(PhysicsError::NotConverged) if subdivisions < settings.maximum_substeps => {
                    subdivisions *= 2;
                }
                Err(error) => return Err(error),
            }
        }
    }
}

fn bounds(creation: &CompiledCreation, drives: &[CoordinateDrive], coordinate: usize) -> [f64; 2] {
    let physical = creation.bearings[creation.dynamics.coordinate_bearings[coordinate]]
        .kind
        .bounds();
    [
        f64::from(physical[0].max(drives[coordinate].min_angle)),
        f64::from(physical[1].min(drives[coordinate].max_angle)),
    ]
}

fn validate_positions(
    creation: &CompiledCreation,
    drives: &[CoordinateDrive],
    state: &MachineState,
) -> Result<(), PhysicsError> {
    for (coordinate, &q) in state.coordinates.iter().enumerate() {
        let [lower, upper] = bounds(creation, drives, coordinate);
        if lower > upper || !q.is_finite() || q < lower - 1e-10 || q > upper + 1e-10 {
            return Err(PhysicsError::InvalidConstraints);
        }
    }
    Ok(())
}

#[allow(clippy::too_many_arguments, clippy::too_many_lines)] // One ordered numerical substep with explicit inputs and work accounting.
fn substep(
    creation: &CompiledCreation,
    passive: &[PassiveForce],
    drives: &[CoordinateDrive],
    state: &mut MachineState,
    gravity: DVec3,
    dt: f64,
    settings: JointTickSettings,
    diagnostics: &mut JointTickDiagnostics,
) -> Result<(), PhysicsError> {
    let model = MachineDynamics::assemble(creation, &state.poses, &state.coordinates)?;
    let size = state.velocities.len();
    let mut diagonal = vec![0.0; size];
    for (coordinate, &row) in creation.dynamics.coordinate_velocities.iter().enumerate() {
        diagonal[row] = passive[coordinate].implicit_diagonal(dt);
    }
    let factor = model.factor(&diagonal)?;
    diagnostics.factorizations += 1;
    let gravity = model.gravity_force(creation, gravity)?;
    let bias = model.inertial_bias(creation, &state.velocities)?;
    let base = (0..size)
        .map(|row| {
            model.mass_matrix[row * size..(row + 1) * size]
                .iter()
                .zip(&state.velocities)
                .map(|(h, v)| h * v)
                .sum::<f64>()
                + dt * (gravity[row] - bias[row])
        })
        .collect::<Vec<_>>();
    let mut blocks = Vec::new();
    let mut desired = Vec::new();
    let mut drive_indices = Vec::new();
    for (coordinate, &row) in creation.dynamics.coordinate_velocities.iter().enumerate() {
        let drive = drives[coordinate];
        let position = state.coordinates[coordinate];
        let [lower, upper] = bounds(creation, drives, coordinate);
        let mut add = |sign: f64, target: f64, minimum: f64, maximum: f64| {
            let mut jacobian = vec![0.0; size];
            jacobian[row] = sign;
            blocks.push(ConstraintBlock {
                jacobian: vec![jacobian],
                target: vec![0.0],
                bounds: vec![ImpulseBounds { minimum, maximum }],
                friction: None,
            });
            desired.push(target);
        };
        if lower.is_finite() {
            add(1.0, ((lower - position) / dt).min(0.0), 0.0, f64::INFINITY);
        }
        if upper.is_finite() {
            add(-1.0, ((position - upper) / dt).min(0.0), 0.0, f64::INFINITY);
        }
        if drive.mode != DriveMode::Passive {
            let target = drive_target(drive, position);
            let capacity = drive_budget(
                drive,
                f64::from(creation.loop_topology.coordinate_axis_inertia[coordinate]),
                state.velocities[row],
                target,
                dt,
            );
            if capacity.is_nan() || capacity < 0.0 {
                return Err(PhysicsError::InvalidDynamics);
            }
            if capacity > 0.0 {
                add(1.0, target, -capacity, capacity);
                drive_indices.push((coordinate, blocks.len() - 1));
            }
        }
    }
    let mut response = PreparedConstraints::new(&factor, &blocks)?;
    diagnostics.response_preparation_solves += response.preparation_factor_solves();
    let mut velocity = state.velocities.clone();
    let mut last_residual = f64::INFINITY;
    for _ in 0..settings.force_iterations {
        diagnostics.force_iterations += 1;
        let mut free = base.clone();
        for (coordinate, &row) in creation.dynamics.coordinate_velocities.iter().enumerate() {
            free[row] += diagonal[row] * velocity[row]
                + dt * passive[coordinate].force(
                    state.coordinates[coordinate] + dt * velocity[row],
                    velocity[row],
                );
        }
        factor.solve(&mut free)?;
        diagnostics.force_factor_solves += 1;
        let targets = blocks
            .iter()
            .zip(&desired)
            .map(|(block, target)| {
                target
                    - block.jacobian[0]
                        .iter()
                        .zip(&free)
                        .map(|(j, v)| j * v)
                        .sum::<f64>()
            })
            .collect::<Vec<_>>();
        let solution = response.solve(
            &targets,
            settings.constraint_iterations,
            settings.tolerance * 0.1,
        )?;
        diagnostics.constraint_factor_solves += solution.factor_solves;
        diagnostics.constraint_iterations += solution.iterations;
        if !solution.converged {
            diagnostics.residual = diagnostics.residual.max(solution.residual);
            return Err(PhysicsError::NotConverged);
        }
        let next = free
            .iter()
            .zip(&solution.velocity_change)
            .map(|(v, d)| v + d)
            .collect::<Vec<_>>();
        // Check the actual implicit force equation, not merely iterate change.
        let mut error = vec![0.0; size];
        // H_eff*v_new used D*v_old + dt*F(v_old). The physical momentum
        // residual is D*(v_old-v_new) + dt*(F(v_old)-F(v_new)).
        for (coordinate, &row) in creation.dynamics.coordinate_velocities.iter().enumerate() {
            let actual = passive[coordinate]
                .force(state.coordinates[coordinate] + dt * next[row], next[row]);
            let previous = passive[coordinate].force(
                state.coordinates[coordinate] + dt * velocity[row],
                velocity[row],
            );
            error[row] = diagonal[row] * (velocity[row] - next[row]) + dt * (previous - actual);
        }
        factor.solve(&mut error)?;
        diagnostics.force_factor_solves += 1;
        let residual = error
            .iter()
            .map(|v| v.abs())
            .fold(solution.residual, f64::max);
        velocity = next;
        if residual <= settings.tolerance {
            diagnostics.residual = diagnostics.residual.max(residual);
            for (coordinate, index) in drive_indices {
                diagnostics.drive_impulses[coordinate] += solution.impulses[index];
            }
            state.velocities = velocity;
            advance_positions(creation, state, dt);
            if validate_positions(creation, drives, state).is_err() {
                return Err(PhysicsError::NotConverged);
            }
            let final_model =
                MachineDynamics::assemble(creation, &state.poses, &state.coordinates)?;
            final_model.body_motions(&state.velocities)?;
            state.poses = final_model.poses;
            return Ok(());
        }
        last_residual = residual;
    }
    diagnostics.residual = diagnostics.residual.max(last_residual);
    Err(PhysicsError::NotConverged)
}

#[cfg(test)]
mod tests;
