use super::*;

type RecordedBlock = (
    Vec<Vec<f64>>,
    Vec<f64>,
    Vec<(f64, f64)>,
    Vec<(f64, f64, bool, Option<f64>)>,
);

#[test]
fn captured_cold_car_impact_converges_without_relaxing_its_velocity_residual() {
    let (mass, recorded): (Vec<f64>, Vec<RecordedBlock>) =
        ron::from_str(include_str!("fixtures/cold_car_impact.ron")).unwrap();
    let blocks = recorded
        .into_iter()
        .map(|(jacobian, target, bounds, contacts)| ConstraintBlock {
            jacobian,
            target,
            bounds: bounds
                .into_iter()
                .map(|(minimum, maximum)| ImpulseBounds { minimum, maximum })
                .collect(),
            contacts: contacts
                .into_iter()
                .map(
                    |(static_coefficient, kinetic_coefficient, sliding, rolling_length)| {
                        ContactFriction {
                            static_coefficient,
                            kinetic_coefficient,
                            sliding,
                            rolling_length,
                        }
                    },
                )
                .collect(),
        })
        .collect::<Vec<_>>();
    let factor = DynamicsFactor::new(&mass, blocks[0].jacobian[0].len()).unwrap();
    let solution = solve_constraints(&factor, &blocks, 256, 1e-9).unwrap();
    let prepared = PreparedConstraints::new(&factor, &blocks).unwrap();
    for (block, layout) in blocks.iter().zip(&prepared.layout) {
        let raw = block.jacobian.iter().zip(&block.target).map(|(row,target)| target-dot(row, &solution.velocity_change)).collect::<Vec<_>>();
        println!("block scale={:e} raw={raw:?}",layout.scale);
    }
    let extended = solve_constraints(&factor, &blocks, 8192, 1e-9).unwrap();
    println!("captured_impact bounded={solution:?}\nextended={extended:?}");
    assert!(solution.converged, "residual={:e}", solution.residual);
}
