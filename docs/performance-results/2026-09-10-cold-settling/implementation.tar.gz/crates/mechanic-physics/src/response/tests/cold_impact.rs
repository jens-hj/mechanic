use super::*;

type RecordedBlock = (
    Vec<Vec<f64>>,
    Vec<f64>,
    Vec<(f64, f64)>,
    Vec<(f64, f64, bool, Option<f64>)>,
);

#[test]
fn captured_cold_car_impact_converges_without_relaxing_its_velocity_residual() {
    let (mass, recorded): (Vec<f64>, Vec<RecordedBlock>) =
        ron::from_str(include_str!("fixtures/cold_car_impact.ron")).unwrap();
    let blocks = blocks(recorded);
    let factor = DynamicsFactor::new(&mass, blocks[0].jacobian[0].len()).unwrap();
    let solution = solve_constraints(&factor, &blocks, 256, 1e-9).unwrap();
    assert!(solution.converged, "residual={:e}", solution.residual);
    assert!(solution.residual <= 1e-9);
    assert!(solution.iterations <= 256);
    // Independently check every original contact, including the inactive
    // hypothesis. No normal row may be hidden by the trial's temporary bound.
    let mut first = 0;
    for block in &blocks {
        let mut row = 0;
        for contact in &block.contacts {
            let normal = solution.impulses[first + row];
            let slack = dot(&block.jacobian[row], &solution.velocity_change) - block.target[row];
            assert!(normal >= 0.0 && slack >= -1e-9);
            if normal > 0.0 {
                assert!(slack.abs() <= 1e-9);
            }
            let tangent =
                solution.impulses[first + row + 1].hypot(solution.impulses[first + row + 2]);
            assert!(tangent <= contact.kinetic_coefficient * normal + 1e-12);
            if let Some(length) = contact.rolling_length {
                let rolling =
                    solution.impulses[first + row + 3].hypot(solution.impulses[first + row + 4]);
                assert!(rolling <= length * normal + 1e-12);
            }
            row += contact.rows();
        }
        first += block.target.len();
    }
    let repeated = solve_constraints(&factor, &blocks, 256, 1e-9).unwrap();
    assert_eq!(solution.impulses, repeated.impulses);
    assert_eq!(solution.velocity_change, repeated.velocity_change);
    println!(
        "captured_impact residual={:e} iterations={} inactive_trials={}",
        solution.residual, solution.iterations, solution.active_set_trials
    );
}

fn blocks(recorded: Vec<RecordedBlock>) -> Vec<ConstraintBlock> {
    recorded
        .into_iter()
        .map(|(jacobian, target, bounds, contacts)| ConstraintBlock {
            jacobian,
            target,
            bounds: bounds
                .into_iter()
                .map(|(minimum, maximum)| ImpulseBounds { minimum, maximum })
                .collect(),
            contacts: contacts
                .into_iter()
                .map(
                    |(static_coefficient, kinetic_coefficient, sliding, rolling_length)| {
                        ContactFriction {
                            static_coefficient,
                            kinetic_coefficient,
                            sliding,
                            rolling_length,
                        }
                    },
                )
                .collect(),
        })
        .collect::<Vec<_>>()
}

#[test]
fn a_wrong_inactive_contact_trial_is_discarded_without_losing_the_original_solution() {
    let (lower, recorded, initial): (Vec<f64>, Vec<RecordedBlock>, Option<Vec<f64>>) =
        ron::from_str(include_str!("fixtures/rejected_contact_trial.ron")).unwrap();
    let blocks = blocks(recorded);
    let size = blocks[0].jacobian[0].len();
    assert_eq!(lower.len(), size * size);
    let factor = DynamicsFactor { size, lower };
    let targets = blocks
        .iter()
        .flat_map(|b| b.target.clone())
        .collect::<Vec<_>>();
    let mut response = PreparedConstraints::new(&factor, &blocks).unwrap();
    let original = response
        .solve_with_contact_trial(&targets, initial.as_deref(), 256, 1e-9, false)
        .unwrap();
    let actual = response
        .solve_from(&targets, initial.as_deref(), 256, 1e-9)
        .unwrap();
    println!("rejected_trial original={original:?} actual={actual:?}");
    assert!(original.converged && actual.converged);
    assert!(actual.active_set_trial_rejections > 0);
    assert!(actual.iterations <= 256);
    for (a, b) in actual.velocity_change.iter().zip(&original.velocity_change) {
        assert!((a - b).abs() < 1e-8);
    }
}
