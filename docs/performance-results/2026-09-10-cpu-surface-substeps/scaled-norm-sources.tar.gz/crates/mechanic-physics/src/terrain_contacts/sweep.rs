//! Conservative advancement along a reconstructed articulated trajectory.

use super::{MachineCollisionGeometry, TerrainContactScene, valid_bounds};
use crate::{MachineMotion, PhysicsError};
use bevy_math::{DVec3, Vec3};
use mechanic_world::{TerrainNodeId, WorldBounds, WorldPosition};

/// First finite triangle approached by a certified candidate path.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TerrainSweepHit {
    /// Collider row within the query's topology generation.
    pub collider: usize,
    /// Owning terrain chunk.
    pub node: TerrainNodeId,
    /// Triangle row in the chunk's immutable BVH.
    pub triangle: usize,
    /// Candidate motion fraction, in [0, 1].
    pub fraction: f64,
    /// Signed SAT gap at this fraction, in metres.
    pub separation: f64,
}

/// Continuous query result. Unconverged work is never interpreted as clear space.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum TerrainSweepOutcome {
    /// Every candidate was certified separated for the entire path.
    Clear,
    /// Earliest approach within the requested geometric tolerance.
    Impact(TerrainSweepHit),
    /// At least one candidate exhausted its work/progress bound. Its path
    /// remainder is uncertified; retry or retain the last valid snapshot.
    Unconverged(TerrainSweepHit),
}

/// Tagged continuous query and actual work, including failed advancement.
#[derive(Clone, Debug)]
pub struct TerrainSweepQuery {
    /// Continuous result, which must be checked before accepting the path.
    pub outcome: TerrainSweepOutcome,
    /// Construction generation used by the query.
    pub topology_generation: u64,
    /// Complete terrain publication used by the query.
    pub terrain_generation: u64,
    /// Chunk candidates across the swept collider bounds.
    pub chunk_candidates: usize,
    /// Exact finite triangles tested.
    pub triangle_candidates: usize,
    /// Whole-tree pose reconstructions; none assemble or factor inertia.
    pub pose_evaluations: usize,
    /// Separating-axis evaluations, including failed advancement work.
    pub separation_evaluations: usize,
}

impl TerrainContactScene {
    /// Sweeps every moving compiled collider along the exact generalized path.
    /// Bounds include ancestor rotation, root motion, and suspension extension.
    /// Existing touching geometry returns an impact at fraction zero; the tick
    /// solver must handle its support constraints before continuing the path.
    ///
    /// # Errors
    /// Rejects incompatible topology, invalid bounds/settings, or invalid geometry.
    #[allow(clippy::too_many_lines)] // Stable candidate order and explicit failed-work accounting.
    pub fn sweep(
        &self,
        machine: &MachineCollisionGeometry,
        motion: &MachineMotion<'_>,
        origin: DVec3,
        tolerance: f64,
        maximum_evaluations_per_triangle: usize,
    ) -> Result<TerrainSweepQuery, PhysicsError> {
        if machine.generation != motion.generation()
            || machine.bodies != motion.initial_poses().len()
            || !origin.is_finite()
            || !tolerance.is_finite()
            || tolerance <= 0.0
            || maximum_evaluations_per_triangle == 0
        {
            return Err(PhysicsError::InvalidCollision);
        }
        let mut query = TerrainSweepQuery {
            outcome: TerrainSweepOutcome::Clear,
            topology_generation: machine.generation,
            terrain_generation: self.generation,
            chunk_candidates: 0,
            triangle_candidates: 0,
            pose_evaluations: 0,
            separation_evaluations: 0,
        };
        let mut earliest: Option<TerrainSweepHit> = None;
        for (collider_row, collider) in machine.colliders.iter().enumerate() {
            if !collider.moving {
                continue;
            }
            let bound = motion.bounds()[collider.body];
            let reach = bound.origin_speed + collider.radius + tolerance;
            let center = origin + motion.initial_poses()[collider.body].position;
            let bounds = WorldBounds {
                minimum: WorldPosition(center - DVec3::splat(reach)),
                maximum: WorldPosition(center + DVec3::splat(reach)),
            };
            if !valid_bounds(bounds) {
                return Err(PhysicsError::InvalidCollision);
            }
            let speed = bound.point_speed(collider.radius);
            if !speed.is_finite() {
                return Err(PhysicsError::InvalidCollision);
            }
            let chunks = self.index.bounds_candidates(bounds);
            query.chunk_candidates += chunks.len();
            for node in chunks {
                let chunk = &self.chunks[&node].geometry;
                for triangle_row in chunk.bounds_candidates(bounds) {
                    let triangle =
                        chunk.triangle_bvh.triangles[triangle_row]
                            .indices
                            .map(|index| {
                                chunk.origin.0 - origin
                                    + Vec3::from_array(chunk.vertices[index as usize]).as_dvec3()
                            });
                    if (triangle[1] - triangle[0])
                        .cross(triangle[2] - triangle[0])
                        .try_normalize()
                        .is_none()
                    {
                        continue;
                    }
                    query.triangle_candidates += 1;
                    let end = earliest.map_or(1.0, |hit| hit.fraction);
                    let mut fraction = 0.0;
                    for evaluation in 1..=maximum_evaluations_per_triangle {
                        let poses = motion.poses_at(fraction)?;
                        query.pose_evaluations += 1;
                        let pose = poses[collider.body];
                        let shape = collider
                            .local
                            .transformed(pose.position, pose.rotation)
                            .map_err(|_| PhysicsError::InvalidCollision)?;
                        let separation = shape
                            .triangle_separation(triangle)
                            .map_err(|_| PhysicsError::InvalidCollision)?;
                        query.separation_evaluations += 1;
                        let hit = TerrainSweepHit {
                            collider: collider_row,
                            node,
                            triangle: triangle_row,
                            fraction,
                            separation,
                        };
                        if separation <= tolerance {
                            if earliest.is_none_or(|previous| fraction < previous.fraction) {
                                earliest = Some(hit);
                            }
                            break;
                        }
                        if speed == 0.0 || separation > speed * (end - fraction) {
                            break;
                        }
                        let next = fraction + separation / speed;
                        if evaluation == maximum_evaluations_per_triangle || next <= fraction {
                            query.outcome = TerrainSweepOutcome::Unconverged(hit);
                            return Ok(query);
                        }
                        fraction = next.min(end);
                    }
                }
            }
        }
        query.outcome = earliest.map_or(TerrainSweepOutcome::Clear, TerrainSweepOutcome::Impact);
        Ok(query)
    }
}

#[cfg(test)]
mod tests;
