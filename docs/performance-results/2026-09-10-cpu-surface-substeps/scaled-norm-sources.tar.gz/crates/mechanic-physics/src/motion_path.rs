//! Exact tree trajectories and conservative motion bounds for continuous queries.

use bevy_math::DVec3;
use mechanic_core::CompiledCreation;

use crate::{
    BodyPose, MachineDynamics, MachineState, PhysicsError, free_motion::advance_positions,
};

/// Bounds on body-origin translation and angular motion per unit path fraction.
/// They include every ancestor joint, not just endpoint displacement.
#[derive(Clone, Copy, Debug, Default)]
pub struct MotionBound {
    /// Maximum speed of the body origin over the complete normalized path.
    pub origin_speed: f64,
    /// Maximum world angular speed over that path.
    pub angular_speed: f64,
}

impl MotionBound {
    /// Conservative speed of any point within `radius` of the body origin.
    pub fn point_speed(self, radius: f64) -> f64 {
        self.origin_speed + self.angular_speed * radius
    }
}

/// A candidate path specified by generalized displacements, including unwrapped
/// world root rotation and joint angles. Poses are reconstructed at every query;
/// this path never interpolates disconnected body endpoint poses.
/// It describes geometry only and neither integrates forces nor publishes state.
pub struct MachineMotion<'a> {
    pub(crate) creation: &'a CompiledCreation,
    initial: &'a MachineState,
    displacement: &'a [f64],
    generation: u64,
    start: Vec<BodyPose>,
    bounds: Vec<MotionBound>,
}

impl<'a> MachineMotion<'a> {
    /// Prepares the exact tree path and one root-before-child motion-bound pass.
    /// Generalized displacement uses the same row order as state velocities.
    ///
    /// # Errors
    /// Rejects loops, invalid state/dimensions, non-finite motion, or overflow.
    #[allow(clippy::too_many_lines)] // Root and joint bounds follow the same ordered reconstruction schedule.
    pub fn new(
        creation: &'a CompiledCreation,
        generation: u64,
        initial: &'a MachineState,
        displacement: &'a [f64],
    ) -> Result<Self, PhysicsError> {
        if !creation.dynamics.loops.is_empty() {
            return Err(PhysicsError::UnsupportedJointLoops);
        }
        if displacement.len() != creation.dynamics.elimination_parent.len()
            || displacement.iter().any(|value| !value.is_finite())
            || initial.velocities.len() != displacement.len()
        {
            return Err(PhysicsError::InvalidDynamics);
        }
        let start =
            MachineDynamics::reconstruct_poses(creation, &initial.poses, &initial.coordinates)?;
        let mut bounds = vec![MotionBound::default(); start.len()];
        for &body in &creation.dynamics.preorder {
            let topology = creation.loop_topology.body_parents[body];
            let rows = creation.dynamics.body_velocities[body].clone();
            if topology.is_root {
                if !rows.is_empty() {
                    let motion = &displacement[rows];
                    bounds[body] = MotionBound {
                        origin_speed: DVec3::new(motion[0], motion[1], motion[2]).length(),
                        angular_speed: DVec3::new(motion[3], motion[4], motion[5]).length(),
                    };
                }
                continue;
            }
            let parent = topology.parent_body as usize;
            let row = creation.dynamics.body_bearings[body].ok_or(PhysicsError::InvalidDynamics)?;
            let bearing = creation.bearings[row];
            let coordinate = bearing
                .coordinate_index
                .ok_or(PhysicsError::InvalidDynamics)? as usize;
            let change = displacement[rows.start].abs();
            let inherited = bounds[parent];
            let (parent_anchor, child_anchor, axis) = if topology.bearing_direction == 0 {
                (
                    bearing.local_anchor_a,
                    bearing.local_anchor_b,
                    bearing.local_axis_a,
                )
            } else {
                (
                    bearing.local_anchor_b,
                    bearing.local_anchor_a,
                    bearing.local_axis_b,
                )
            };
            if bearing.kind.is_translational() {
                let inverse = creation.compounds[parent]
                    .root_rotation
                    .as_dquat()
                    .inverse();
                let bind = inverse
                    * (creation.compounds[body].root_translation
                        - creation.compounds[parent].root_translation)
                        .as_dvec3();
                let extent = initial.coordinates[coordinate]
                    .abs()
                    .max((initial.coordinates[coordinate] + displacement[rows.start]).abs());
                let axis_length = axis.as_dvec3().length();
                let reach = bind.length() + extent * axis_length;
                bounds[body] = MotionBound {
                    origin_speed: inherited.origin_speed
                        + inherited.angular_speed * reach
                        + change * axis_length,
                    angular_speed: inherited.angular_speed,
                };
            } else {
                let child_reach = child_anchor.as_dvec3().length();
                let reach = parent_anchor.as_dvec3().length() + child_reach;
                bounds[body] = MotionBound {
                    origin_speed: inherited.origin_speed
                        + inherited.angular_speed * reach
                        + change * child_reach,
                    angular_speed: inherited.angular_speed + change,
                };
            }
        }
        if bounds
            .iter()
            .any(|bound| !bound.origin_speed.is_finite() || !bound.angular_speed.is_finite())
        {
            return Err(PhysicsError::InvalidDynamics);
        }
        let path = Self {
            creation,
            initial,
            displacement,
            generation,
            start,
            bounds,
        };
        path.poses_at(1.0)?;
        Ok(path)
    }

    /// Topology generation supplied with this candidate path.
    pub fn generation(&self) -> u64 {
        self.generation
    }

    /// Reconstructed poses at the beginning of the candidate path.
    pub fn initial_poses(&self) -> &[BodyPose] {
        &self.start
    }

    /// Body-indexed conservative motion bounds over the complete path.
    pub fn bounds(&self) -> &[MotionBound] {
        &self.bounds
    }

    /// Reconstructs all body poses at a normalized path fraction, without inertia.
    ///
    /// # Errors
    /// Rejects fractions outside [0, 1] and invalid reconstructed geometry.
    pub fn poses_at(&self, fraction: f64) -> Result<Vec<BodyPose>, PhysicsError> {
        if !fraction.is_finite() || !(0.0..=1.0).contains(&fraction) {
            return Err(PhysicsError::InvalidDynamics);
        }
        let mut state = self.initial.clone();
        state.velocities.copy_from_slice(self.displacement);
        advance_positions(self.creation, &mut state, fraction);
        MachineDynamics::reconstruct_poses(self.creation, &state.poses, &state.coordinates)
    }
}

#[cfg(test)]
mod tests;
