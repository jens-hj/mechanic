use super::*;
use bevy_math::IVec3;
use mechanic_core::{BuildCommand, BuildPose, ConstructionGraph, CuboidSpec, GridRotation};

fn bodies(count: i32) -> CompiledCreation {
    let mut graph = ConstructionGraph::new();
    for x in 0..count {
        graph
            .apply(BuildCommand::Spawn(
                CuboidSpec::new(
                    [1, 1, 1],
                    BuildPose::new(IVec3::new(x * 2, 0, 0), GridRotation::default()),
                )
                .unwrap(),
            ))
            .unwrap();
    }
    graph.compile().unwrap()
}

#[test]
fn full_root_rotation_is_preserved_between_matching_endpoint_orientations() {
    let creation = bodies(1);
    let initial = MachineState::at_rest(&creation);
    let mut displacement = vec![0.0; 6];
    displacement[5] = std::f64::consts::TAU;
    let motion = MachineMotion::new(&creation, 7, &initial, &displacement).unwrap();
    let start = motion.poses_at(0.0).unwrap()[0];
    let middle = motion.poses_at(0.5).unwrap()[0];
    let end = motion.poses_at(1.0).unwrap()[0];
    assert!((end.rotation.dot(start.rotation).abs() - 1.0).abs() < 1e-12);
    assert!((middle.rotation * DVec3::X).distance(start.rotation * -DVec3::X) < 1e-12);
    assert!((motion.bounds()[0].angular_speed - std::f64::consts::TAU).abs() < 1e-12);
    assert_eq!(motion.generation(), 7);
}

#[test]
fn pose_only_queries_are_not_limited_by_dense_inertia_capacity() {
    let creation = bodies(100);
    let initial = MachineState::at_rest(&creation);
    let displacement = vec![0.01; 600];
    let motion = MachineMotion::new(&creation, 1, &initial, &displacement).unwrap();
    assert_eq!(motion.poses_at(0.25).unwrap().len(), 100);
    assert!(matches!(
        MachineDynamics::assemble(&creation, &initial.poses, &[]),
        Err(PhysicsError::ReferenceCapacity)
    ));
}

#[test]
fn invalid_displacements_and_fractions_fail_without_changing_the_initial_state() {
    let creation = bodies(1);
    let initial = MachineState::at_rest(&creation);
    let expected = initial.clone();
    assert!(MachineMotion::new(&creation, 1, &initial, &[0.0; 5]).is_err());
    assert!(MachineMotion::new(&creation, 1, &initial, &[f64::NAN; 6]).is_err());
    let displacement = [0.0; 6];
    let motion = MachineMotion::new(&creation, 1, &initial, &displacement).unwrap();
    assert!(motion.poses_at(1.1).is_err());
    assert!(motion.poses_at(f64::NAN).is_err());
    assert_eq!(initial, expected);
}
