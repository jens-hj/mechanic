//! Derivatives valid only for one fixed Newton linearization and friction mode.

use super::{BlockLayout, ConstraintBlock};
use crate::{ContactFriction, ImpulseBounds};

pub(super) struct PointDerivative {
    pub block: usize,
    pub first: usize,
    pub size: usize,
    normal_active: bool,
    tangent: Option<DiskDerivative>,
    rolling: Option<DiskDerivative>,
}

impl PointDerivative {
    fn new(
        block: usize,
        first: usize,
        bounds: ImpulseBounds,
        contact: Option<(ContactFriction, bool)>,
        at: &[f64],
    ) -> Self {
        let normal = at[0].clamp(bounds.minimum, bounds.maximum);
        let normal_active = at[0] > bounds.minimum && at[0] < bounds.maximum;
        let Some((law, sliding)) = contact else {
            return Self {
                block,
                first,
                size: 1,
                normal_active,
                tangent: None,
                rolling: None,
            };
        };
        let coefficient = if sliding {
            law.kinetic_coefficient
        } else {
            law.static_coefficient
        };
        Self {
            block,
            first,
            size: law.rows(),
            normal_active,
            tangent: Some(DiskDerivative::new(
                &at[1..3],
                coefficient * normal,
                coefficient,
            )),
            rolling: law
                .rolling_length
                .map(|length| DiskDerivative::new(&at[3..5], length * normal, length)),
        }
    }

    pub fn apply(&self, input: &[f64], output: &mut [f64]) {
        let normal = if self.normal_active { input[0] } else { 0.0 };
        output[0] = normal;
        if let Some(tangent) = &self.tangent {
            tangent.apply(&input[1..3], normal, &mut output[1..3]);
        }
        if let Some(rolling) = &self.rolling {
            rolling.apply(&input[3..5], normal, &mut output[3..5]);
        }
    }
}

enum DiskDerivative {
    Inside,
    Outside {
        unit: [f64; 2],
        ratio: f64,
        coefficient: f64,
    },
    Apex,
}

impl DiskDerivative {
    fn new(at: &[f64], radius: f64, coefficient: f64) -> Self {
        let length = at[0].hypot(at[1]);
        if length < radius {
            Self::Inside
        } else if length > 0.0 {
            Self::Outside {
                unit: [at[0] / length, at[1] / length],
                ratio: radius / length,
                coefficient,
            }
        } else {
            Self::Apex
        }
    }

    fn apply(&self, input: &[f64], normal_derivative: f64, output: &mut [f64]) {
        match self {
            Self::Inside => output.copy_from_slice(input),
            Self::Outside {
                unit,
                ratio,
                coefficient,
            } => {
                let radius_derivative = coefficient * normal_derivative;
                let radial = unit[0] * input[0] + unit[1] * input[1];
                for row in 0..2 {
                    output[row] =
                        ratio * (input[row] - unit[row] * radial) + unit[row] * radius_derivative;
                }
            }
            Self::Apex => output.fill(0.0),
        }
    }
}

pub(super) fn prepare(
    blocks: &[ConstraintBlock],
    layout: &[BlockLayout],
    modes: &[Vec<bool>],
    at: &[f64],
) -> Vec<PointDerivative> {
    let mut result = Vec::new();
    for (block_index, ((block, info), modes)) in blocks.iter().zip(layout).zip(modes).enumerate() {
        let count = if block.contacts.is_empty() {
            block.jacobian.len()
        } else {
            block.contacts.len()
        };
        let mut first = 0;
        for point in 0..count {
            let law = block
                .contacts
                .get(point)
                .copied()
                .zip(modes.get(point).copied());
            let derivative = PointDerivative::new(
                block_index,
                info.first + first,
                block.bounds[first],
                law,
                &at[info.first + first..],
            );
            first += derivative.size;
            result.push(derivative);
        }
    }
    result
}
