//! Eliminate contact-space Newton motion into a bounded generalized system.
//!
//! With projection derivative P, row steps S and shift s, the Newton matrix is
//! A + P S J H^-1 J^T, where A = (1+s)I-P is point-block diagonal.
//! Solve (I + H^-1 J^T A^-1 P S J) dq = H^-1 J^T A^-1 rhs,
//! then recover every contact impulse. No global contact response is stored.

use super::{
    ConstraintBlock, DynamicsFactor, NewtonWork, apply_lu, factor_dense,
    projection::PointDerivative,
};

/// Bounds quadratic storage by generalized dimension; larger machines use Krylov.
pub(super) const MAXIMUM_COORDINATES: usize = 64;

pub(super) fn direction(
    factor: &DynamicsFactor,
    blocks: &[ConstraintBlock],
    derivatives: &[PointDerivative],
    steps: &[f64],
    rhs: &[f64],
    shift: f64,
) -> NewtonWork {
    let mut work = NewtonWork::default();
    work.direction = solve(factor, blocks, derivatives, steps, rhs, shift, &mut work);
    work
}

#[allow(clippy::too_many_arguments)] // The immutable linearization and explicit actual-work accumulator.
fn solve(
    factor: &DynamicsFactor,
    blocks: &[ConstraintBlock],
    derivatives: &[PointDerivative],
    steps: &[f64],
    rhs: &[f64],
    shift: f64,
    work: &mut NewtonWork,
) -> Option<Vec<f64>> {
    let size = factor.size;
    let rows = blocks
        .iter()
        .flat_map(|block| &block.jacobian)
        .collect::<Vec<_>>();
    let mut local_rhs = rhs.to_vec();
    let mut response = vec![0.0; rhs.len() * size];
    work.reduced_storage = response.len() + size * size;
    for point in derivatives {
        let width = point.size;
        let mut diagonal = vec![0.0; width * width];
        for column in 0..width {
            let mut input = [0.0; 5];
            let mut output = [0.0; 5];
            input[column] = 1.0;
            point.apply(&input[..width], &mut output[..width]);
            for row in 0..width {
                diagonal[row * width + column] =
                    (1.0 + shift) * f64::from(row == column) - output[row];
            }
        }
        work.local_factorizations += 1;
        let (matrix, pivots) = factor_dense(diagonal, width)?;
        apply_lu(
            &matrix,
            &pivots,
            &mut local_rhs[point.first..point.first + width],
        )?;
        for column in 0..size {
            let mut input = [0.0; 5];
            let mut output = [0.0; 5];
            for row in 0..width {
                input[row] = steps[point.first + row] * rows[point.first + row][column];
            }
            point.apply(&input[..width], &mut output[..width]);
            apply_lu(&matrix, &pivots, &mut output[..width])?;
            for row in 0..width {
                response[(point.first + row) * size + column] = output[row];
            }
        }
    }
    let mut matrix = vec![0.0; size * size];
    let mut scratch = vec![0.0; size];
    for column in 0..size {
        scratch.fill(0.0);
        for (row, jacobian) in rows.iter().enumerate() {
            for (out, j) in scratch.iter_mut().zip(*jacobian) {
                *out += j * response[row * size + column];
            }
        }
        work.factor_solves += 1;
        factor.solve(&mut scratch).ok()?;
        for row in 0..size {
            matrix[row * size + column] = scratch[row] + f64::from(row == column);
        }
    }
    scratch.fill(0.0);
    for (row, value) in rows.iter().zip(&local_rhs) {
        for (out, j) in scratch.iter_mut().zip(*row) {
            *out += j * value;
        }
    }
    work.factor_solves += 1;
    factor.solve(&mut scratch).ok()?;
    work.generalized_factorizations += 1;
    let (matrix, pivots) = factor_dense(matrix, size)?;
    apply_lu(&matrix, &pivots, &mut scratch)?;
    for (row, out) in local_rhs.iter_mut().enumerate() {
        *out -= response[row * size..(row + 1) * size]
            .iter()
            .zip(&scratch)
            .map(|(a, b)| a * b)
            .sum::<f64>();
    }
    local_rhs
        .iter()
        .all(|value| value.is_finite())
        .then_some(local_rhs)
}
