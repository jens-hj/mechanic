//! Unsmoothed rank-revealing Newton finishing, using the existing projection law.

use super::{BlockLayout, ConstraintBlock, Continuation, Problem, consider, dot, equations::{Evaluation, Local}, linear};

pub(super) fn polish(
    problem: &Problem<'_>, blocks: &[ConstraintBlock], layout: &[BlockLayout], modes: &[Vec<bool>],
    maximum_iterations: usize, tolerance: f64, result: &mut Continuation,
) {
    let Some(mut impulses) = result.impulses.clone() else { return; };
    while result.iterations < maximum_iterations && result.residual > tolerance {
        let at = evaluate(problem, blocks, layout, modes, &impulses, result);
        result.iterations += 1;
        let Some(direction) = linear::direction(problem, &at, true, None, &mut result.work) else { return; };
        let mut fraction = 1.0;
        let mut accepted = None;
        for _ in 0..32 {
            let mut candidate = impulses.iter().zip(&direction).map(|(x,d)| x + fraction * d).collect::<Vec<_>>();
            project(blocks, layout, modes, &mut candidate);
            let trial = evaluate(problem, blocks, layout, modes, &candidate, result);
            if trial.norm < at.norm * (1.0 - 1e-4 * fraction) {
                accepted = Some(candidate); break;
            }
            fraction *= 0.5;
        }
        let Some(candidate) = accepted else { return; };
        impulses = candidate;
        if consider(problem, blocks, layout, modes, &impulses, tolerance, result) { return; }
    }
}

fn project(blocks: &[ConstraintBlock], layout: &[BlockLayout], modes: &[Vec<bool>], x: &mut [f64]) {
    for ((block, info), modes) in blocks.iter().zip(layout).zip(modes) {
        super::super::super::super::project(block, modes, &mut x[info.first..info.first + block.target.len()]);
    }
}

fn evaluate(
    problem: &Problem<'_>, blocks: &[ConstraintBlock], layout: &[BlockLayout], modes: &[Vec<bool>],
    impulses: &[f64], result: &mut Continuation,
) -> Evaluation {
    result.evaluations += 1;
    result.work.applications += 1;
    let velocity = problem.motion(impulses);
    let at = impulses.iter().zip(&problem.rows).zip(&problem.targets).zip(&problem.scales)
        .map(|(((x,j),y),scale)| x + (y - dot(j,&velocity)) / scale).collect::<Vec<_>>();
    let derivatives = super::super::super::projection::prepare(blocks, layout, modes, &at);
    let mut projected = at;
    project(blocks, layout, modes, &mut projected);
    let residual = impulses.iter().zip(&projected).zip(&problem.scales).map(|((x,p),scale)| (x-p)*scale).collect::<Vec<_>>();
    let mut evaluation = Evaluation { locals: Vec::new(), maximum: residual.iter().map(|v| v.abs()).fold(0.0,f64::max), norm: residual.iter().fold(0.0_f64,|sum,v| sum.hypot(*v)), residual };
    for point in derivatives {
        let size = point.size;
        let first = point.first;
        let scale = problem.scales[first];
        let mut local = Local { first, size, matrix: vec![0.0;size*size], velocity: vec![0.0;size*problem.size], parameter: vec![0.0;size], rhs: evaluation.residual[first..first+size].iter().map(|r| -r).collect() };
        for column in 0..size {
            let mut unit = vec![0.0;size]; unit[column] = 1.0;
            let mut image = vec![0.0;size]; point.apply(&unit,&mut image);
            for row in 0..size {
                local.matrix[row*size+column] = scale*(f64::from(row==column)-image[row]);
                for axis in 0..problem.size {
                    local.velocity[row*problem.size+axis] += image[row]*problem.rows[first+column][axis];
                }
            }
        }
        evaluation.locals.push(local);
    }
    evaluation
}
