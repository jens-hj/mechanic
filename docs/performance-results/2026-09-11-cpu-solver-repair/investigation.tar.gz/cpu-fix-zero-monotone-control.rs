//! Bounded smoothing continuation proposes an impulse guess. It never substitutes
//! smoothed equations for the original contact residual or friction-mode proof.

use super::super::{BlockLayout, ConstraintBlock, DynamicsFactor, dot, response_motion};
use super::NewtonWork;
mod central;
mod mixed;
mod rank;
mod smoothing;
use smoothing::Evaluation;

#[derive(Default)]
pub(in crate::response) struct Continuation {
    pub impulses: Option<Vec<f64>>,
    pub residual: f64,
    pub iterations: usize,
    pub stages: usize,
    pub work: NewtonWork,
    pub evaluations: usize,
}

#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
pub(in crate::response) fn propose(
    factor: &DynamicsFactor,
    blocks: &[ConstraintBlock],
    layout: &[BlockLayout],
    modes: &[Vec<bool>],
    initial: &[f64],
    maximum_iterations: usize,
    tolerance: f64,
) -> Continuation {
    if blocks.iter().any(|block| block.contacts.is_empty()) {
        return central::propose(factor, blocks, layout, modes, maximum_iterations, tolerance);
    }
    let mut result = Continuation::default();
    if factor.size == 0
        || factor.size > 64
        || blocks.iter().any(|b| {
            b.contacts.is_empty()
                || b.contacts
                    .iter()
                    .scan(0, |row, c| {
                        let bounded = b.bounds[*row].maximum.is_finite();
                        *row += c.rows();
                        Some(bounded)
                    })
                    .any(|bounded| bounded)
        })
    {
        return result;
    }
    let rows = blocks.iter().flat_map(|b| &b.jacobian).collect::<Vec<_>>();
    let scales = blocks
        .iter()
        .zip(layout)
        .flat_map(|(b, info)| std::iter::repeat_n(info.scale, b.target.len()))
        .collect::<Vec<_>>();
    let mut impulses = vec![0.0; initial.len()];
    let Some((_, mut motion)) = response_motion(factor, &rows, &impulses).ok() else {
        return result;
    };
    result.work.factor_solves += 1;
    let mut epsilon = blocks
        .iter()
        .flat_map(|b| &b.target)
        .map(|v| v.abs())
        .fold(tolerance, f64::max)
        * 0.01;
    epsilon = epsilon.max(tolerance * 0.1);
    for _ in 0..32 {
        result.stages += 1;
        let mut stage_converged = false;
        let mut direction_failed = false;
        // Reserve the shared budget for branch following when a monotone stage
        // cannot settle promptly. Successful stages keep their original checks.
        for _ in 0..32 {
            result.evaluations += 1;
            let Some(at) = smoothing::evaluate(blocks, layout, modes, &impulses, &motion, epsilon)
            else {
                return result;
            };
            if at.maximum <= (epsilon * 0.01).max(tolerance * 0.01) {
                stage_converged = true;
                break;
            }
            if result.iterations == maximum_iterations {
                return result;
            }
            result.iterations += 1;
            let Some(direction) = mixed::direction(factor, &rows, &scales, &at, &mut result.work)
            else {
                direction_failed = true;
                break;
            };
            let mut fraction = 1.0;
            let mut accepted = false;
            for _ in 0..32 {
                result.evaluations += 1;
                let candidate = impulses
                    .iter()
                    .zip(&direction)
                    .map(|(a, b)| a + fraction * b)
                    .collect::<Vec<_>>();
                result.work.factor_solves += 1;
                if let Ok((_, change)) = response_motion(factor, &rows, &candidate)
                    && let Some(trial) =
                        smoothing::evaluate(blocks, layout, modes, &candidate, &change, epsilon)
                    && trial.norm < at.norm * (1.0 - 1e-4 * fraction)
                {
                    impulses = candidate;
                    motion = change;
                    accepted = true;
                    break;
                }
                fraction *= 0.5;
            }
            if !accepted {
                break;
            }
        }
        #[cfg(test)]
        if std::env::var_os("MECHANIC_TRACE_CONTINUATION").is_some() {
            eprintln!("smooth eps={epsilon:e} iterations={} converged={stage_converged} direction_failed={direction_failed}", result.iterations);
        }
        // End continuation as soon as the original nonsmooth laws pass. This
        // avoids spending further search stages on an already valid candidate.
        let mut candidate = impulses.clone();
        for ((block, info), mode) in blocks.iter().zip(layout).zip(modes) {
            super::super::project(
                block,
                mode,
                &mut candidate[info.first..info.first + block.target.len()],
            );
        }
        result.work.factor_solves += 1;
        if let Ok((_, rows_changed)) = response_motion(factor, &rows, &candidate)
            && let Ok(residual) = super::super::projected_residual(
                blocks,
                layout,
                &rows_changed,
                &candidate,
                modes,
                tolerance,
            )
        {
            if result.impulses.is_none() || residual < result.residual {
                result.impulses = Some(candidate);
                result.residual = residual;
            }
            if residual <= tolerance { return result; }
        }
        if !stage_converged && direction_failed {
            // Decreasing smoothing after an unconverged stage does not follow
            // a solution branch. Follow folds with a bordered path instead,
            // spending only the directions left in the caller's fixed budget.
            let trial = central::propose(
                factor,
                blocks,
                layout,
                modes,
                maximum_iterations - result.iterations,
                tolerance,
            );
            result.iterations += trial.iterations;
            result.stages += trial.stages;
            result.evaluations += trial.evaluations;
            result.work.applications += trial.work.applications;
            result.work.factor_solves += trial.work.factor_solves;
            result.work.local_factorizations += trial.work.local_factorizations;
            result.work.generalized_factorizations += trial.work.generalized_factorizations;
            result.work.reduced_storage =
                result.work.reduced_storage.max(trial.work.reduced_storage);
            result.work.mixed_rows = result.work.mixed_rows.max(trial.work.mixed_rows);
            if trial.impulses.is_some() && (result.impulses.is_none() || trial.residual < result.residual) {
                result.impulses = trial.impulses;
                result.residual = trial.residual;
            }
            return result;
        }
        if epsilon <= tolerance * 0.1 {
            return result;
        }
        epsilon = (epsilon * 0.1).max(tolerance * 0.1);
    }
    result
}
