mod hold;
mod terrain;
pub use hold::GpuHoldError;
pub use terrain::{
    GpuTerrainError, PreparedTerrainUpdate, TerrainPreparationCache, TerrainPreparationRequest,
    TerrainResidency, TerrainUploadStats,
};

use std::borrow::Cow;
use std::collections::{BTreeMap, BTreeSet};
use std::sync::{
    Mutex,
    atomic::{AtomicBool, AtomicU64, Ordering},
    mpsc,
};
use std::time::Instant;

use bevy_math::Vec3;
use bytemuck::{Pod, Zeroable, bytes_of, cast_slice};
use mechanic_core::{ColliderShape, CompiledCreation, ConstructionMaterial};
use thiserror::Error;
use wgpu::util::DeviceExt;

use crate::{
    BROADPHASE_HASH_CAPACITY, COLLIDER_SHAPE_CONVEX, COLLIDER_SHAPE_CUBOID, FIXED_DT_SECONDS,
    GpuBearing, GpuCollider, GpuContact, GpuContractionNode, GpuDiagnostics, GpuGroundSurface,
    GpuLinkState, GpuMass, GpuMechanismBody, GpuMechanismCoordinate, GpuMechanismDrive, GpuPair,
    GpuPersistentManifold, GpuSpatialInertia, GpuTickConfig, GpuTransform, GpuVelocity,
    MAX_BEARINGS, MAX_BODIES, MAX_COLLIDERS, MAX_CONTACT_PAIRS, MAX_CONVEX_SHAPE_SLOTS,
    SNAPSHOT_RING_SIZE, pack_convex_counts,
};

const FUSED_VELOCITY_BEARING_LIMIT: u32 = 64;
const FUSED_GROUND_CONTACT_BEARING_LIMIT: u32 = 64;
const FUSED_STREAMED_CONTACT_BEARING_LIMIT: u32 = 64;
const ASYNC_READBACK_RING_SIZE: usize = 12;

/// Number of external impulses staged and applied by one serial GPU pass.
pub const EXTERNAL_IMPULSE_BATCH_CAPACITY: usize = 64;

/// Per-scene pipeline switches that do not adapt during simulation.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct GpuPhysicsConfig {
    /// Whether broadphase, SAT, and projected contact impulses are dispatched.
    pub collisions_enabled: bool,
    /// Whether the explicit flat ground plane participates in collision.
    /// Garage and benchmark scenes opt into this; streamed worlds disable it.
    pub ground_plane_enabled: bool,
    /// Whether colliders in the same articulated mechanism may contact.
    pub mechanism_self_collisions: bool,
    /// Base number of projected impulse iterations. Small mechanisms with angle
    /// drives use at least 32 pre-integration velocity iterations; contact
    /// sweeps retain this configured count.
    pub solver_iterations: u32,
}

/// Immutable contact-solver schedule selected when a scene is uploaded.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GpuSolverRoute {
    /// Parallel contact projection with separate mechanism correction passes.
    General,
    /// One ordered dispatch for a small floating articulated mechanism.
    FusedSmallMechanism,
}

impl GpuSolverRoute {
    /// Stable diagnostic label used by benchmark JSONL.
    pub const fn name(self) -> &'static str {
        match self {
            Self::General => "general",
            Self::FusedSmallMechanism => "fused_small_mechanism",
        }
    }
}

impl Default for GpuPhysicsConfig {
    fn default() -> Self {
        Self {
            collisions_enabled: true,
            ground_plane_enabled: true,
            mechanism_self_collisions: true,
            solver_iterations: 8,
        }
    }
}

/// Device-local shader and compute-pipeline cache shared by replaceable scenes.
///
/// Scene buffers and bind groups remain owned by [`GpuPhysics`]; rebuilding a
/// topology with this cache only uploads those scene-specific resources.
#[derive(Debug, Default)]
pub struct GpuPhysicsPipelines {
    shaders: Mutex<BTreeMap<&'static str, wgpu::ShaderModule>>,
    pipelines: Mutex<BTreeMap<(&'static str, &'static str), wgpu::ComputePipeline>>,
}

impl GpuPhysicsPipelines {
    /// Creates an empty cache that compiles each embedded kernel lazily once.
    pub fn new() -> Self {
        Self::default()
    }
}

const fn uses_fused_velocity_schedule(bearing_count: u32, body_count: u32) -> bool {
    bearing_count <= FUSED_VELOCITY_BEARING_LIMIT && body_count <= 256
}

const fn uses_fused_contact_schedule(bearing_count: u32, ground_plane_enabled: bool) -> bool {
    // Keep contact and bearing projection tightly coupled for small mechanisms.
    // This is necessary for large body-to-wheel mass ratios: a parallel pass
    // can otherwise let the chassis outrun the wheel contacts before their
    // impulses propagate through the bearings. Both choices are immutable
    // after the scene is loaded.
    let limit = if ground_plane_enabled {
        FUSED_GROUND_CONTACT_BEARING_LIMIT
    } else {
        FUSED_STREAMED_CONTACT_BEARING_LIMIT
    };
    bearing_count <= limit
}

/// GPU buffers containing one complete renderable physics snapshot.
#[derive(Debug)]
pub struct SnapshotBuffers {
    positions: wgpu::Buffer,
    rotations: wgpu::Buffer,
}

impl SnapshotBuffers {
    /// Compound positions as tightly packed `vec4<f32>` rows.
    pub const fn positions(&self) -> &wgpu::Buffer {
        &self.positions
    }

    /// Compound orientations as tightly packed quaternion `vec4<f32>` rows.
    pub const fn rotations(&self) -> &wgpu::Buffer {
        &self.rotations
    }
}

/// Submitted tick identity. Completion is asynchronous on the shared queue.
#[derive(Debug)]
pub struct GpuTickSubmission {
    /// Contiguous submission ordinal, independent of scheduler tick gaps.
    pub submission_sequence: u64,
    /// Tick encoded into the submission.
    pub tick_index: u64,
    /// Snapshot ring destination written by that tick.
    pub snapshot_slot: u8,
    /// Shared queue submission token.
    pub submission_index: wgpu::SubmissionIndex,
    /// CPU wall-clock stage costs; these do not wait for GPU completion.
    pub cpu_timings: GpuSubmissionTimings,
}

/// Non-overlapping CPU wall-clock costs for encoding and submitting one tick.
/// Includes driver calls and any contention inside them, not just CPU execution.
/// External-impulse dispatches and later readback polling are outside these stages.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct GpuSubmissionTimings {
    /// Config upload, command encoding, and readback staging allocation/copies.
    pub encoding_ms: f64,
    /// Finishing the command encoder into a command buffer.
    pub finalization_ms: f64,
    /// Shared queue submission, including pending uploads and resource maintenance.
    pub submission_ms: f64,
    /// Registering asynchronous mapping callbacks, not waiting for their completion.
    pub readback_setup_ms: f64,
}

/// Validation values copied back after a tick without reading body state.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GpuTickReadback {
    /// Evidence written by the executing shaders, independent of scenario labels.
    pub execution: GpuExecutionEvidence,
    /// Timestamp-query duration, or `None` if the shared device lacks support.
    pub gpu_tick_ms: Option<f64>,
    /// Per-stage timestamp durations, or `None` without timestamp-query support.
    pub kernel_timings: Option<GpuKernelTimings>,
    /// Kernel failure flags. A non-zero value blocks publication.
    pub error_flags: u32,
    /// Broadphase candidates requested during the tick.
    pub pair_count: u32,
    /// SAT contacts requested during the tick.
    pub contact_count: u32,
    /// Contacts dispatched through the projected impulse iterations.
    pub active_contact_count: u32,
    /// Contact/bearing sweeps budgeted for the selected solver route.
    pub planned_solver_sweeps: u32,
    /// Contact/bearing sweeps executed by the selected solver route.
    pub executed_solver_sweeps: u32,
    /// Largest derived bearing anchor residual in metres.
    pub anchor_residual_meters: f32,
    /// Largest derived bearing axis residual in degrees.
    pub axis_residual_degrees: f32,
}

/// Device-written execution evidence. Stage markers prove entry, not every kernel
/// or physical correctness. Body counters exclude early returns after a failure.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct GpuExecutionEvidence {
    /// Integration=1, articulated validation=2, broadphase=4, narrowphase=8,
    /// general/serial contact accumulator=16, bearing validation=32, publication=64,
    /// terrain=128. The fused contact kernel has no spare portable storage binding
    /// for diagnostics and is deliberately unmarked.
    pub stage_mask: u32,
    /// Body rows admitted past integration's initial bounds/failure checks.
    pub integrated_bodies: u32,
    /// Body rows copied to the validated snapshot.
    pub published_bodies: u32,
    /// Bearing rows visited by validation.
    pub validated_bearings: u32,
}

/// One asynchronously completed tick and its prototype-render snapshot.
///
/// The body rows are staged with the fixed-size diagnostics so application
/// frames can consume them without ever waiting for the GPU. Production
/// renderers should continue to bind [`SnapshotBuffers`] directly.
#[derive(Clone, Debug, PartialEq)]
pub struct GpuCompletedTickReadback {
    /// Contiguous submission ordinal, independent of scheduler tick gaps.
    pub submission_sequence: u64,
    /// Monotonic tick encoded into the submission.
    pub tick_index: u64,
    /// Snapshot-ring slot written by the completed tick.
    pub snapshot_slot: u8,
    /// Wall-clock latency from queue submission until mapped readback consumption.
    pub submission_to_readback_ms: f64,
    /// Time when the last mapping callback ran, if diagnostic timing is enabled.
    /// This observes callback servicing, not the instant GPU execution completed.
    pub callbacks_completed_at: Option<Instant>,
    /// Queue-return to final mapping callback latency, when enabled.
    pub submission_to_callbacks_ms: Option<f64>,
    /// Whether the final callback ran during this call to `poll_tick_readback`.
    pub callbacks_during_poll: Option<bool>,
    /// Fixed-size validation and timestamp telemetry.
    pub diagnostics: GpuTickReadback,
    /// CPU prototype-render rows captured from the same tick.
    pub transforms: Vec<GpuTransform>,
    /// Authoritative body velocities captured in the same submission as the poses.
    pub velocities: Vec<GpuVelocity>,
    /// Permitted joint positions and velocities from the same tick.
    pub coordinates: Vec<GpuMechanismCoordinate>,
}

/// GPU timestamp durations for the fixed production pipeline stages.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct GpuKernelTimings {
    /// Body gravity/damping and root-pose integration.
    pub integration_ms: f64,
    /// Exact terrain BVH traversal and contact generation (part of narrowphase).
    pub terrain_traversal_ms: f64,
    /// Conservative rotational CCD.
    pub rotational_sweep_ms: f64,
    /// Split positional recovery, including its mechanism projection.
    pub terrain_recovery_ms: f64,
    /// Mechanism projection inside the three recovery rounds.
    pub recovery_projection_ms: f64,
    /// Reduced-coordinate projection, closure factorization, and forward kinematics.
    pub mechanism_ms: f64,
    /// Spatial broadphase and candidate generation.
    pub broadphase_ms: f64,
    /// OBB SAT and manifold-cache update.
    pub narrowphase_ms: f64,
    /// Warm-started projected impulses, persistence, and articulated feedback.
    pub contact_solver_ms: f64,
    /// Bearing closure validation.
    pub bearings_ms: f64,
    /// GPU snapshot-ring publication.
    pub snapshot_ms: f64,
}

/// Fixed-size diagnostic readback failed.
#[derive(Clone, Debug, Error, PartialEq, Eq)]
pub enum GpuReadbackError {
    /// The requested snapshot ring slot does not exist.
    #[error("snapshot slot {0} is outside the published ring")]
    InvalidSnapshotSlot(u8),
    /// Device polling failed before the mapping callback ran.
    #[error("device polling failed: {0}")]
    DevicePoll(String),
    /// wgpu rejected a diagnostic buffer map.
    #[error("diagnostic buffer mapping failed: {0}")]
    BufferMap(String),
    /// Mapping callback channel closed unexpectedly.
    #[error("diagnostic buffer mapping callback was lost")]
    CallbackLost,
}

/// GPU upload or dispatch could not be created safely.
#[derive(Clone, Debug, Error, PartialEq, Eq)]
pub enum GpuPhysicsError {
    /// Scene exceeds the fixed compound capacity.
    #[error("scene requires {required} bodies but capacity is {capacity}")]
    BodyCapacity {
        /// Required rows.
        required: usize,
        /// Allocated rows.
        capacity: usize,
    },
    /// Scene exceeds the fixed bearing capacity.
    #[error("scene requires {required} bearings but capacity is {capacity}")]
    BearingCapacity {
        /// Required rows.
        required: usize,
        /// Allocated rows.
        capacity: usize,
    },
    /// Scene exceeds the fixed collider capacity.
    #[error("scene requires {required} colliders but capacity is {capacity}")]
    ColliderCapacity {
        /// Required rows.
        required: usize,
        /// Allocated rows.
        capacity: usize,
    },
    /// Scene exceeds the fixed convex-shape buffer.
    #[error("scene requires {required} convex-shape slots but capacity is {capacity}")]
    ConvexShapeCapacity {
        /// Required slots.
        required: usize,
        /// Allocated slots.
        capacity: usize,
    },
    /// Replacement drive rows do not match the compiled coordinate count.
    #[error("drive state has {provided} rows but scene requires {required}")]
    DriveStateCount {
        /// Rows supplied by the caller.
        provided: usize,
        /// Rows required by the compiled forest.
        required: usize,
    },
    /// Initial mechanism-coordinate state does not match the compiled forest.
    #[error("coordinate state has {provided} rows but scene requires {required}")]
    CoordinateStateCount {
        /// Supplied rows.
        provided: usize,
        /// Required rows.
        required: usize,
    },
}

/// A requested external impulse cannot be submitted safely.
#[derive(Clone, Debug, Error, PartialEq, Eq)]
pub enum GpuImpulseError {
    /// The requested body row is outside the uploaded creation.
    #[error("body index {body_index} is outside the uploaded body count {body_count}")]
    BodyIndexOutOfRange {
        /// Requested body row.
        body_index: u32,
        /// Uploaded row count.
        body_count: u32,
    },
    /// The world point or impulse contains NaN or infinity.
    #[error("external impulse point and vector must be finite")]
    NonFinite,
    /// Direct batch submission accepts one fixed staging batch.
    #[error("external impulse batch contains {provided} rows; capacity is {capacity}")]
    BatchCapacity {
        /// Supplied rows.
        provided: usize,
        /// Fixed staging capacity.
        capacity: usize,
    },
}

/// A replacement scene state cannot be uploaded safely.
#[derive(Clone, Debug, Error, PartialEq, Eq)]
pub enum GpuBodyStateError {
    /// State rows must exactly match the uploaded body count.
    #[error("body state count {provided} does not match uploaded body count {expected}")]
    BodyCount {
        /// Number of rows supplied by the caller.
        provided: usize,
        /// Number of rows allocated by the scene.
        expected: u32,
    },
    /// Every transform and velocity lane must be finite.
    #[error("body state contains NaN or infinity")]
    NonFinite,
}

/// A replacement set of collider-local terrain support planes is invalid.
#[derive(Clone, Debug, Error, PartialEq, Eq)]
pub enum GpuGroundPlaneError {
    /// Plane rows must exactly match the uploaded collider count.
    #[error("ground plane count {provided} does not match collider count {expected}")]
    PlaneCount {
        /// Number of rows supplied by the caller.
        provided: usize,
        /// Number of collider rows allocated by the scene.
        expected: u32,
    },
    /// A normal or offset contains NaN or infinity.
    #[error("ground plane contains NaN or infinity")]
    NonFinite,
}

/// One local terrain plane assigned to a compiled collider.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct GpuGroundPlane {
    /// Normal pointing out of terrain toward the construction.
    pub normal: Vec3,
    /// Signed plane offset, satisfying `dot(point, normal) == offset`.
    pub offset: f32,
}

impl GpuGroundPlane {
    /// No terrain surface is available beneath this collider.
    pub const DISABLED: Self = Self {
        normal: Vec3::ZERO,
        offset: 0.0,
    };

    /// Creates a plane passing through `point` with the supplied outward normal.
    pub fn through_point(normal: Vec3, point: Vec3) -> Self {
        let normal = normal.normalize_or_zero();
        Self {
            normal,
            offset: normal.dot(point),
        }
    }
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable, PartialEq)]
/// One validated construction-frame impulse consumed by the GPU serial pass.
pub struct GpuExternalImpulse {
    /// xyz construction-frame contact point; w is unused.
    pub world_point: [f32; 4],
    /// xyz impulse applied to the compound; w is unused.
    pub impulse: [f32; 4],
    /// Body index in x; remaining lanes are reserved.
    pub metadata: [u32; 4],
}

impl GpuExternalImpulse {
    /// Creates one world-space impulse row.
    pub const fn new(body_index: u32, world_point: Vec3, impulse: Vec3) -> Self {
        Self {
            world_point: [world_point.x, world_point.y, world_point.z, 0.0],
            impulse: [impulse.x, impulse.y, impulse.z, 0.0],
            metadata: [body_index, 0, 0, 0],
        }
    }

    /// Target compound row.
    pub const fn body_index(self) -> u32 {
        self.metadata[0]
    }

    fn is_finite(self) -> bool {
        self.world_point[..3].iter().all(|lane| lane.is_finite())
            && self.impulse[..3].iter().all(|lane| lane.is_finite())
    }
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
struct GpuExternalImpulseBatch {
    metadata: [u32; 4],
    rows: [GpuExternalImpulse; EXTERNAL_IMPULSE_BATCH_CAPACITY],
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Pod, Zeroable)]
struct GpuDriveConstraint {
    bearing: GpuBearing,
    drive: GpuMechanismDrive,
    /// Axis inertia, accumulated impulse, current angle, reserved.
    state: [f32; 4],
    /// Child body, parent body, tree direction, coordinate.
    metadata: [u32; 4],
}

/// Custom compute resources backed by Bevy's shared wgpu device and queue.
#[derive(Debug)]
pub struct GpuPhysics {
    body_count: u32,
    holds: Mutex<hold::HoldResources>,
    collider_count: u32,
    bearing_count: u32,
    suppression_count: u32,
    pair_capacity: u32,
    pipeline_config: GpuPhysicsConfig,
    config: wgpu::Buffer,
    positions: wgpu::Buffer,
    rotations: wgpu::Buffer,
    linear_velocities: wgpu::Buffer,
    angular_velocities: wgpu::Buffer,
    inverse_masses: wgpu::Buffer,
    diagnostics: wgpu::Buffer,
    diagnostics_readback: wgpu::Buffer,
    snapshot_positions_readback: wgpu::Buffer,
    snapshot_rotations_readback: wgpu::Buffer,
    masses: wgpu::Buffer,
    _spatial_inertias: wgpu::Buffer,
    colliders: wgpu::Buffer,
    convex_shapes: wgpu::Buffer,
    bearings: wgpu::Buffer,
    external_impulse: wgpu::Buffer,
    external_impulse_pipeline: wgpu::ComputePipeline,
    external_impulse_bind_group: wgpu::BindGroup,
    snapshots: Vec<SnapshotBuffers>,
    bind_groups: Vec<wgpu::BindGroup>,
    integration_pipeline: wgpu::ComputePipeline,
    mechanism: MechanismResources,
    collision: CollisionResources,
    terrain_recovery: Option<terrain::PositionRecovery>,
    terrain_scene: terrain::TerrainGpuScene,
    terrain_free_bodies: wgpu::Buffer,
    terrain_has_free_bodies: bool,
    bearing_pipeline: wgpu::ComputePipeline,
    bearing_bind_group: wgpu::BindGroup,
    snapshot_pipeline: wgpu::ComputePipeline,
    snapshot_bind_groups: Vec<wgpu::BindGroup>,
    timestamps: Option<TimestampResources>,
    submission_sequence: AtomicU64,
    async_readback_enabled: AtomicBool,
    readback_timing_enabled: AtomicBool,
    async_readbacks: Mutex<Vec<AsyncReadbackSlot>>,
}

#[derive(Debug)]
struct AsyncReadbackSlot {
    diagnostics: wgpu::Buffer,
    timestamps: Option<wgpu::Buffer>,
    positions: wgpu::Buffer,
    rotations: wgpu::Buffer,
    linear_velocities: wgpu::Buffer,
    angular_velocities: wgpu::Buffer,
    coordinates: wgpu::Buffer,
    pending: Option<PendingAsyncReadback>,
}

#[derive(Debug)]
struct PendingAsyncReadback {
    submission_sequence: u64,
    tick_index: u64,
    snapshot_slot: u8,
    receiver: mpsc::Receiver<(Result<(), String>, Option<Instant>)>,
    callbacks_completed_at: Option<Instant>,
    remaining_callbacks: u8,
    submitted_at: Instant,
}

#[derive(Debug)]
struct CollisionResources {
    lbvh: LbvhResources,
    body_components: wgpu::Buffer,
    _pairs: wgpu::Buffer,
    contacts: wgpu::Buffer,
    manifold_keys: wgpu::Buffer,
    persistent_manifolds: wgpu::Buffer,
    ground_surfaces: wgpu::Buffer,
    active_contacts: wgpu::Buffer,
    indirect_args: wgpu::Buffer,
    velocity_deltas: wgpu::Buffer,
    world_masses: wgpu::Buffer,
    update_world_masses_pipeline: wgpu::ComputePipeline,
    update_world_masses_bind_group: wgpu::BindGroup,
    narrowphase_pipeline: wgpu::ComputePipeline,
    narrowphase_bind_group: wgpu::BindGroup,
    ground_contacts_pipeline: wgpu::ComputePipeline,
    ground_contacts_bind_group: wgpu::BindGroup,
    terrain_pipeline: wgpu::ComputePipeline,
    terrain_bind_group: Option<wgpu::BindGroup>,
    terrain_geometry_bind_group: Option<wgpu::BindGroup>,
    terrain_triangle_count: usize,
    finalize_contacts_pipeline: wgpu::ComputePipeline,
    finalize_contacts_bind_group: wgpu::BindGroup,
    select_active_pipeline: wgpu::ComputePipeline,
    select_active_bind_group: wgpu::BindGroup,
    finalize_active_pipeline: wgpu::ComputePipeline,
    finalize_active_bind_group: wgpu::BindGroup,
    count_body_contacts_pipeline: wgpu::ComputePipeline,
    count_body_contacts_bind_group: wgpu::BindGroup,
    warm_start_pipeline: wgpu::ComputePipeline,
    warm_start_bind_group: wgpu::BindGroup,
    solve_accumulate_pipeline: wgpu::ComputePipeline,
    solve_accumulate_bind_group: wgpu::BindGroup,
    solve_small_mechanism_pipeline: wgpu::ComputePipeline,
    solve_small_mechanism_bind_group: wgpu::BindGroup,
    solve_apply_pipeline: wgpu::ComputePipeline,
    solve_apply_bind_group: wgpu::BindGroup,
    persist_contacts_pipeline: wgpu::ComputePipeline,
    persist_contacts_bind_group: wgpu::BindGroup,
}

#[derive(Debug)]
struct LbvhResources {
    sort_count: u32,
    _collider_aabbs: wgpu::Buffer,
    _morton_entries: wgpu::Buffer,
    _node_aabbs: wgpu::Buffer,
    _node_children: wgpu::Buffer,
    node_parents: wgpu::Buffer,
    node_visits: wgpu::Buffer,
    sort_params: wgpu::Buffer,
    sort_params_upload: wgpu::Buffer,
    sort_steps: Vec<(u64, bool)>,
    compute_morton_pipeline: wgpu::ComputePipeline,
    compute_morton_bind_group: wgpu::BindGroup,
    sort_local_initial_pipeline: wgpu::ComputePipeline,
    sort_local_initial_bind_group: wgpu::BindGroup,
    sort_global_pipeline: wgpu::ComputePipeline,
    sort_global_bind_group: wgpu::BindGroup,
    sort_local_merge_pipeline: wgpu::ComputePipeline,
    sort_local_merge_bind_group: wgpu::BindGroup,
    build_topology_pipeline: wgpu::ComputePipeline,
    build_topology_bind_group: wgpu::BindGroup,
    prepare_leaves_pipeline: wgpu::ComputePipeline,
    prepare_leaves_bind_group: wgpu::BindGroup,
    build_bounds_pipeline: wgpu::ComputePipeline,
    build_bounds_bind_group: wgpu::BindGroup,
    traverse_pipeline: wgpu::ComputePipeline,
    traverse_bind_group: wgpu::BindGroup,
    finalize_pairs_pipeline: wgpu::ComputePipeline,
    finalize_pairs_bind_group: wgpu::BindGroup,
}

#[derive(Debug)]
struct MechanismResources {
    root_flags: wgpu::Buffer,
    bodies: wgpu::Buffer,
    body_rows: Vec<GpuMechanismBody>,
    coordinates: wgpu::Buffer,
    drives: wgpu::Buffer,
    drive_constraints: wgpu::Buffer,
    drive_constraint_rows: Vec<u32>,
    _preorder: wgpu::Buffer,
    _contraction_schedule: wgpu::Buffer,
    velocity_deltas: wgpu::Buffer,
    _articulated_inertia: wgpu::Buffer,
    _bias_force: wgpu::Buffer,
    _generalized_force: wgpu::Buffer,
    _constraint_impulse: wgpu::Buffer,
    _reduction_scratch: wgpu::Buffer,
    links_a: wgpu::Buffer,
    links_b: wgpu::Buffer,
    closure_accumulators: wgpu::Buffer,
    closure_state: wgpu::Buffer,
    closure_indirect_args: wgpu::Buffer,
    prepare_pipeline: wgpu::ComputePipeline,
    prepare_bind_group: wgpu::BindGroup,
    jump_a_to_b_pipeline: wgpu::ComputePipeline,
    jump_a_to_b_bind_group: wgpu::BindGroup,
    jump_b_to_a_pipeline: wgpu::ComputePipeline,
    jump_b_to_a_bind_group: wgpu::BindGroup,
    publish_a_pipeline: wgpu::ComputePipeline,
    publish_a_bind_group: wgpu::BindGroup,
    publish_b_pipeline: wgpu::ComputePipeline,
    publish_b_bind_group: wgpu::BindGroup,
    evaluate_closures_pipeline: wgpu::ComputePipeline,
    evaluate_closures_bind_group: wgpu::BindGroup,
    finalize_closures_pipeline: wgpu::ComputePipeline,
    finalize_closures_bind_group: wgpu::BindGroup,
    apply_closure_step_pipeline: wgpu::ComputePipeline,
    apply_closure_step_bind_group: wgpu::BindGroup,
    project_velocity_pipeline: wgpu::ComputePipeline,
    project_velocity_bind_group: wgpu::BindGroup,
    project_small_velocity_pipeline: wgpu::ComputePipeline,
    project_small_velocity_bind_group: wgpu::BindGroup,
    project_velocity_serial_pipeline: wgpu::ComputePipeline,
    project_velocity_serial_bind_group: wgpu::BindGroup,
    apply_velocity_pipeline: wgpu::ComputePipeline,
    apply_velocity_bind_group: wgpu::BindGroup,
    prepare_drives_pipeline: wgpu::ComputePipeline,
    prepare_drives_bind_group: wgpu::BindGroup,
    advance_coordinates_pipeline: wgpu::ComputePipeline,
    advance_coordinates_bind_group: wgpu::BindGroup,
    capture_coordinates_pipeline: wgpu::ComputePipeline,
    capture_coordinates_bind_group: wgpu::BindGroup,
    reconstruct_velocities_pipeline: wgpu::ComputePipeline,
    reconstruct_velocities_bind_group: wgpu::BindGroup,
    validate_state_pipeline: wgpu::ComputePipeline,
    validate_state_bind_group: wgpu::BindGroup,
    pointer_jump_rounds: u32,
    coordinate_count: u32,
    closure_count: u32,
    final_is_a: bool,
    active: bool,
    has_dynamic_root: bool,
}

#[derive(Debug)]
struct TimestampResources {
    boundary: wgpu::ComputePipeline,
    boundary_bindings: wgpu::BindGroup,
    query_set: wgpu::QuerySet,
    resolve: wgpu::Buffer,
    readback: wgpu::Buffer,
    period_nanoseconds: f64,
}

impl GpuPhysics {
    /// Contact-solver route fixed for this uploaded scene.
    pub const fn solver_route(&self) -> GpuSolverRoute {
        if self.mechanism.active
            && self.mechanism.has_dynamic_root
            && uses_fused_contact_schedule(
                self.bearing_count,
                self.pipeline_config.ground_plane_enabled,
            )
        {
            GpuSolverRoute::FusedSmallMechanism
        } else {
            GpuSolverRoute::General
        }
    }

    /// Number of asynchronous tick slots awaiting readback completion.
    pub fn in_flight_tick_count(&self) -> usize {
        self.async_readbacks
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .iter()
            .filter(|slot| slot.pending.is_some())
            .count()
    }

    /// Uploads a compiled creation. The supplied device/queue may be Bevy's
    /// `RenderDevice` and `RenderQueue` deref targets, avoiding a second device.
    ///
    /// # Errors
    ///
    /// Returns [`GpuPhysicsError`] when a fixed scene capacity is exceeded.
    ///
    /// # Panics
    ///
    /// wgpu may panic if `device` is invalid or its implementation rejects the
    /// statically embedded, startup-validated WGSL module.
    pub fn new(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        creation: &CompiledCreation,
    ) -> Result<Self, GpuPhysicsError> {
        Self::new_with_config(device, queue, creation, GpuPhysicsConfig::default())
    }

    /// Uploads a compiled creation with fixed scene-wide pipeline settings.
    ///
    /// # Errors
    ///
    /// Returns [`GpuPhysicsError`] when a fixed scene capacity is exceeded.
    ///
    /// # Panics
    ///
    /// wgpu may panic if `device` is invalid or rejects an embedded WGSL module.
    #[allow(clippy::too_many_lines)]
    pub fn new_with_config(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        creation: &CompiledCreation,
        pipeline_config: GpuPhysicsConfig,
    ) -> Result<Self, GpuPhysicsError> {
        Self::new_with_pipelines(
            device,
            queue,
            creation,
            pipeline_config,
            &GpuPhysicsPipelines::new(),
        )
    }

    /// Uploads a compiled scene while reusing previously compiled GPU kernels.
    ///
    /// # Errors
    ///
    /// Returns [`GpuPhysicsError`] when a fixed scene capacity is exceeded.
    ///
    /// # Panics
    ///
    /// wgpu may panic if `device` is invalid or rejects an embedded WGSL module.
    #[allow(clippy::too_many_lines)]
    pub fn new_with_pipelines(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        creation: &CompiledCreation,
        pipeline_config: GpuPhysicsConfig,
        pipelines: &GpuPhysicsPipelines,
    ) -> Result<Self, GpuPhysicsError> {
        if creation.compounds.len() > MAX_BODIES {
            return Err(GpuPhysicsError::BodyCapacity {
                required: creation.compounds.len(),
                capacity: MAX_BODIES,
            });
        }
        if creation.bearings.len() > MAX_BEARINGS {
            return Err(GpuPhysicsError::BearingCapacity {
                required: creation.bearings.len(),
                capacity: MAX_BEARINGS,
            });
        }
        if creation.colliders.len() > MAX_COLLIDERS {
            return Err(GpuPhysicsError::ColliderCapacity {
                required: creation.colliders.len(),
                capacity: MAX_COLLIDERS,
            });
        }

        let body_count = u32::try_from(creation.compounds.len()).unwrap_or(u32::MAX);
        let collider_count = u32::try_from(creation.colliders.len()).unwrap_or(u32::MAX);
        let bearing_count = u32::try_from(creation.bearings.len()).unwrap_or(u32::MAX);
        let suppression_count =
            u32::try_from(creation.collision_suppression.len()).unwrap_or(u32::MAX);
        let pair_capacity = contact_pair_capacity(creation.colliders.len());
        let positions = creation
            .compounds
            .iter()
            .map(|compound| vec4(compound.root_translation, 0.0))
            .collect::<Vec<_>>();
        let rotations = creation
            .compounds
            .iter()
            .map(|compound| {
                let rotation = compound.root_rotation;
                [rotation.x, rotation.y, rotation.z, rotation.w]
            })
            .collect::<Vec<_>>();
        let zero_vectors = vec![[0.0_f32; 4]; creation.compounds.len()];
        let inverse_masses = creation
            .compounds
            .iter()
            .map(|compound| compound.mass_properties.inverse_mass)
            .collect::<Vec<_>>();
        let body_components = creation
            .loop_topology
            .body_parents
            .iter()
            .map(|body| body.component_index)
            .collect::<Vec<_>>();
        let masses = creation
            .compounds
            .iter()
            .map(|compound| {
                let properties = compound.mass_properties;
                GpuMass {
                    inverse_mass: [properties.inverse_mass, 0.0, 0.0, 0.0],
                    inverse_inertia_x: vec4(properties.inverse_inertia.x_axis, 0.0),
                    inverse_inertia_y: vec4(properties.inverse_inertia.y_axis, 0.0),
                    inverse_inertia_z: vec4(properties.inverse_inertia.z_axis, 0.0),
                }
            })
            .collect::<Vec<_>>();
        let spatial_inertias = creation
            .compounds
            .iter()
            .map(|compound| {
                let properties = compound.mass_properties;
                GpuSpatialInertia {
                    mass: [properties.mass, 0.0, 0.0, 0.0],
                    inertia_x: vec4(properties.inertia.x_axis, 0.0),
                    inertia_y: vec4(properties.inertia.y_axis, 0.0),
                    inertia_z: vec4(properties.inertia.z_axis, 0.0),
                }
            })
            .collect::<Vec<_>>();
        let cylinder_ground_data = full_cylinder_ground_data(&creation.colliders);
        let mut convex_shapes: Vec<[f32; 4]> = Vec::new();
        let colliders = creation
            .colliders
            .iter()
            .zip(cylinder_ground_data)
            .map(|(collider, ground)| {
                let (local_rotation, half_extents, mut shape) = match &collider.shape {
                    ColliderShape::Cuboid {
                        local_rotation,
                        half_extents,
                    } => (
                        [
                            local_rotation.x,
                            local_rotation.y,
                            local_rotation.z,
                            local_rotation.w,
                        ],
                        vec4(*half_extents, ground.outer_radius),
                        [COLLIDER_SHAPE_CUBOID, 0, 0, 0],
                    ),
                    ColliderShape::Convex(convex) => {
                        let offset =
                            u32::try_from(convex_shapes.len()).expect("convex slot fits u32");
                        convex_shapes
                            .extend(convex.vertices.iter().map(|vertex| vec4(*vertex, 0.0)));
                        convex_shapes.extend(
                            convex
                                .face_planes
                                .iter()
                                .map(|plane| [plane.x, plane.y, plane.z, plane.w]),
                        );
                        convex_shapes
                            .extend(convex.edge_directions.iter().map(|edge| vec4(*edge, 0.0)));
                        let counts = pack_convex_counts(
                            u32::try_from(convex.vertices.len()).expect("vertex count fits u32"),
                            u32::try_from(convex.face_planes.len()).expect("face count fits u32"),
                            u32::try_from(convex.edge_directions.len())
                                .expect("edge count fits u32"),
                        );
                        (
                            [0.0, 0.0, 0.0, 1.0],
                            [0.0, 0.0, 0.0, 0.0],
                            [COLLIDER_SHAPE_CONVEX, offset, counts, 0],
                        )
                    }
                };
                // Terrain contacts name no second body, so the solver discards
                // every one belonging to an immovable body. Marking the row lets
                // the contact kernel skip a full BVH descent that can only
                // produce discarded contacts.
                shape[3] = u32::from(
                    creation.compounds[collider.compound_index as usize]
                        .mass_properties
                        .inverse_mass
                        <= 0.0,
                );
                GpuCollider {
                    local_center: vec4(collider.local_center, ground.center_radius),
                    local_rotation,
                    half_extents,
                    metadata: [
                        collider.compound_index,
                        collider.source_part.index(),
                        collider.source_part.generation(),
                        ground.role,
                    ],
                    surface_response: [
                        collider.material_properties.static_friction,
                        collider.material_properties.dynamic_friction,
                        collider.material_properties.restitution,
                        collider.material_properties.rolling_resistance,
                    ],
                    surface_elasticity: [
                        collider.material_properties.nominal_block_compliance(),
                        collider.material_properties.youngs_modulus_pa,
                        0.0,
                        0.0,
                    ],
                    shape,
                }
            })
            .collect::<Vec<_>>();
        if convex_shapes.len() > MAX_CONVEX_SHAPE_SLOTS {
            return Err(GpuPhysicsError::ConvexShapeCapacity {
                required: convex_shapes.len(),
                capacity: MAX_CONVEX_SHAPE_SLOTS,
            });
        }
        // The buffer is fixed size, so an empty scene still needs one slot.
        if convex_shapes.is_empty() {
            convex_shapes.push([0.0; 4]);
        }
        let bearings = creation
            .bearings
            .iter()
            .map(|bearing| GpuBearing {
                local_anchor_a: vec4(bearing.local_anchor_a, bearing.kind.bounds()[0]),
                local_anchor_b: vec4(bearing.local_anchor_b, bearing.kind.bounds()[1]),
                local_axis_a: vec4(
                    bearing.local_axis_a,
                    if bearing.kind.is_translational() {
                        1.0
                    } else {
                        0.0
                    },
                ),
                local_axis_b: vec4(bearing.local_axis_b, 0.0),
                suspension: match bearing.kind {
                    mechanic_core::BearingKind::Suspension(s) => s.passive_rows()[0],
                    _ => [0.0; 4],
                },
                bump_stop: match bearing.kind {
                    mechanic_core::BearingKind::Suspension(s) => s.passive_rows()[1],
                    _ => [0.0; 4],
                },
                metadata: [
                    bearing.compound_a,
                    bearing.compound_b,
                    bearing.coordinate_index.unwrap_or(u32::MAX),
                    u32::from(bearing.coordinate_index.is_none()),
                ],
            })
            .collect::<Vec<_>>();
        let holds = Mutex::new(hold::HoldResources::new(
            masses.clone(),
            bearings.clone(),
            body_components.clone(),
        ));
        let suppressed_pairs = creation
            .collision_suppression
            .iter()
            .map(|pair| GpuPair {
                collider_a: pair[0],
                collider_b: pair[1],
            })
            .collect::<Vec<_>>();

        let config =
            create_uniform_buffer(device, "mechanic tick config", &GpuTickConfig::zeroed());
        let positions_buffer = create_storage_buffer(device, "mechanic positions", &positions);
        let rotations_buffer = create_storage_buffer(device, "mechanic rotations", &rotations);
        let linear_velocities =
            create_state_buffer(device, "mechanic linear velocities", &zero_vectors);
        let angular_velocities =
            create_state_buffer(device, "mechanic angular velocities", &zero_vectors);
        let inverse_masses =
            create_storage_buffer(device, "mechanic inverse masses", &inverse_masses);
        let diagnostics = create_buffer(
            device,
            "mechanic diagnostics",
            // The fixed readback header is followed by per-body contact counts.
            // Sharing this atomic scratch buffer keeps collision passes within
            // the baseline limit of eight storage-buffer bindings.
            &vec![0_u32; size_of::<GpuDiagnostics>() / size_of::<u32>() + body_count as usize],
            wgpu::BufferUsages::STORAGE
                | wgpu::BufferUsages::COPY_DST
                | wgpu::BufferUsages::COPY_SRC,
        );
        let diagnostics_readback = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("mechanic diagnostics readback"),
            size: size_of::<GpuDiagnostics>() as u64,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        let snapshot_readback_size = u64::from(body_count) * 16;
        let snapshot_positions_readback = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("mechanic snapshot positions readback"),
            size: snapshot_readback_size,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        let snapshot_rotations_readback = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("mechanic snapshot rotations readback"),
            size: snapshot_readback_size,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        let masses = create_storage_buffer(device, "mechanic mass rows", &masses);
        let spatial_inertias = create_readonly_storage_buffer(
            device,
            "mechanic direct spatial inertia rows",
            &spatial_inertias,
        );
        let colliders = create_readonly_storage_buffer(device, "mechanic colliders", &colliders);
        let convex_shapes =
            create_readonly_storage_buffer(device, "mechanic convex shapes", &convex_shapes);
        let bearings = create_storage_buffer(device, "mechanic bearings", &bearings);
        let suppressed_pairs = create_readonly_storage_buffer(
            device,
            "mechanic collision suppression",
            &suppressed_pairs,
        );

        let mechanism = create_mechanism_resources(
            device,
            pipelines,
            creation,
            &config,
            &positions_buffer,
            &rotations_buffer,
            &diagnostics,
            &bearings,
            &masses,
            &spatial_inertias,
            &linear_velocities,
            &angular_velocities,
        );

        let shader = shader_module(
            pipelines,
            device,
            "mechanic physics kernels",
            include_str!("kernels/physics.wgsl"),
        );
        let integration_pipeline = compute_pipeline(
            pipelines,
            device,
            "mechanic integrate and snapshot",
            &shader,
            "integrate",
        );
        let external_impulse = create_uniform_buffer(
            device,
            "mechanic external impulse",
            &GpuExternalImpulseBatch::zeroed(),
        );
        let external_impulse_pipeline = compute_pipeline(
            pipelines,
            device,
            "mechanic apply external impulse",
            &shader,
            "apply_external_impulse",
        );
        let external_impulse_bind_group = bind_group(
            device,
            "mechanic external impulse bindings",
            &external_impulse_pipeline,
            &[
                entry(1, &positions_buffer),
                entry(2, &rotations_buffer),
                entry(3, &linear_velocities),
                entry(4, &angular_velocities),
                entry(7, &masses),
                entry(8, &external_impulse),
            ],
        );
        let layout = integration_pipeline.get_bind_group_layout(0);
        let snapshot_shader = shader_module(
            pipelines,
            device,
            "mechanic snapshot kernel",
            include_str!("kernels/snapshot.wgsl"),
        );
        let snapshot_pipeline = compute_pipeline(
            pipelines,
            device,
            "mechanic publish snapshot",
            &snapshot_shader,
            "publish_snapshot",
        );
        let timestamps = device
            .features()
            .contains(wgpu::Features::TIMESTAMP_QUERY)
            .then(|| {
                let boundary = compute_pipeline(pipelines, device, "mechanic timestamp boundary", &shader_module(pipelines, device, "mechanic timestamp boundary",
                    "@group(0) @binding(0) var<storage, read_write> positions: array<atomic<u32>>; @compute @workgroup_size(1) fn boundary() { atomicOr(&positions[0], 0u); }"), "boundary");
                let boundary_bindings = bind_group(device, "mechanic ordered timestamp boundary", &boundary, &[entry(0, &positions_buffer)]);
                TimestampResources {
                    boundary,
                    boundary_bindings,
                query_set: device.create_query_set(&wgpu::QuerySetDescriptor {
                    label: Some("mechanic physics timestamps"),
                    ty: wgpu::QueryType::Timestamp,
                    count: 28,
                }),
                resolve: device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("mechanic timestamp resolve"),
                    size: 224,
                    usage: wgpu::BufferUsages::QUERY_RESOLVE | wgpu::BufferUsages::COPY_SRC,
                    mapped_at_creation: false,
                }),
                readback: device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("mechanic timestamp readback"),
                    size: 224,
                    usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
                    mapped_at_creation: false,
                }),
                period_nanoseconds: f64::from(queue.get_timestamp_period()),
                }
            });
        let mut snapshots = Vec::with_capacity(SNAPSHOT_RING_SIZE);
        let mut bind_groups = Vec::with_capacity(SNAPSHOT_RING_SIZE);
        let mut snapshot_bind_groups = Vec::with_capacity(SNAPSHOT_RING_SIZE);
        for slot in 0..SNAPSHOT_RING_SIZE {
            let snapshot = SnapshotBuffers {
                positions: create_buffer(
                    device,
                    &format!("mechanic snapshot {slot} positions"),
                    &positions,
                    wgpu::BufferUsages::STORAGE
                        | wgpu::BufferUsages::COPY_DST
                        | wgpu::BufferUsages::COPY_SRC,
                ),
                rotations: create_buffer(
                    device,
                    &format!("mechanic snapshot {slot} rotations"),
                    &rotations,
                    wgpu::BufferUsages::STORAGE
                        | wgpu::BufferUsages::COPY_DST
                        | wgpu::BufferUsages::COPY_SRC,
                ),
            };
            bind_groups.push(device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("mechanic integration bindings"),
                layout: &layout,
                entries: &[
                    entry(0, &config),
                    entry(1, &positions_buffer),
                    entry(2, &rotations_buffer),
                    entry(3, &linear_velocities),
                    entry(4, &angular_velocities),
                    entry(5, &inverse_masses),
                    entry(6, &diagnostics),
                    entry(9, &mechanism.root_flags),
                ],
            }));
            snapshot_bind_groups.push(bind_group(
                device,
                "mechanic snapshot bindings",
                &snapshot_pipeline,
                &[
                    entry(0, &positions_buffer),
                    entry(1, &rotations_buffer),
                    entry(2, &snapshot.positions),
                    entry(3, &snapshot.rotations),
                    entry(4, &diagnostics),
                ],
            ));
            snapshots.push(snapshot);
        }

        let collision = create_collision_resources(
            device,
            pipelines,
            creation.colliders.len(),
            usize::try_from(pair_capacity).unwrap_or(MAX_CONTACT_PAIRS),
            &config,
            &positions_buffer,
            &rotations_buffer,
            &linear_velocities,
            &angular_velocities,
            &masses,
            &diagnostics,
            &colliders,
            &convex_shapes,
            &suppressed_pairs,
            &mechanism.drive_constraints,
            &body_components,
            pipeline_config.mechanism_self_collisions,
        );
        let bearing_shader = shader_module(
            pipelines,
            device,
            "mechanic bearing kernels",
            include_str!("kernels/bearings.wgsl"),
        );
        let bearing_entry_point = if mechanism.active {
            "validate_mechanism_bearings"
        } else {
            "validate_bearings"
        };
        let bearing_pipeline = compute_pipeline(
            pipelines,
            device,
            "mechanic validate bearings",
            &bearing_shader,
            bearing_entry_point,
        );
        let bearing_bind_group = if mechanism.active {
            let final_links = if mechanism.final_is_a {
                &mechanism.links_a
            } else {
                &mechanism.links_b
            };
            bind_group(
                device,
                "mechanic local bearing bindings",
                &bearing_pipeline,
                &[
                    entry(0, &config),
                    entry(3, &diagnostics),
                    entry(4, &bearings),
                    entry(5, final_links),
                ],
            )
        } else {
            bind_group(
                device,
                "mechanic bearing bindings",
                &bearing_pipeline,
                &[
                    entry(0, &config),
                    entry(1, &positions_buffer),
                    entry(2, &rotations_buffer),
                    entry(3, &diagnostics),
                    entry(4, &bearings),
                ],
            )
        };

        let mut free_bodies: Vec<u32> = creation
            .compounds
            .iter()
            .map(|body| u32::from(!body.is_static))
            .collect();
        for bearing in &creation.bearings {
            free_bodies[bearing.compound_a as usize] = 0;
            free_bodies[bearing.compound_b as usize] = 0;
        }
        free_bodies.resize(free_bodies.len().max(1), 0);
        let terrain_free_bodies = create_readonly_storage_buffer(
            device,
            "mechanic unjointed terrain sweep bodies",
            &free_bodies,
        );

        // Make the upload boundary explicit before the first fixed tick.
        queue.write_buffer(&diagnostics, 0, bytes_of(&GpuDiagnostics::zeroed()));
        Ok(Self {
            holds,
            body_count,
            collider_count,
            bearing_count,
            suppression_count,
            pair_capacity,
            pipeline_config,
            config,
            positions: positions_buffer,
            rotations: rotations_buffer,
            linear_velocities,
            angular_velocities,
            inverse_masses,
            diagnostics,
            diagnostics_readback,
            snapshot_positions_readback,
            snapshot_rotations_readback,
            masses,
            _spatial_inertias: spatial_inertias,
            colliders,
            convex_shapes,
            bearings,
            external_impulse,
            external_impulse_pipeline,
            external_impulse_bind_group,
            snapshots,
            bind_groups,
            integration_pipeline,
            mechanism,
            collision,
            terrain_recovery: None,
            terrain_scene: terrain::TerrainGpuScene::default(),
            terrain_has_free_bodies: free_bodies.contains(&1),
            terrain_free_bodies,
            bearing_pipeline,
            bearing_bind_group,
            snapshot_pipeline,
            snapshot_bind_groups,
            timestamps,
            submission_sequence: AtomicU64::new(0),
            async_readback_enabled: AtomicBool::new(false),
            readback_timing_enabled: AtomicBool::new(false),
            async_readbacks: Mutex::new(Vec::new()),
        })
    }

    /// Adds a world-space impulse at a world-space point on one compound body.
    ///
    /// Static bodies ignore the impulse. The submission is ordered before later
    /// fixed ticks submitted to the same queue.
    ///
    /// # Errors
    ///
    /// Returns [`GpuImpulseError`] for an invalid body row or non-finite input.
    pub fn apply_impulse(
        &self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        body_index: u32,
        world_point: Vec3,
        impulse: Vec3,
    ) -> Result<wgpu::SubmissionIndex, GpuImpulseError> {
        self.apply_impulses(
            device,
            queue,
            &[GpuExternalImpulse::new(body_index, world_point, impulse)],
        )
    }

    /// Validates and applies at most one fixed staging batch as a serial pass.
    ///
    /// Validation covers every row before the queue is modified, so invalid input
    /// can never produce a partial submission.
    ///
    /// # Errors
    ///
    /// Returns [`GpuImpulseError`] when the batch exceeds staging capacity or any
    /// row has an invalid body index or non-finite point/vector.
    pub fn apply_impulses(
        &self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        impulses: &[GpuExternalImpulse],
    ) -> Result<wgpu::SubmissionIndex, GpuImpulseError> {
        if impulses.len() > EXTERNAL_IMPULSE_BATCH_CAPACITY {
            return Err(GpuImpulseError::BatchCapacity {
                provided: impulses.len(),
                capacity: EXTERNAL_IMPULSE_BATCH_CAPACITY,
            });
        }
        self.validate_impulses(impulses)?;
        let mut batch = GpuExternalImpulseBatch::zeroed();
        batch.metadata[0] = u32::try_from(impulses.len()).unwrap_or(u32::MAX);
        batch.rows[..impulses.len()].copy_from_slice(impulses);
        queue.write_buffer(&self.external_impulse, 0, bytes_of(&batch));
        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("mechanic external impulse"),
        });
        direct_compute_pass(
            &mut encoder,
            "mechanic apply external impulse",
            &self.external_impulse_pipeline,
            &self.external_impulse_bind_group,
            1,
            None,
        );
        Ok(queue.submit([encoder.finish()]))
    }

    fn validate_impulses(&self, impulses: &[GpuExternalImpulse]) -> Result<(), GpuImpulseError> {
        for row in impulses {
            let body_index = row.body_index();
            if body_index >= self.body_count {
                return Err(GpuImpulseError::BodyIndexOutOfRange {
                    body_index,
                    body_count: self.body_count,
                });
            }
            if !row.is_finite() {
                return Err(GpuImpulseError::NonFinite);
            }
        }
        Ok(())
    }

    /// Replaces all authoritative body transforms and velocities at a safe app-owned boundary.
    ///
    /// This is used when a live world rebuilds its static construction topology after an edit;
    /// unchanged moving compounds keep their latest pose and motion.
    ///
    /// # Errors
    ///
    /// Returns [`GpuBodyStateError`] when row counts differ or any lane is non-finite.
    pub fn write_body_states(
        &self,
        queue: &wgpu::Queue,
        transforms: &[GpuTransform],
        velocities: &[GpuVelocity],
    ) -> Result<(), GpuBodyStateError> {
        let expected = self.body_count;
        if transforms.len() != expected as usize || velocities.len() != expected as usize {
            return Err(GpuBodyStateError::BodyCount {
                provided: transforms.len().max(velocities.len()),
                expected,
            });
        }
        let finite = transforms.iter().all(|state| {
            state.position.into_iter().all(f32::is_finite)
                && state.rotation.into_iter().all(f32::is_finite)
        }) && velocities.iter().all(|state| {
            state.linear.into_iter().all(f32::is_finite)
                && state.angular.into_iter().all(f32::is_finite)
        });
        if !finite {
            return Err(GpuBodyStateError::NonFinite);
        }
        let positions = transforms
            .iter()
            .map(|state| state.position)
            .collect::<Vec<_>>();
        let rotations = transforms
            .iter()
            .map(|state| state.rotation)
            .collect::<Vec<_>>();
        let linear = velocities
            .iter()
            .map(|state| state.linear)
            .collect::<Vec<_>>();
        let angular = velocities
            .iter()
            .map(|state| state.angular)
            .collect::<Vec<_>>();
        queue.write_buffer(&self.positions, 0, cast_slice(&positions));
        queue.write_buffer(&self.rotations, 0, cast_slice(&rotations));
        queue.write_buffer(&self.linear_velocities, 0, cast_slice(&linear));
        queue.write_buffer(&self.angular_velocities, 0, cast_slice(&angular));
        Ok(())
    }

    /// Assigns the same explicit flat collision plane to every collider.
    pub fn write_ground_plane(&self, queue: &wgpu::Queue, normal: Vec3, offset: f32) {
        let length = normal.length();
        let plane = if length > 0.0 {
            GpuGroundPlane {
                normal: normal / length,
                offset: offset / length,
            }
        } else {
            GpuGroundPlane::DISABLED
        };
        let planes = vec![plane; self.collider_count as usize];
        // This method constructs exactly one finite row per uploaded collider.
        let _ = self.write_ground_planes(queue, &planes);
    }

    /// Replaces the terrain-support plane independently for every collider.
    ///
    /// Per-collider planes let a large mechanism rest on the streamed terrain
    /// beneath each of its parts without pretending the entire world is one
    /// moving infinite plane.
    ///
    /// # Errors
    ///
    /// Returns [`GpuGroundPlaneError`] when the row count differs from the
    /// uploaded collider count or a row is not finite.
    pub fn write_ground_planes(
        &self,
        queue: &wgpu::Queue,
        planes: &[GpuGroundPlane],
    ) -> Result<(), GpuGroundPlaneError> {
        if planes.len() != self.collider_count as usize {
            return Err(GpuGroundPlaneError::PlaneCount {
                provided: planes.len(),
                expected: self.collider_count,
            });
        }
        if planes
            .iter()
            .any(|plane| !plane.normal.is_finite() || !plane.offset.is_finite())
        {
            return Err(GpuGroundPlaneError::NonFinite);
        }
        let concrete = ConstructionMaterial::Concrete.properties();
        let rows = planes
            .iter()
            .map(|plane| {
                let length = plane.normal.length();
                let (normal, offset) = if length > 0.0 {
                    (plane.normal / length, plane.offset / length)
                } else {
                    (Vec3::ZERO, 0.0)
                };
                GpuGroundSurface {
                    response: [
                        concrete.static_friction,
                        concrete.dynamic_friction,
                        concrete.restitution,
                        concrete.rolling_resistance,
                    ],
                    elasticity: [
                        concrete.nominal_block_compliance(),
                        concrete.youngs_modulus_pa,
                        0.0,
                        0.0,
                    ],
                    plane: [normal.x, normal.y, normal.z, offset],
                }
            })
            .collect::<Vec<_>>();
        queue.write_buffer(&self.collision.ground_surfaces, 0, cast_slice(&rows));
        Ok(())
    }

    /// Enables non-blocking per-tick telemetry and prototype snapshot staging.
    ///
    /// This is opt-in because correctness tests and headless benchmarks use
    /// explicit synchronous sampling and should not allocate an application
    /// readback ring for unobserved warm-up ticks.
    pub fn enable_async_readback(&self) {
        self.async_readback_enabled.store(true, Ordering::Release);
    }

    /// Enables callback timestamps for subsequently submitted asynchronous ticks.
    /// Adds no polling, waits, queue work, or readback slots.
    pub fn enable_readback_timing(&self) {
        self.readback_timing_enabled.store(true, Ordering::Release);
    }

    /// Number of ticks that can be staged without waiting or allocating.
    ///
    /// The application uses this as its in-flight submission budget. Logical
    /// scheduler ticks remain in the CPU backlog until a fixed ring slot is
    /// available, preventing a slow GPU from turning into an unbounded queue.
    pub fn async_readback_slots_available(&self) -> usize {
        if !self.async_readback_enabled.load(Ordering::Acquire) {
            return usize::MAX;
        }
        let slots = self
            .async_readbacks
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        slots.iter().filter(|slot| slot.pending.is_none()).count()
            + ASYNC_READBACK_RING_SIZE.saturating_sub(slots.len())
    }

    /// Encodes and submits one 60 Hz integration/publication pass.
    #[allow(clippy::too_many_lines)]
    pub fn dispatch_tick(
        &self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        tick_index: u64,
    ) -> GpuTickSubmission {
        self.encode_and_submit_tick(device, queue, tick_index)
    }

    /// Applies all pending impulses in ordered serial batches, then dispatches a tick.
    ///
    /// Every row is validated before the first queue write. Sets larger than the fixed
    /// staging buffer are split without dropping contacts.
    ///
    /// # Errors
    ///
    /// Returns [`GpuImpulseError`] when any pending row has an invalid body index or
    /// non-finite point/vector.
    pub fn dispatch_tick_with_impulses(
        &self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        tick_index: u64,
        impulses: &[GpuExternalImpulse],
    ) -> Result<GpuTickSubmission, GpuImpulseError> {
        self.validate_impulses(impulses)?;
        for batch in impulses.chunks(EXTERNAL_IMPULSE_BATCH_CAPACITY) {
            self.apply_impulses(device, queue, batch)?;
        }
        Ok(self.encode_and_submit_tick(device, queue, tick_index))
    }

    #[allow(clippy::too_many_lines)]
    fn encode_and_submit_tick(
        &self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        tick_index: u64,
    ) -> GpuTickSubmission {
        let submission_sequence = self.submission_sequence.fetch_add(1, Ordering::Relaxed) + 1;
        let encoding_started = Instant::now();
        let snapshot_slot = u8::try_from(tick_index % 3).unwrap_or(0);
        let config = GpuTickConfig {
            body_count: self.body_count,
            tick_index: wrapping_u32(tick_index),
            snapshot_slot: u32::from(snapshot_slot),
            collider_count: self.collider_count,
            delta_seconds: FIXED_DT_SECONDS,
            gravity_y: -9.81,
            linear_damping: 0.999,
            angular_damping: 0.98,
            bearing_count: self.bearing_count,
            suppression_count: self.suppression_count,
            pair_capacity: self.pair_capacity,
            flags: u32::from(self.pipeline_config.collisions_enabled)
                | (u32::from(self.solver_route() == GpuSolverRoute::FusedSmallMechanism) << 1),
            hash_capacity: u32::try_from(BROADPHASE_HASH_CAPACITY).unwrap_or(u32::MAX),
            solver_iterations: self.pipeline_config.solver_iterations.max(1),
            reserved_a: self.collision.lbvh.sort_count,
            reserved_b: self.mechanism.coordinate_count,
        };
        queue.write_buffer(&self.config, 0, bytes_of(&config));
        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("mechanic physics tick"),
        });
        // Error flags are a persistent GPU failure latch. Per-tick counters are
        // cleared independently, so a delayed CPU readback can never erase a
        // terminal failure reported by an earlier submission.
        encoder.clear_buffer(&self.diagnostics, 4, None);
        let run_collisions = self.pipeline_config.collisions_enabled && self.collider_count > 0;
        let run_bearings = self.bearing_count > 0;
        if run_collisions {
            encoder.clear_buffer(&self.collision.lbvh.node_parents, 0, None);
            encoder.clear_buffer(&self.collision.lbvh.node_visits, 0, None);
            encoder.clear_buffer(&self.collision.velocity_deltas, 0, None);
        }
        if self.mechanism.active {
            encoder.clear_buffer(&self.mechanism.velocity_deltas, 0, None);
        }
        if run_collisions
            && self.collision.terrain_triangle_count > 0
            && let Some(recovery) = &self.terrain_recovery
        {
            recovery.capture(self, &mut encoder);
        }
        {
            let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
                label: Some("mechanic integrate pass"),
                timestamp_writes: timestamp_writes(self.timestamps.as_ref(), Some(0), Some(1)),
            });
            pass.set_pipeline(&self.integration_pipeline);
            pass.set_bind_group(0, &self.bind_groups[usize::from(snapshot_slot)], &[]);
            pass.dispatch_workgroups(self.body_count.div_ceil(256), 1, 1);
        }
        if self.mechanism.active {
            self.encode_mechanism_passes(&mut encoder);
        }
        if run_collisions
            && self.collision.terrain_triangle_count > 0
            && let Some(recovery) = &self.terrain_recovery
        {
            self.encode_terrain_timestamp(&mut encoder, 16);
            if self.terrain_has_free_bodies {
                recovery.sweep.encode(self, &mut encoder);
            }
            self.encode_terrain_timestamp(&mut encoder, 17);
        }
        if run_collisions {
            self.encode_collision_passes(&mut encoder);
        }
        if self.mechanism.active && run_collisions {
            self.encode_post_contact_mechanism(&mut encoder);
        }
        if run_collisions
            && self.collision.terrain_triangle_count > 0
            && let Some(recovery) = &self.terrain_recovery
        {
            self.encode_terrain_timestamp(&mut encoder, 18);
            recovery.encode(self, &mut encoder);
            self.encode_terrain_timestamp(&mut encoder, 19);
        }
        if self.mechanism.active {
            direct_compute_pass(
                &mut encoder,
                "mechanic validate articulated state",
                &self.mechanism.validate_state_pipeline,
                &self.mechanism.validate_state_bind_group,
                self.body_count.div_ceil(256),
                None,
            );
        }
        if run_bearings {
            let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
                label: Some("mechanic bearing validation"),
                timestamp_writes: timestamp_writes(self.timestamps.as_ref(), Some(10), Some(11)),
            });
            pass.set_pipeline(&self.bearing_pipeline);
            pass.set_bind_group(0, &self.bearing_bind_group, &[]);
            pass.dispatch_workgroups(self.bearing_count.div_ceil(256), 1, 1);
        }
        direct_compute_pass(
            &mut encoder,
            "mechanic snapshot publication",
            &self.snapshot_pipeline,
            &self.snapshot_bind_groups[usize::from(snapshot_slot)],
            self.body_count.div_ceil(256),
            timestamp_writes(self.timestamps.as_ref(), Some(12), Some(13)),
        );
        encoder.copy_buffer_to_buffer(
            &self.diagnostics,
            0,
            &self.diagnostics_readback,
            0,
            u64::try_from(size_of::<GpuDiagnostics>()).unwrap_or(32),
        );
        if let Some(timestamps) = &self.timestamps {
            encoder.resolve_query_set(&timestamps.query_set, 0..28, &timestamps.resolve, 0);
            encoder.copy_buffer_to_buffer(&timestamps.resolve, 0, &timestamps.readback, 0, 224);
        }
        let mut async_readbacks = self
            .async_readback_enabled
            .load(Ordering::Acquire)
            .then(|| {
                self.async_readbacks
                    .lock()
                    .unwrap_or_else(std::sync::PoisonError::into_inner)
            });
        let async_slot_index = async_readbacks.as_mut().and_then(|slots| {
            let index = if let Some(index) = slots.iter().position(|slot| slot.pending.is_none()) {
                index
            } else if slots.len() < ASYNC_READBACK_RING_SIZE {
                let index = slots.len();
                slots.push(create_async_readback_slot(
                    device,
                    self.body_count,
                    self.mechanism.coordinate_count,
                    self.timestamps.is_some(),
                    index,
                ));
                index
            } else {
                return None;
            };
            let slot = &slots[index];
            let diagnostics_size = u64::try_from(size_of::<GpuDiagnostics>()).unwrap_or(32);
            let snapshot_size = u64::from(self.body_count) * 16;
            encoder.copy_buffer_to_buffer(
                &self.diagnostics,
                0,
                &slot.diagnostics,
                0,
                diagnostics_size,
            );
            if let (Some(timestamps), Some(readback)) = (&self.timestamps, slot.timestamps.as_ref())
            {
                encoder.copy_buffer_to_buffer(&timestamps.resolve, 0, readback, 0, 224);
            }
            let snapshot = &self.snapshots[usize::from(snapshot_slot)];
            encoder.copy_buffer_to_buffer(
                snapshot.positions(),
                0,
                &slot.positions,
                0,
                snapshot_size,
            );
            encoder.copy_buffer_to_buffer(
                snapshot.rotations(),
                0,
                &slot.rotations,
                0,
                snapshot_size,
            );
            // Copies share the tick command encoder, before any subsequent tick can
            // mutate the source buffers. Zero-coordinate scenes retain a dummy row.
            for (source, destination, size) in [
                (
                    &self.linear_velocities,
                    &slot.linear_velocities,
                    snapshot_size,
                ),
                (
                    &self.angular_velocities,
                    &slot.angular_velocities,
                    snapshot_size,
                ),
                (
                    &self.mechanism.coordinates,
                    &slot.coordinates,
                    u64::from(self.mechanism.coordinate_count) * 8,
                ),
            ] {
                if size != 0 {
                    encoder.copy_buffer_to_buffer(source, 0, destination, 0, size);
                }
            }
            Some(index)
        });
        let encoding_ms = encoding_started.elapsed().as_secs_f64() * 1_000.0;
        let finalization_started = Instant::now();
        let command_buffer = encoder.finish();
        let finalization_ms = finalization_started.elapsed().as_secs_f64() * 1_000.0;
        let submission_started = Instant::now();
        let submission_index = queue.submit([command_buffer]);
        let submission_finished = Instant::now();
        let submission_ms = submission_finished
            .duration_since(submission_started)
            .as_secs_f64()
            * 1_000.0;
        let readback_setup_started = Instant::now();
        if let (Some(slots), Some(index)) = (&mut async_readbacks, async_slot_index) {
            begin_async_mapping(
                &mut slots[index],
                submission_sequence,
                tick_index,
                snapshot_slot,
                submission_finished,
                self.readback_timing_enabled.load(Ordering::Acquire),
            );
        }
        let readback_setup_ms = readback_setup_started.elapsed().as_secs_f64() * 1_000.0;
        GpuTickSubmission {
            submission_sequence,
            tick_index,
            snapshot_slot,
            submission_index,
            cpu_timings: GpuSubmissionTimings {
                encoding_ms,
                finalization_ms,
                submission_ms,
                readback_setup_ms,
            },
        }
    }

    fn encode_mechanism_passes(&self, encoder: &mut wgpu::CommandEncoder) {
        let mechanism = &self.mechanism;
        let workgroups = self.body_count.div_ceil(256);
        direct_compute_pass(
            encoder,
            "mechanic prepare drive constraints",
            &mechanism.prepare_drives_pipeline,
            &mechanism.prepare_drives_bind_group,
            self.bearing_count.div_ceil(256),
            None,
        );
        self.encode_bearing_velocity_projection(encoder, true);
        direct_compute_pass(
            encoder,
            "mechanic advance reduced coordinates",
            &mechanism.advance_coordinates_pipeline,
            &mechanism.advance_coordinates_bind_group,
            workgroups,
            None,
        );
        self.encode_mechanism_pose_projection(encoder);
        direct_compute_pass(
            encoder,
            "mechanic reconstruct body velocities",
            &mechanism.reconstruct_velocities_pipeline,
            &mechanism.reconstruct_velocities_bind_group,
            1,
            timestamp_writes(self.timestamps.as_ref(), None, Some(3)),
        );
    }

    // Metal drops timestamps on empty passes. A bit-preserving atomic access
    // orders markers against pose readers/writers, including zero-work dispatches.
    fn encode_terrain_timestamp(&self, encoder: &mut wgpu::CommandEncoder, index: u32) {
        if let Some(timestamps) = &self.timestamps {
            let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
                label: Some("mechanic terrain stage boundary"),
                timestamp_writes: timestamp_writes(self.timestamps.as_ref(), Some(index), None),
            });
            pass.set_pipeline(&timestamps.boundary);
            pass.set_bind_group(0, &timestamps.boundary_bindings, &[]);
            pass.dispatch_workgroups(1, 1, 1);
        }
    }

    fn encode_recovery_pose_projection(
        &self,
        encoder: &mut wgpu::CommandEncoder,
        gate: &wgpu::Buffer,
    ) {
        self.encode_mechanism_pose_projection_gated(encoder, Some(gate));
    }

    fn encode_mechanism_pose_projection(&self, encoder: &mut wgpu::CommandEncoder) {
        self.encode_mechanism_pose_projection_gated(encoder, None);
    }

    fn encode_mechanism_pose_projection_gated(
        &self,
        encoder: &mut wgpu::CommandEncoder,
        gate: Option<&wgpu::Buffer>,
    ) {
        let mechanism = &self.mechanism;
        let workgroups = self.body_count.div_ceil(256);
        self.encode_mechanism_forward_kinematics(encoder, gate, 0);
        if mechanism.closure_count > 0 {
            const CLOSURE_CORRECTION_STEPS: u32 = 12;
            for step in 0..CLOSURE_CORRECTION_STEPS {
                encoder.clear_buffer(&mechanism.closure_accumulators, 0, None);
                encoder.clear_buffer(&mechanism.closure_state, 0, None);
                if step == 0
                    && let Some(gate) = gate
                {
                    indirect_compute_pass(
                        encoder,
                        "mechanic evaluate recovery closures",
                        &mechanism.evaluate_closures_pipeline,
                        &mechanism.evaluate_closures_bind_group,
                        gate,
                        32,
                        None,
                    );
                } else if step == 0 {
                    direct_compute_pass(
                        encoder,
                        "mechanic evaluate closures",
                        &mechanism.evaluate_closures_pipeline,
                        &mechanism.evaluate_closures_bind_group,
                        self.bearing_count.div_ceil(256),
                        None,
                    );
                } else {
                    indirect_compute_pass(
                        encoder,
                        "mechanic evaluate closures",
                        &mechanism.evaluate_closures_pipeline,
                        &mechanism.evaluate_closures_bind_group,
                        &mechanism.closure_indirect_args,
                        0,
                        None,
                    );
                }
                direct_compute_pass(
                    encoder,
                    "mechanic finalize closures",
                    &mechanism.finalize_closures_pipeline,
                    &mechanism.finalize_closures_bind_group,
                    1,
                    None,
                );
                indirect_compute_pass(
                    encoder,
                    "mechanic closure Newton PCG step",
                    &mechanism.apply_closure_step_pipeline,
                    &mechanism.apply_closure_step_bind_group,
                    &mechanism.closure_indirect_args,
                    12,
                    None,
                );
                self.encode_mechanism_forward_kinematics(
                    encoder,
                    Some(&mechanism.closure_indirect_args),
                    12,
                );
            }
        }
        let (pipeline, bindings) = if mechanism.final_is_a {
            (
                &mechanism.publish_a_pipeline,
                &mechanism.publish_a_bind_group,
            )
        } else {
            (
                &mechanism.publish_b_pipeline,
                &mechanism.publish_b_bind_group,
            )
        };
        if let Some(gate) = gate {
            indirect_compute_pass(
                encoder,
                "mechanic publish recovered mechanism poses",
                pipeline,
                bindings,
                gate,
                0,
                None,
            );
            return;
        }
        direct_compute_pass(
            encoder,
            "mechanic publish mechanism poses",
            pipeline,
            bindings,
            workgroups,
            None,
        );
    }

    fn encode_bearing_velocity_projection(
        &self,
        encoder: &mut wgpu::CommandEncoder,
        timestamp_start: bool,
    ) {
        if uses_fused_velocity_schedule(self.bearing_count, self.body_count) {
            direct_compute_pass(
                encoder,
                "mechanic fused small bearing velocity projection",
                &self.mechanism.project_small_velocity_pipeline,
                &self.mechanism.project_small_velocity_bind_group,
                1,
                if timestamp_start {
                    timestamp_writes(self.timestamps.as_ref(), Some(2), None)
                } else {
                    None
                },
            );
            return;
        }
        for iteration in 0..self.pipeline_config.solver_iterations.max(1) {
            self.encode_bearing_velocity_projection_iteration(
                encoder,
                timestamp_start && iteration == 0,
                false,
            );
        }
    }

    fn encode_bearing_velocity_projection_iteration(
        &self,
        encoder: &mut wgpu::CommandEncoder,
        timestamp_start: bool,
        serial: bool,
    ) {
        let mechanism = &self.mechanism;
        if serial {
            direct_compute_pass(
                encoder,
                "mechanic project bearing velocities serially",
                &mechanism.project_velocity_serial_pipeline,
                &mechanism.project_velocity_serial_bind_group,
                1,
                if timestamp_start {
                    timestamp_writes(self.timestamps.as_ref(), Some(2), None)
                } else {
                    None
                },
            );
            return;
        }
        direct_compute_pass(
            encoder,
            "mechanic project bearing velocities",
            &mechanism.project_velocity_pipeline,
            &mechanism.project_velocity_bind_group,
            self.bearing_count.div_ceil(256),
            if timestamp_start {
                timestamp_writes(self.timestamps.as_ref(), Some(2), None)
            } else {
                None
            },
        );
        direct_compute_pass(
            encoder,
            "mechanic apply bearing velocity deltas",
            &mechanism.apply_velocity_pipeline,
            &mechanism.apply_velocity_bind_group,
            self.body_count.div_ceil(256),
            None,
        );
    }

    fn encode_contact_bearing_velocity_projection_iteration(
        &self,
        encoder: &mut wgpu::CommandEncoder,
        serial: bool,
    ) {
        if serial {
            indirect_compute_pass(
                encoder,
                "mechanic project contact bearing velocities serially",
                &self.mechanism.project_velocity_serial_pipeline,
                &self.mechanism.project_velocity_serial_bind_group,
                &self.collision.indirect_args,
                48,
                None,
            );
        } else {
            self.encode_bearing_velocity_projection_iteration(encoder, false, false);
        }
    }

    fn encode_post_contact_mechanism(&self, encoder: &mut wgpu::CommandEncoder) {
        let mechanism = &self.mechanism;
        if !mechanism.has_dynamic_root {
            self.encode_bearing_velocity_projection(encoder, false);
        }
        direct_compute_pass(
            encoder,
            "mechanic capture reduced velocities",
            &mechanism.capture_coordinates_pipeline,
            &mechanism.capture_coordinates_bind_group,
            self.body_count.div_ceil(256),
            if mechanism.has_dynamic_root {
                timestamp_writes(self.timestamps.as_ref(), None, Some(9))
            } else {
                None
            },
        );
        if !mechanism.has_dynamic_root {
            direct_compute_pass(
                encoder,
                "mechanic reconstruct grounded post-contact velocities",
                &mechanism.reconstruct_velocities_pipeline,
                &mechanism.reconstruct_velocities_bind_group,
                1,
                timestamp_writes(self.timestamps.as_ref(), None, Some(9)),
            );
        }
    }

    fn encode_mechanism_forward_kinematics(
        &self,
        encoder: &mut wgpu::CommandEncoder,
        indirect: Option<&wgpu::Buffer>,
        indirect_offset: u64,
    ) {
        let mechanism = &self.mechanism;
        let workgroups = self.body_count.div_ceil(256);
        let mut dispatch = |label: &str,
                            pipeline: &wgpu::ComputePipeline,
                            bindings: &wgpu::BindGroup,
                            timestamp_writes| {
            if let Some(indirect) = indirect {
                indirect_compute_pass(
                    encoder,
                    label,
                    pipeline,
                    bindings,
                    indirect,
                    indirect_offset,
                    timestamp_writes,
                );
            } else {
                direct_compute_pass(
                    encoder,
                    label,
                    pipeline,
                    bindings,
                    workgroups,
                    timestamp_writes,
                );
            }
        };
        dispatch(
            "mechanic prepare mechanism links",
            &mechanism.prepare_pipeline,
            &mechanism.prepare_bind_group,
            None,
        );
        let mut final_is_a = true;
        for _ in 0..mechanism.pointer_jump_rounds {
            if final_is_a {
                dispatch(
                    "mechanic mechanism jump A to B",
                    &mechanism.jump_a_to_b_pipeline,
                    &mechanism.jump_a_to_b_bind_group,
                    None,
                );
            } else {
                dispatch(
                    "mechanic mechanism jump B to A",
                    &mechanism.jump_b_to_a_pipeline,
                    &mechanism.jump_b_to_a_bind_group,
                    None,
                );
            }
            final_is_a = !final_is_a;
        }
        debug_assert_eq!(final_is_a, mechanism.final_is_a);
    }

    #[allow(clippy::too_many_lines)]
    fn encode_collision_passes(&self, encoder: &mut wgpu::CommandEncoder) {
        let collision = &self.collision;
        let lbvh = &collision.lbvh;
        let sort_workgroups = lbvh.sort_count.div_ceil(256);
        direct_compute_pass(
            encoder,
            "mechanic world inverse inertias",
            &collision.update_world_masses_pipeline,
            &collision.update_world_masses_bind_group,
            self.body_count.div_ceil(256),
            timestamp_writes(self.timestamps.as_ref(), Some(4), None),
        );
        direct_compute_pass(
            encoder,
            "mechanic LBVH Morton codes",
            &lbvh.compute_morton_pipeline,
            &lbvh.compute_morton_bind_group,
            sort_workgroups,
            None,
        );
        direct_compute_pass(
            encoder,
            "mechanic LBVH local sort",
            &lbvh.sort_local_initial_pipeline,
            &lbvh.sort_local_initial_bind_group,
            sort_workgroups,
            None,
        );
        for &(parameter_offset, local_merge) in &lbvh.sort_steps {
            encoder.copy_buffer_to_buffer(
                &lbvh.sort_params_upload,
                parameter_offset,
                &lbvh.sort_params,
                0,
                16,
            );
            let (pipeline, bindings, label) = if local_merge {
                (
                    &lbvh.sort_local_merge_pipeline,
                    &lbvh.sort_local_merge_bind_group,
                    "mechanic LBVH local merge",
                )
            } else {
                (
                    &lbvh.sort_global_pipeline,
                    &lbvh.sort_global_bind_group,
                    "mechanic LBVH global merge",
                )
            };
            direct_compute_pass(encoder, label, pipeline, bindings, sort_workgroups, None);
        }
        direct_compute_pass(
            encoder,
            "mechanic LBVH topology",
            &lbvh.build_topology_pipeline,
            &lbvh.build_topology_bind_group,
            self.collider_count.saturating_sub(1).max(1).div_ceil(256),
            None,
        );
        direct_compute_pass(
            encoder,
            "mechanic LBVH leaves",
            &lbvh.prepare_leaves_pipeline,
            &lbvh.prepare_leaves_bind_group,
            self.collider_count.div_ceil(256),
            None,
        );
        direct_compute_pass(
            encoder,
            "mechanic LBVH bounds",
            &lbvh.build_bounds_pipeline,
            &lbvh.build_bounds_bind_group,
            self.collider_count.div_ceil(256),
            None,
        );
        direct_compute_pass(
            encoder,
            "mechanic LBVH traversal",
            &lbvh.traverse_pipeline,
            &lbvh.traverse_bind_group,
            self.collider_count.div_ceil(256),
            None,
        );
        direct_compute_pass(
            encoder,
            "mechanic finalize pairs",
            &lbvh.finalize_pairs_pipeline,
            &lbvh.finalize_pairs_bind_group,
            1,
            timestamp_writes(self.timestamps.as_ref(), None, Some(5)),
        );
        indirect_compute_pass(
            encoder,
            "mechanic OBB SAT",
            &collision.narrowphase_pipeline,
            &collision.narrowphase_bind_group,
            &collision.indirect_args,
            0,
            timestamp_writes(self.timestamps.as_ref(), Some(6), None),
        );
        if self.pipeline_config.ground_plane_enabled {
            direct_compute_pass(
                encoder,
                "mechanic ground contacts",
                &collision.ground_contacts_pipeline,
                &collision.ground_contacts_bind_group,
                self.collider_count.div_ceil(256),
                None,
            );
        }
        if let Some(bindings) = &collision.terrain_bind_group
            && collision.terrain_triangle_count > 0
        {
            direct_compute_pass(
                encoder,
                "mechanic terrain BVH contacts",
                &collision.terrain_pipeline,
                bindings,
                self.collider_count.div_ceil(256),
                timestamp_writes(self.timestamps.as_ref(), Some(14), Some(15)),
            );
        }
        direct_compute_pass(
            encoder,
            "mechanic finalize contacts",
            &collision.finalize_contacts_pipeline,
            &collision.finalize_contacts_bind_group,
            1,
            timestamp_writes(self.timestamps.as_ref(), None, Some(7)),
        );
        indirect_compute_pass(
            encoder,
            "mechanic prepare persistent contacts",
            &collision.select_active_pipeline,
            &collision.select_active_bind_group,
            &collision.indirect_args,
            12,
            timestamp_writes(self.timestamps.as_ref(), Some(8), None),
        );
        direct_compute_pass(
            encoder,
            "mechanic finalize active contacts",
            &collision.finalize_active_pipeline,
            &collision.finalize_active_bind_group,
            1,
            None,
        );
        if self.mechanism.active
            && !self.mechanism.has_dynamic_root
            && uses_fused_velocity_schedule(self.bearing_count, self.body_count)
        {
            self.encode_grounded_contact_solver_pass(encoder);
            return;
        }
        if self.solver_route() == GpuSolverRoute::General || collision.terrain_triangle_count > 0 {
            indirect_compute_pass(
                encoder,
                "mechanic count body contacts",
                &collision.count_body_contacts_pipeline,
                &collision.count_body_contacts_bind_group,
                &collision.indirect_args,
                24,
                None,
            );
        }
        indirect_compute_pass(
            encoder,
            "mechanic contact warm start",
            &collision.warm_start_pipeline,
            &collision.warm_start_bind_group,
            &collision.indirect_args,
            24,
            None,
        );
        indirect_compute_pass(
            encoder,
            "mechanic contact warm start apply",
            &collision.solve_apply_pipeline,
            &collision.solve_apply_bind_group,
            &collision.indirect_args,
            36,
            None,
        );
        let serial_mechanism = self.mechanism.active
            && self.mechanism.has_dynamic_root
            && uses_fused_contact_schedule(
                self.bearing_count,
                self.pipeline_config.ground_plane_enabled,
            );
        if serial_mechanism {
            direct_compute_pass(
                encoder,
                "mechanic fused small mechanism contacts",
                &collision.solve_small_mechanism_pipeline,
                &collision.solve_small_mechanism_bind_group,
                1,
                None,
            );
        } else if self.mechanism.active && self.mechanism.has_dynamic_root {
            self.encode_contact_bearing_velocity_projection_iteration(encoder, serial_mechanism);
        }
        let iterations = self.pipeline_config.solver_iterations.max(1);
        if !serial_mechanism {
            for _ in 1..iterations {
                indirect_compute_pass(
                    encoder,
                    "mechanic contact projection",
                    &collision.solve_accumulate_pipeline,
                    &collision.solve_accumulate_bind_group,
                    &collision.indirect_args,
                    24,
                    None,
                );
                indirect_compute_pass(
                    encoder,
                    "mechanic contact apply",
                    &collision.solve_apply_pipeline,
                    &collision.solve_apply_bind_group,
                    &collision.indirect_args,
                    36,
                    None,
                );
                if self.mechanism.active && self.mechanism.has_dynamic_root {
                    self.encode_contact_bearing_velocity_projection_iteration(encoder, false);
                }
            }
        }
        indirect_compute_pass(
            encoder,
            "mechanic persist contact manifolds",
            &collision.persist_contacts_pipeline,
            &collision.persist_contacts_bind_group,
            &collision.indirect_args,
            24,
            if self.mechanism.active {
                None
            } else {
                timestamp_writes(self.timestamps.as_ref(), None, Some(9))
            },
        );
    }

    /// Records the small grounded mechanism's contact reconciliation in one
    /// Metal compute pass. Dispatch order and iteration count match the general
    /// schedule; eliminating empty pass boundaries matters when no contacts exist.
    fn encode_grounded_contact_solver_pass(&self, encoder: &mut wgpu::CommandEncoder) {
        let collision = &self.collision;
        let mechanism = &self.mechanism;
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("mechanic grounded contact solver"),
            timestamp_writes: timestamp_writes(self.timestamps.as_ref(), None, Some(9)),
        });
        indirect_dispatch_in_pass(
            &mut pass,
            &collision.count_body_contacts_pipeline,
            &collision.count_body_contacts_bind_group,
            &collision.indirect_args,
            24,
        );
        indirect_dispatch_in_pass(
            &mut pass,
            &collision.warm_start_pipeline,
            &collision.warm_start_bind_group,
            &collision.indirect_args,
            24,
        );
        indirect_dispatch_in_pass(
            &mut pass,
            &collision.solve_apply_pipeline,
            &collision.solve_apply_bind_group,
            &collision.indirect_args,
            36,
        );
        for _ in 1..self.pipeline_config.solver_iterations.max(1) {
            indirect_dispatch_in_pass(
                &mut pass,
                &collision.solve_accumulate_pipeline,
                &collision.solve_accumulate_bind_group,
                &collision.indirect_args,
                24,
            );
            indirect_dispatch_in_pass(
                &mut pass,
                &collision.solve_apply_pipeline,
                &collision.solve_apply_bind_group,
                &collision.indirect_args,
                36,
            );
        }
        indirect_dispatch_in_pass(
            &mut pass,
            &collision.persist_contacts_pipeline,
            &collision.persist_contacts_bind_group,
            &collision.indirect_args,
            24,
        );
        indirect_dispatch_in_pass(
            &mut pass,
            &mechanism.project_small_velocity_pipeline,
            &mechanism.project_small_velocity_bind_group,
            &collision.indirect_args,
            48,
        );
        indirect_dispatch_in_pass(
            &mut pass,
            &mechanism.capture_coordinates_pipeline,
            &mechanism.capture_coordinates_bind_group,
            &collision.indirect_args,
            36,
        );
        indirect_dispatch_in_pass(
            &mut pass,
            &mechanism.reconstruct_velocities_pipeline,
            &mechanism.reconstruct_velocities_bind_group,
            &collision.indirect_args,
            48,
        );
        if let Some(timestamps) = &self.timestamps {
            pass.set_pipeline(&timestamps.boundary);
            pass.set_bind_group(0, &timestamps.boundary_bindings, &[]);
            pass.dispatch_workgroups(1, 1, 1);
        }
    }

    /// Polls asynchronous telemetry and prototype-render staging without
    /// waiting for queue completion.
    ///
    /// Completed ticks are returned in submission order. `None` means the GPU
    /// has not completed another staged tick yet.
    ///
    /// # Errors
    ///
    /// Returns [`GpuReadbackError`] if device polling or a completed mapping
    /// failed. The caller should latch that as a terminal simulation failure.
    pub fn poll_tick_readback(
        &self,
        device: &wgpu::Device,
    ) -> Result<Option<GpuCompletedTickReadback>, GpuReadbackError> {
        let poll_started = self
            .readback_timing_enabled
            .load(Ordering::Acquire)
            .then(Instant::now);
        device
            .poll(wgpu::PollType::Poll)
            .map_err(|error| GpuReadbackError::DevicePoll(error.to_string()))?;
        let mut slots = self
            .async_readbacks
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);

        for slot in &mut *slots {
            let Some(pending) = &mut slot.pending else {
                continue;
            };
            while pending.remaining_callbacks > 0 {
                match pending.receiver.try_recv() {
                    Ok((Ok(()), observed_at)) => {
                        pending.remaining_callbacks -= 1;
                        pending.callbacks_completed_at =
                            pending.callbacks_completed_at.max(observed_at);
                    }
                    Ok((Err(error), _)) => {
                        unmap_async_slot(slot);
                        slot.pending = None;
                        return Err(GpuReadbackError::BufferMap(error));
                    }
                    Err(mpsc::TryRecvError::Empty) => break,
                    Err(mpsc::TryRecvError::Disconnected) => {
                        unmap_async_slot(slot);
                        slot.pending = None;
                        return Err(GpuReadbackError::CallbackLost);
                    }
                }
            }
        }

        let Some(slot_index) =
            oldest_completed_readback(slots.iter().enumerate().filter_map(|(index, slot)| {
                let pending = slot.pending.as_ref()?;
                Some((
                    index,
                    pending.submission_sequence,
                    pending.remaining_callbacks,
                ))
            }))
        else {
            return Ok(None);
        };
        let slot = &mut slots[slot_index];
        let Some(pending) = slot.pending.take() else {
            return Ok(None);
        };
        let diagnostics = {
            let bytes = slot
                .diagnostics
                .get_mapped_range(0..u64::try_from(size_of::<GpuDiagnostics>()).unwrap_or(32));
            bytemuck::pod_read_unaligned::<GpuDiagnostics>(&bytes)
        };
        let timestamp_values = slot.timestamps.as_ref().map(|buffer| {
            bytemuck::pod_read_unaligned::<[u64; 28]>(&buffer.get_mapped_range(0..224))
        });
        let positions = mapped_rows::<[f32; 4]>(&slot.positions, self.body_count);
        let rotations = mapped_rows::<[f32; 4]>(&slot.rotations, self.body_count);
        let linear = mapped_rows::<[f32; 4]>(&slot.linear_velocities, self.body_count);
        let angular = mapped_rows::<[f32; 4]>(&slot.angular_velocities, self.body_count);
        let coordinates = mapped_rows::<GpuMechanismCoordinate>(
            &slot.coordinates,
            self.mechanism.coordinate_count,
        );
        unmap_async_slot(slot);

        Ok(Some(GpuCompletedTickReadback {
            submission_sequence: pending.submission_sequence,
            tick_index: pending.tick_index,
            snapshot_slot: pending.snapshot_slot,
            submission_to_readback_ms: pending.submitted_at.elapsed().as_secs_f64() * 1_000.0,
            callbacks_completed_at: pending.callbacks_completed_at,
            submission_to_callbacks_ms: pending
                .callbacks_completed_at
                .map(|at| at.duration_since(pending.submitted_at).as_secs_f64() * 1_000.0),
            callbacks_during_poll: pending
                .callbacks_completed_at
                .zip(poll_started)
                .map(|(at, start)| at >= start),
            diagnostics: self.decode_tick_readback(diagnostics, timestamp_values),
            velocities: linear
                .into_iter()
                .zip(angular)
                .map(|(linear, angular)| GpuVelocity { linear, angular })
                .collect(),
            coordinates,
            transforms: positions
                .into_iter()
                .zip(rotations)
                .map(|(position, rotation)| GpuTransform { position, rotation })
                .collect(),
        }))
    }

    fn decode_tick_readback(
        &self,
        diagnostics: GpuDiagnostics,
        timestamp_values: Option<[u64; 28]>,
    ) -> GpuTickReadback {
        let timestamp_readback =
            timestamp_values
                .zip(self.timestamps.as_ref())
                .map(|(values, timestamps)| {
                    let elapsed = |start, end| {
                        timestamp_milliseconds(
                            values[start],
                            values[end],
                            timestamps.period_nanoseconds,
                        )
                    };
                    let timings = GpuKernelTimings {
                        integration_ms: elapsed(0, 1),
                        terrain_traversal_ms: if self.pipeline_config.collisions_enabled
                            && self.collision.terrain_triangle_count > 0
                        {
                            elapsed(14, 15)
                        } else {
                            0.0
                        },
                        rotational_sweep_ms: if self.pipeline_config.collisions_enabled
                            && self.collision.terrain_triangle_count > 0
                        {
                            elapsed(16, 17)
                        } else {
                            0.0
                        },
                        terrain_recovery_ms: if self.pipeline_config.collisions_enabled
                            && self.collision.terrain_triangle_count > 0
                        {
                            elapsed(18, 19)
                        } else {
                            0.0
                        },
                        recovery_projection_ms: if self.pipeline_config.collisions_enabled
                            && self.collision.terrain_triangle_count > 0
                            && self.mechanism.active
                        {
                            elapsed(20, 21) + elapsed(22, 23) + elapsed(24, 25)
                        } else {
                            0.0
                        },
                        mechanism_ms: if self.mechanism.active {
                            elapsed(2, 3)
                        } else {
                            0.0
                        },
                        broadphase_ms: if self.pipeline_config.collisions_enabled {
                            elapsed(4, 5)
                        } else {
                            0.0
                        },
                        narrowphase_ms: if self.pipeline_config.collisions_enabled {
                            elapsed(6, 7)
                        } else {
                            0.0
                        },
                        contact_solver_ms: if self.pipeline_config.collisions_enabled {
                            elapsed(8, 9)
                        } else {
                            0.0
                        },
                        bearings_ms: if self.bearing_count > 0 {
                            elapsed(10, 11)
                        } else {
                            0.0
                        },
                        snapshot_ms: elapsed(12, 13),
                    };
                    let total = timings.rotational_sweep_ms
                        + timings.terrain_recovery_ms
                        + timings.integration_ms
                        + timings.mechanism_ms
                        + timings.broadphase_ms
                        + timings.narrowphase_ms
                        + timings.contact_solver_ms
                        + timings.bearings_ms
                        + timings.snapshot_ms;
                    (total, timings)
                });
        GpuTickReadback {
            execution: GpuExecutionEvidence {
                stage_mask: diagnostics.executed_stage_mask,
                integrated_bodies: diagnostics.integrated_bodies,
                published_bodies: diagnostics.published_bodies,
                validated_bearings: diagnostics.validated_bearings,
            },
            gpu_tick_ms: timestamp_readback.map(|(total, _)| total),
            kernel_timings: timestamp_readback.map(|(_, timings)| timings),
            error_flags: diagnostics.error_flags,
            pair_count: diagnostics.pair_count,
            contact_count: diagnostics.contact_count,
            active_contact_count: diagnostics.active_contact_count,
            planned_solver_sweeps: diagnostics.planned_solver_sweeps,
            executed_solver_sweeps: diagnostics.executed_solver_sweeps,
            anchor_residual_meters: diagnostic_units(diagnostics.max_anchor_micrometers),
            axis_residual_degrees: diagnostic_units(diagnostics.max_axis_microdegrees),
        }
    }

    /// Reads only stage timestamps and fixed-size diagnostics after a completed
    /// submission. Authoritative body state remains GPU-resident.
    ///
    /// # Errors
    ///
    /// Returns [`GpuReadbackError`] if device polling or either fixed-size map fails.
    pub fn read_last_tick(
        &self,
        device: &wgpu::Device,
    ) -> Result<GpuTickReadback, GpuReadbackError> {
        map_for_read(device, &self.diagnostics_readback)?;
        let diagnostics = {
            let bytes = self
                .diagnostics_readback
                .get_mapped_range(0..u64::try_from(size_of::<GpuDiagnostics>()).unwrap_or(32));
            bytemuck::pod_read_unaligned::<GpuDiagnostics>(&bytes)
        };
        self.diagnostics_readback.unmap();

        let timestamp_values = self
            .timestamps
            .as_ref()
            .map(|timestamps| {
                map_for_read(device, &timestamps.readback)?;
                let values = bytemuck::pod_read_unaligned::<[u64; 28]>(
                    &timestamps.readback.get_mapped_range(0..224),
                );
                timestamps.readback.unmap();
                Ok::<_, GpuReadbackError>(values)
            })
            .transpose()?;
        Ok(self.decode_tick_readback(diagnostics, timestamp_values))
    }

    /// Copies one published snapshot to CPU memory for prototype renderers.
    ///
    /// Production rendering should consume [`SnapshotBuffers`] directly and avoid
    /// this synchronous readback.
    ///
    /// # Errors
    ///
    /// Returns [`GpuReadbackError`] when `slot` is invalid or GPU mapping fails.
    pub fn read_snapshot_transforms(
        &self,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        slot: u8,
    ) -> Result<Vec<GpuTransform>, GpuReadbackError> {
        let snapshot = self
            .snapshot(slot)
            .ok_or(GpuReadbackError::InvalidSnapshotSlot(slot))?;
        let byte_len = u64::from(self.body_count) * 16;
        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("mechanic snapshot readback"),
        });
        encoder.copy_buffer_to_buffer(
            snapshot.positions(),
            0,
            &self.snapshot_positions_readback,
            0,
            byte_len,
        );
        encoder.copy_buffer_to_buffer(
            snapshot.rotations(),
            0,
            &self.snapshot_rotations_readback,
            0,
            byte_len,
        );
        queue.submit([encoder.finish()]);

        let positions = read_vec4_buffer(device, &self.snapshot_positions_readback, byte_len)?;
        let rotations = read_vec4_buffer(device, &self.snapshot_rotations_readback, byte_len)?;
        Ok(positions
            .into_iter()
            .zip(rotations)
            .map(|(position, rotation)| GpuTransform { position, rotation })
            .collect())
    }

    /// Whether the shared device supports real GPU timestamp queries.
    pub const fn has_gpu_timestamps(&self) -> bool {
        self.timestamps.is_some()
    }

    /// Snapshot buffers for direct GPU-driven render consumption.
    pub fn snapshot(&self, slot: u8) -> Option<&SnapshotBuffers> {
        self.snapshots.get(usize::from(slot))
    }

    /// Number of uploaded compound rows.
    pub const fn body_count(&self) -> u32 {
        self.body_count
    }

    /// Current authoritative position buffer.
    pub const fn positions(&self) -> &wgpu::Buffer {
        &self.positions
    }

    /// Current authoritative orientation buffer.
    pub const fn rotations(&self) -> &wgpu::Buffer {
        &self.rotations
    }

    /// Current authoritative linear-velocity buffer.
    pub const fn linear_velocities(&self) -> &wgpu::Buffer {
        &self.linear_velocities
    }

    /// Current authoritative angular-velocity buffer.
    pub const fn angular_velocities(&self) -> &wgpu::Buffer {
        &self.angular_velocities
    }

    /// Current inverse-mass struct-of-arrays buffer.
    pub const fn inverse_masses(&self) -> &wgpu::Buffer {
        &self.inverse_masses
    }

    /// Replaces the drive parameters of every mechanism coordinate.
    ///
    /// This is the one write permitted while the simulation is running: it
    /// changes no topology, mass, or buffer size, so compiled row indices stay
    /// valid and a control block can be retuned without recompiling.
    ///
    /// # Errors
    ///
    /// Returns [`GpuPhysicsError::DriveStateCount`] unless one row is supplied
    /// per compiled tree bearing.
    pub fn write_mechanism_drives(
        &self,
        queue: &wgpu::Queue,
        drives: &[GpuMechanismDrive],
    ) -> Result<(), GpuPhysicsError> {
        let required = usize::try_from(self.mechanism.coordinate_count).unwrap_or(usize::MAX);
        if drives.len() != required {
            return Err(GpuPhysicsError::DriveStateCount {
                provided: drives.len(),
                required,
            });
        }
        if !drives.is_empty() {
            queue.write_buffer(&self.mechanism.drives, 0, cast_slice(drives));
            for (coordinate, drive) in drives.iter().enumerate() {
                let row = self.mechanism.drive_constraint_rows[coordinate];
                let offset = u64::from(row)
                    * u64::try_from(size_of::<GpuDriveConstraint>()).unwrap_or(u64::MAX)
                    + u64::try_from(size_of::<GpuBearing>()).unwrap_or(u64::MAX);
                queue.write_buffer(&self.mechanism.drive_constraints, offset, bytes_of(drive));
            }
        }
        Ok(())
    }

    /// Replaces the permitted bearing-coordinate state at a paused/load boundary.
    ///
    /// # Errors
    ///
    /// Returns [`GpuPhysicsError::CoordinateStateCount`] unless one row is
    /// supplied for every tree bearing in the compiled mechanism forest.
    pub fn initialize_mechanism_coordinates(
        &self,
        queue: &wgpu::Queue,
        coordinates: &[GpuMechanismCoordinate],
    ) -> Result<(), GpuPhysicsError> {
        let required = usize::try_from(self.mechanism.coordinate_count).unwrap_or(usize::MAX);
        if coordinates.len() != required {
            return Err(GpuPhysicsError::CoordinateStateCount {
                provided: coordinates.len(),
                required,
            });
        }
        if !coordinates.is_empty() {
            queue.write_buffer(&self.mechanism.coordinates, 0, cast_slice(coordinates));
        }
        Ok(())
    }
}

#[allow(
    clippy::similar_names,
    clippy::too_many_arguments,
    clippy::too_many_lines
)]
fn create_mechanism_resources(
    device: &wgpu::Device,
    pipelines: &GpuPhysicsPipelines,
    creation: &CompiledCreation,
    config: &wgpu::Buffer,
    positions: &wgpu::Buffer,
    rotations: &wgpu::Buffer,
    diagnostics: &wgpu::Buffer,
    bearings: &wgpu::Buffer,
    masses: &wgpu::Buffer,
    _spatial_inertias: &wgpu::Buffer,
    linear_velocities: &wgpu::Buffer,
    angular_velocities: &wgpu::Buffer,
) -> MechanismResources {
    let body_count = creation.compounds.len();
    let has_dynamic_root =
        creation
            .loop_topology
            .body_parents
            .iter()
            .enumerate()
            .any(|(body, topology)| {
                topology.is_root && creation.compounds[body].mass_properties.inverse_mass > 0.0
            });
    let bearing_rows = creation
        .bearings
        .iter()
        .enumerate()
        .map(|(row, bearing)| (bearing.source_bearing, row))
        .collect::<BTreeMap<_, _>>();
    let coordinate_by_bearing = creation
        .loop_topology
        .tree_bearings
        .iter()
        .enumerate()
        .map(|(coordinate, &bearing)| (bearing, coordinate))
        .collect::<BTreeMap<_, _>>();
    let powered_components = creation
        .loop_topology
        .body_parents
        .iter()
        .filter_map(|body| {
            let coordinate = *coordinate_by_bearing.get(&body.tree_bearing?)?;
            (creation.coordinate_drives.get(coordinate)?.mode != mechanic_core::DriveMode::Passive)
                .then_some(body.component_index)
        })
        .collect::<BTreeSet<_>>();
    let root_flags = creation
        .loop_topology
        .body_parents
        .iter()
        .map(|body| {
            let powered_coordinate = body
                .tree_bearing
                .and_then(|bearing| coordinate_by_bearing.get(&bearing))
                .and_then(|&coordinate| creation.coordinate_drives.get(coordinate))
                .is_some_and(|drive| drive.mode != mechanic_core::DriveMode::Passive);
            u32::from(body.is_root)
                | (u32::from(
                    powered_coordinate
                        || (body.is_root && powered_components.contains(&body.component_index)),
                ) << 1)
        })
        .collect::<Vec<_>>();
    let bodies = creation
        .compounds
        .iter()
        .enumerate()
        .map(|(body, compound)| {
            let topology = creation.loop_topology.body_parents[body];
            if topology.is_root {
                return GpuMechanismBody {
                    metadata: [u32::try_from(body).unwrap_or(u32::MAX), u32::MAX, 0, 1],
                    traversal: [
                        topology.component_index,
                        topology.depth,
                        topology.preorder_index,
                        topology.postorder_index,
                    ],
                    bind_relative_position: [0.0; 4],
                    bind_relative_rotation: [0.0, 0.0, 0.0, 1.0],
                };
            }
            let parent = topology.parent_body as usize;
            let bearing = topology.tree_bearing.expect("non-root has a tree bearing");
            let bearing_index = bearing_rows[&bearing];
            let parent_compound = &creation.compounds[parent];
            let child_compound = compound;
            let inverse_parent = parent_compound.root_rotation.inverse();
            let relative_position = inverse_parent
                * (child_compound.root_translation - parent_compound.root_translation);
            let relative_rotation = (inverse_parent * child_compound.root_rotation).normalize();
            GpuMechanismBody {
                metadata: [
                    u32::try_from(parent).unwrap_or(u32::MAX),
                    u32::try_from(bearing_index).unwrap_or(u32::MAX),
                    topology.bearing_direction,
                    0,
                ],
                traversal: [
                    topology.component_index,
                    topology.depth,
                    topology.preorder_index,
                    topology.postorder_index,
                ],
                bind_relative_position: vec4(relative_position, 0.0),
                bind_relative_rotation: [
                    relative_rotation.x,
                    relative_rotation.y,
                    relative_rotation.z,
                    relative_rotation.w,
                ],
            }
        })
        .collect::<Vec<_>>();
    let maximum_depth = creation
        .loop_topology
        .body_parents
        .iter()
        .map(|body| body.depth)
        .max()
        .unwrap_or(0);
    let mut preorder = (0..body_count).collect::<Vec<_>>();
    preorder.sort_unstable_by_key(|&body| creation.loop_topology.body_parents[body].preorder_index);
    let preorder = preorder
        .into_iter()
        .map(|body| u32::try_from(body).unwrap_or(u32::MAX))
        .collect::<Vec<_>>();
    let contraction_schedule = creation
        .loop_topology
        .contraction_rounds
        .iter()
        .enumerate()
        .flat_map(|(round, bodies)| {
            bodies.iter().map(move |&body| {
                let topology = creation.loop_topology.body_parents[body as usize];
                GpuContractionNode {
                    metadata: [
                        body,
                        topology.parent_body,
                        u32::try_from(round).unwrap_or(u32::MAX),
                        topology.component_index,
                    ],
                }
            })
        })
        .collect::<Vec<_>>();

    let coordinates =
        vec![GpuMechanismCoordinate::zeroed(); creation.loop_topology.tree_bearings.len()];
    let empty_links = vec![GpuLinkState::zeroed(); body_count];
    let root_flags =
        create_readonly_storage_buffer(device, "mechanic mechanism root flags", &root_flags);
    let body_rows = bodies;
    let bodies = create_storage_buffer(device, "mechanic mechanism bodies", &body_rows);
    let coordinate_count = u32::try_from(coordinates.len()).unwrap_or(u32::MAX);
    let closure_count =
        u32::try_from(creation.loop_topology.closure_bearings.len()).unwrap_or(u32::MAX);
    let coordinates = create_state_buffer(device, "mechanic mechanism coordinates", &coordinates);
    let drive_rows = if creation.coordinate_drives.len() == coordinate_count as usize {
        creation
            .coordinate_drives
            .iter()
            .copied()
            .map(GpuMechanismDrive::from)
            .collect::<Vec<_>>()
    } else {
        vec![GpuMechanismDrive::PASSIVE; coordinate_count as usize]
    };
    let drives = create_storage_buffer(device, "mechanic mechanism drives", &drive_rows);
    let child_by_bearing = creation
        .loop_topology
        .body_parents
        .iter()
        .enumerate()
        .filter_map(|(body, topology)| {
            topology.tree_bearing.map(|bearing| {
                (
                    bearing,
                    (
                        u32::try_from(body).unwrap_or(u32::MAX),
                        topology.parent_body,
                        topology.bearing_direction,
                    ),
                )
            })
        })
        .collect::<BTreeMap<_, _>>();
    let mut drive_constraint_rows = vec![u32::MAX; coordinate_count as usize];
    let drive_constraint_rows_gpu = creation
        .bearings
        .iter()
        .enumerate()
        .map(|(row, bearing)| {
            let coordinate = bearing.coordinate_index.unwrap_or(u32::MAX);
            if coordinate != u32::MAX {
                drive_constraint_rows[coordinate as usize] = u32::try_from(row).unwrap_or(u32::MAX);
            }
            let (child, parent, direction) = child_by_bearing
                .get(&bearing.source_bearing)
                .copied()
                .unwrap_or((u32::MAX, u32::MAX, 0));
            let drive = usize::try_from(coordinate)
                .ok()
                .and_then(|coordinate| drive_rows.get(coordinate))
                .copied()
                .unwrap_or(GpuMechanismDrive::PASSIVE);
            let axis_inertia = usize::try_from(coordinate)
                .ok()
                .and_then(|coordinate| {
                    creation
                        .loop_topology
                        .coordinate_axis_inertia
                        .get(coordinate)
                })
                .copied()
                .unwrap_or(f32::INFINITY);
            GpuDriveConstraint {
                bearing: GpuBearing {
                    local_anchor_a: vec4(bearing.local_anchor_a, bearing.kind.bounds()[0]),
                    local_anchor_b: vec4(bearing.local_anchor_b, bearing.kind.bounds()[1]),
                    local_axis_a: vec4(
                        bearing.local_axis_a,
                        if bearing.kind.is_translational() {
                            1.0
                        } else {
                            0.0
                        },
                    ),
                    local_axis_b: vec4(bearing.local_axis_b, 0.0),
                    suspension: match bearing.kind {
                        mechanic_core::BearingKind::Suspension(s) => s.passive_rows()[0],
                        _ => [0.0; 4],
                    },
                    bump_stop: match bearing.kind {
                        mechanic_core::BearingKind::Suspension(s) => s.passive_rows()[1],
                        _ => [0.0; 4],
                    },
                    metadata: [
                        bearing.compound_a,
                        bearing.compound_b,
                        coordinate,
                        u32::from(bearing.coordinate_index.is_none()),
                    ],
                },
                drive,
                state: [axis_inertia, 0.0, 0.0, 0.0],
                metadata: [child, parent, direction, coordinate],
            }
        })
        .collect::<Vec<_>>();
    let drive_constraints = create_storage_buffer(
        device,
        "mechanic drive constraints",
        &drive_constraint_rows_gpu,
    );
    let preorder = create_readonly_storage_buffer(device, "mechanic mechanism preorder", &preorder);
    let contraction_schedule = create_readonly_storage_buffer(
        device,
        "mechanic articulated contraction schedule",
        &contraction_schedule,
    );
    let velocity_deltas = create_sized_buffer(
        device,
        "mechanic bearing velocity deltas",
        body_count.max(1) * 6 * size_of::<i32>(),
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let articulated_inertia_rows = creation
        .compounds
        .iter()
        .map(|compound| GpuSpatialInertia {
            mass: [compound.mass_properties.mass, 0.0, 0.0, 0.0],
            inertia_x: vec4(compound.mass_properties.inertia.x_axis, 0.0),
            inertia_y: vec4(compound.mass_properties.inertia.y_axis, 0.0),
            inertia_z: vec4(compound.mass_properties.inertia.z_axis, 0.0),
        })
        .collect::<Vec<_>>();
    let articulated_inertia = create_storage_buffer(
        device,
        "mechanic articulated inertia",
        &articulated_inertia_rows,
    );
    let bias_force = create_sized_buffer(
        device,
        "mechanic articulated bias force",
        body_count.max(1) * 32,
        wgpu::BufferUsages::STORAGE,
    );
    let generalized_force = create_sized_buffer(
        device,
        "mechanic generalized force",
        body_count.max(1) * 32,
        wgpu::BufferUsages::STORAGE,
    );
    let constraint_impulse = create_sized_buffer(
        device,
        "mechanic generalized constraint impulse",
        body_count.max(1) * 32,
        wgpu::BufferUsages::STORAGE,
    );
    let reduction_scratch = create_sized_buffer(
        device,
        "mechanic contraction scratch",
        body_count.max(1) * 64,
        wgpu::BufferUsages::STORAGE,
    );
    let links_a = create_storage_buffer(device, "mechanic mechanism links A", &empty_links);
    let links_b = create_storage_buffer(device, "mechanic mechanism links B", &empty_links);
    let closure_accumulators = create_sized_buffer(
        device,
        "mechanic closure accumulators",
        usize::try_from(coordinate_count)
            .unwrap_or(usize::MAX)
            .max(1)
            * 8,
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let closure_state = create_sized_buffer(
        device,
        "mechanic closure state",
        16,
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let closure_indirect_args = create_sized_buffer(
        device,
        "mechanic closure indirect dispatch",
        24,
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::INDIRECT,
    );

    let shader = shader_module(
        pipelines,
        device,
        "mechanic mechanism kernels",
        include_str!("kernels/mechanism.wgsl"),
    );
    let prepare_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic prepare mechanism links",
        &shader,
        "prepare_links",
    );
    let prepare_bind_group = bind_group(
        device,
        "mechanic prepare mechanism bindings",
        &prepare_pipeline,
        &[
            entry(0, config),
            entry(3, &bodies),
            entry(4, bearings),
            entry(5, &coordinates),
            entry(6, &links_a),
        ],
    );
    let jump_a_to_b_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic mechanism jump A to B",
        &shader,
        "jump_a_to_b",
    );
    let jump_a_to_b_bind_group = bind_group(
        device,
        "mechanic mechanism jump A to B bindings",
        &jump_a_to_b_pipeline,
        &[entry(0, config), entry(6, &links_a), entry(7, &links_b)],
    );
    let jump_b_to_a_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic mechanism jump B to A",
        &shader,
        "jump_b_to_a",
    );
    let jump_b_to_a_bind_group = bind_group(
        device,
        "mechanic mechanism jump B to A bindings",
        &jump_b_to_a_pipeline,
        &[entry(0, config), entry(6, &links_a), entry(7, &links_b)],
    );
    let publish_a_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic publish mechanism A",
        &shader,
        "publish_a",
    );
    let publish_a_bind_group = bind_group(
        device,
        "mechanic publish mechanism A bindings",
        &publish_a_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(6, &links_a),
        ],
    );
    let publish_b_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic publish mechanism B",
        &shader,
        "publish_b",
    );
    let publish_b_bind_group = bind_group(
        device,
        "mechanic publish mechanism B bindings",
        &publish_b_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(7, &links_b),
        ],
    );

    let articulated_shader = shader_module(
        pipelines,
        device,
        "mechanic articulated dynamics kernels",
        include_str!("kernels/articulated.wgsl"),
    );
    let prepare_drives_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic prepare drive constraints",
        &articulated_shader,
        "prepare_drive_constraints",
    );
    let prepare_drives_bind_group = bind_group(
        device,
        "mechanic prepare drive constraint bindings",
        &prepare_drives_pipeline,
        &[
            entry(0, config),
            entry(8, &coordinates),
            entry(13, &drive_constraints),
        ],
    );
    let project_velocity_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic project bearing velocities",
        &articulated_shader,
        "project_bearing_velocities",
    );
    let project_velocity_bind_group = bind_group(
        device,
        "mechanic bearing velocity projection bindings",
        &project_velocity_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(5, masses),
            entry(9, &velocity_deltas),
            entry(13, &drive_constraints),
        ],
    );
    let project_small_velocity_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic fused small bearing velocity projection",
        &articulated_shader,
        "project_small_mechanism_velocities",
    );
    let project_small_velocity_bind_group = bind_group(
        device,
        "mechanic fused small bearing velocity bindings",
        &project_small_velocity_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(5, masses),
            entry(9, &velocity_deltas),
            entry(13, &drive_constraints),
        ],
    );
    let project_velocity_serial_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic serial bearing velocity projection",
        &articulated_shader,
        "project_bearing_velocities_serial",
    );
    let project_velocity_serial_bind_group = bind_group(
        device,
        "mechanic serial bearing velocity bindings",
        &project_velocity_serial_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(5, masses),
            entry(9, &velocity_deltas),
            entry(13, &drive_constraints),
        ],
    );
    let apply_velocity_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic apply bearing velocity deltas",
        &articulated_shader,
        "apply_velocity_deltas",
    );
    let apply_velocity_bind_group = bind_group(
        device,
        "mechanic apply bearing velocity bindings",
        &apply_velocity_pipeline,
        &[
            entry(0, config),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(9, &velocity_deltas),
        ],
    );
    let advance_coordinates_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic advance bearing coordinates",
        &articulated_shader,
        "advance_coordinates",
    );
    let advance_coordinates_bind_group = bind_group(
        device,
        "mechanic advance bearing coordinate bindings",
        &advance_coordinates_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(6, bearings),
            entry(7, &bodies),
            entry(8, &coordinates),
            entry(12, &drives),
        ],
    );
    let capture_coordinates_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic capture bearing velocities",
        &articulated_shader,
        "capture_coordinates",
    );
    let capture_coordinates_bind_group = bind_group(
        device,
        "mechanic capture bearing velocity bindings",
        &capture_coordinates_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(6, bearings),
            entry(7, &bodies),
            entry(8, &coordinates),
        ],
    );
    let reconstruct_velocities_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic reconstruct mechanism velocities",
        &articulated_shader,
        "reconstruct_body_velocities",
    );
    let reconstruct_velocities_bind_group = bind_group(
        device,
        "mechanic reconstruct mechanism velocity bindings",
        &reconstruct_velocities_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(6, bearings),
            entry(7, &bodies),
            entry(8, &coordinates),
            entry(10, &preorder),
        ],
    );
    let validate_state_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic validate articulated state",
        &articulated_shader,
        "validate_articulated_state",
    );
    let validate_state_bind_group = bind_group(
        device,
        "mechanic articulated validation bindings",
        &validate_state_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(4, angular_velocities),
            entry(6, bearings),
            entry(7, &bodies),
            entry(8, &coordinates),
            entry(11, diagnostics),
        ],
    );

    let mut covered_depth = 1_u32;
    let mut pointer_jump_rounds = 0_u32;
    while covered_depth < maximum_depth {
        covered_depth = covered_depth.saturating_mul(2);
        pointer_jump_rounds = pointer_jump_rounds.saturating_add(1);
    }
    if maximum_depth > 0 {
        pointer_jump_rounds = pointer_jump_rounds.max(1);
    }
    let final_links = if pointer_jump_rounds.is_multiple_of(2) {
        &links_a
    } else {
        &links_b
    };
    let closure_shader = shader_module(
        pipelines,
        device,
        "mechanic closure kernels",
        include_str!("kernels/closure.wgsl"),
    );
    let evaluate_closures_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic evaluate closures",
        &closure_shader,
        "evaluate_closures",
    );
    let evaluate_closures_bind_group = bind_group(
        device,
        "mechanic evaluate closure bindings",
        &evaluate_closures_pipeline,
        &[
            entry(0, config),
            entry(1, diagnostics),
            entry(2, bearings),
            entry(3, &bodies),
            entry(5, final_links),
            entry(6, &closure_accumulators),
            entry(7, &closure_state),
        ],
    );
    let finalize_closures_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic finalize closures",
        &closure_shader,
        "finalize_closures",
    );
    let finalize_closures_bind_group = bind_group(
        device,
        "mechanic finalize closure bindings",
        &finalize_closures_pipeline,
        &[
            entry(0, config),
            entry(7, &closure_state),
            entry(8, &closure_indirect_args),
        ],
    );
    let apply_closure_step_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic solve closure Newton PCG step",
        &closure_shader,
        "solve_closure_pcg",
    );
    let apply_closure_step_bind_group = bind_group(
        device,
        "mechanic apply closure step bindings",
        &apply_closure_step_pipeline,
        &[
            entry(0, config),
            entry(4, &coordinates),
            entry(2, bearings),
            entry(3, &bodies),
            entry(5, final_links),
            entry(6, &closure_accumulators),
            entry(1, diagnostics),
            entry(9, &reduction_scratch),
        ],
    );

    MechanismResources {
        root_flags,
        bodies,
        body_rows,
        coordinates,
        drives,
        drive_constraints,
        drive_constraint_rows,
        _preorder: preorder,
        _contraction_schedule: contraction_schedule,
        velocity_deltas,
        _articulated_inertia: articulated_inertia,
        _bias_force: bias_force,
        _generalized_force: generalized_force,
        _constraint_impulse: constraint_impulse,
        _reduction_scratch: reduction_scratch,
        links_a,
        links_b,
        closure_accumulators,
        closure_state,
        closure_indirect_args,
        prepare_pipeline,
        prepare_bind_group,
        jump_a_to_b_pipeline,
        jump_a_to_b_bind_group,
        jump_b_to_a_pipeline,
        jump_b_to_a_bind_group,
        publish_a_pipeline,
        publish_a_bind_group,
        publish_b_pipeline,
        publish_b_bind_group,
        evaluate_closures_pipeline,
        evaluate_closures_bind_group,
        finalize_closures_pipeline,
        finalize_closures_bind_group,
        apply_closure_step_pipeline,
        apply_closure_step_bind_group,
        project_velocity_pipeline,
        project_velocity_bind_group,
        project_small_velocity_pipeline,
        project_small_velocity_bind_group,
        project_velocity_serial_pipeline,
        project_velocity_serial_bind_group,
        apply_velocity_pipeline,
        apply_velocity_bind_group,
        prepare_drives_pipeline,
        prepare_drives_bind_group,
        advance_coordinates_pipeline,
        advance_coordinates_bind_group,
        capture_coordinates_pipeline,
        capture_coordinates_bind_group,
        reconstruct_velocities_pipeline,
        reconstruct_velocities_bind_group,
        validate_state_pipeline,
        validate_state_bind_group,
        pointer_jump_rounds,
        coordinate_count,
        closure_count,
        final_is_a: pointer_jump_rounds.is_multiple_of(2),
        active: maximum_depth > 0,
        has_dynamic_root,
    }
}

#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
fn create_lbvh_resources(
    device: &wgpu::Device,
    pipelines: &GpuPhysicsPipelines,
    collider_count: usize,
    config: &wgpu::Buffer,
    positions: &wgpu::Buffer,
    rotations: &wgpu::Buffer,
    diagnostics: &wgpu::Buffer,
    colliders: &wgpu::Buffer,
    convex_shapes: &wgpu::Buffer,
    pairs: &wgpu::Buffer,
    suppressed_pairs: &wgpu::Buffer,
    indirect_args: &wgpu::Buffer,
) -> LbvhResources {
    let sort_count = collider_count.next_power_of_two().max(256);
    let internal_count = collider_count.saturating_sub(1).max(1);
    let node_count = collider_count.saturating_mul(2).saturating_sub(1).max(1);
    let collider_aabbs = create_sized_buffer(
        device,
        "mechanic LBVH collider AABBs",
        collider_count.max(1) * 32,
        wgpu::BufferUsages::STORAGE,
    );
    let morton_entries = create_sized_buffer(
        device,
        "mechanic LBVH Morton entries",
        sort_count * size_of::<GpuPair>(),
        wgpu::BufferUsages::STORAGE,
    );
    let node_aabbs = create_sized_buffer(
        device,
        "mechanic LBVH node AABBs",
        node_count * 32,
        wgpu::BufferUsages::STORAGE,
    );
    let node_children = create_sized_buffer(
        device,
        "mechanic LBVH children",
        internal_count * size_of::<GpuPair>(),
        wgpu::BufferUsages::STORAGE,
    );
    let node_parents = create_sized_buffer(
        device,
        "mechanic LBVH parents",
        node_count * size_of::<u32>(),
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let node_visits = create_sized_buffer(
        device,
        "mechanic LBVH bound visits",
        internal_count * size_of::<u32>(),
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let sort_params = create_uniform_buffer(device, "mechanic LBVH sort parameters", &[0_u32; 4]);
    let mut sort_parameter_rows = Vec::<[u32; 4]>::new();
    let mut sort_steps = Vec::<(u64, bool)>::new();
    let mut k = 512_u32;
    let sort_count_u32 = u32::try_from(sort_count).unwrap_or(u32::MAX);
    while k <= sort_count_u32 {
        let mut j = k / 2;
        while j >= 256 {
            let offset = u64::try_from(sort_parameter_rows.len() * 16).unwrap_or(u64::MAX);
            sort_parameter_rows.push([k, j, 0, 0]);
            sort_steps.push((offset, false));
            j /= 2;
        }
        let offset = u64::try_from(sort_parameter_rows.len() * 16).unwrap_or(u64::MAX);
        sort_parameter_rows.push([k, 0, 0, 0]);
        sort_steps.push((offset, true));
        k = k.saturating_mul(2);
    }
    let sort_params_upload = create_buffer(
        device,
        "mechanic LBVH sort parameter upload",
        &sort_parameter_rows,
        wgpu::BufferUsages::COPY_SRC,
    );

    let shader = shader_module(
        pipelines,
        device,
        "mechanic LBVH kernels",
        include_str!("kernels/lbvh.wgsl"),
    );
    let compute_morton_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH Morton codes",
        &shader,
        "compute_morton",
    );
    let compute_morton_bind_group = bind_group(
        device,
        "mechanic LBVH Morton bindings",
        &compute_morton_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(6, colliders),
            entry(17, &collider_aabbs),
            entry(18, &morton_entries),
            entry(28, convex_shapes),
        ],
    );
    let sort_local_initial_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH local sort",
        &shader,
        "sort_local_initial",
    );
    let sort_local_initial_bind_group = bind_group(
        device,
        "mechanic LBVH local sort bindings",
        &sort_local_initial_pipeline,
        &[entry(18, &morton_entries)],
    );
    let sort_global_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH global merge",
        &shader,
        "sort_global_step",
    );
    let sort_global_bind_group = bind_group(
        device,
        "mechanic LBVH global merge bindings",
        &sort_global_pipeline,
        &[
            entry(0, config),
            entry(18, &morton_entries),
            entry(23, &sort_params),
        ],
    );
    let sort_local_merge_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH local merge",
        &shader,
        "sort_local_merge",
    );
    let sort_local_merge_bind_group = bind_group(
        device,
        "mechanic LBVH local merge bindings",
        &sort_local_merge_pipeline,
        &[entry(18, &morton_entries), entry(23, &sort_params)],
    );
    let build_topology_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH topology",
        &shader,
        "build_topology",
    );
    let build_topology_bind_group = bind_group(
        device,
        "mechanic LBVH topology bindings",
        &build_topology_pipeline,
        &[
            entry(0, config),
            entry(18, &morton_entries),
            entry(20, &node_children),
            entry(21, &node_parents),
        ],
    );
    let prepare_leaves_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH prepare leaves",
        &shader,
        "prepare_leaves",
    );
    let prepare_leaves_bind_group = bind_group(
        device,
        "mechanic LBVH leaf bindings",
        &prepare_leaves_pipeline,
        &[
            entry(0, config),
            entry(17, &collider_aabbs),
            entry(18, &morton_entries),
            entry(19, &node_aabbs),
        ],
    );
    let build_bounds_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH bounds",
        &shader,
        "build_bounds",
    );
    let build_bounds_bind_group = bind_group(
        device,
        "mechanic LBVH bound bindings",
        &build_bounds_pipeline,
        &[
            entry(0, config),
            entry(5, diagnostics),
            entry(19, &node_aabbs),
            entry(20, &node_children),
            entry(21, &node_parents),
            entry(22, &node_visits),
        ],
    );
    let traverse_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic LBVH traversal",
        &shader,
        "traverse",
    );
    let traverse_bind_group = bind_group(
        device,
        "mechanic LBVH traversal bindings",
        &traverse_pipeline,
        &[
            entry(0, config),
            entry(5, diagnostics),
            entry(6, colliders),
            entry(9, pairs),
            entry(11, suppressed_pairs),
            entry(17, &collider_aabbs),
            entry(18, &morton_entries),
            entry(19, &node_aabbs),
            entry(20, &node_children),
        ],
    );
    let finalize_pairs_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic finalize LBVH pairs",
        &shader,
        "finalize_pairs",
    );
    let finalize_pairs_bind_group = bind_group(
        device,
        "mechanic finalize LBVH pair bindings",
        &finalize_pairs_pipeline,
        &[
            entry(0, config),
            entry(5, diagnostics),
            entry(12, indirect_args),
        ],
    );
    LbvhResources {
        sort_count: sort_count_u32,
        _collider_aabbs: collider_aabbs,
        _morton_entries: morton_entries,
        _node_aabbs: node_aabbs,
        _node_children: node_children,
        node_parents,
        node_visits,
        sort_params,
        sort_params_upload,
        sort_steps,
        compute_morton_pipeline,
        compute_morton_bind_group,
        sort_local_initial_pipeline,
        sort_local_initial_bind_group,
        sort_global_pipeline,
        sort_global_bind_group,
        sort_local_merge_pipeline,
        sort_local_merge_bind_group,
        build_topology_pipeline,
        build_topology_bind_group,
        prepare_leaves_pipeline,
        prepare_leaves_bind_group,
        build_bounds_pipeline,
        build_bounds_bind_group,
        traverse_pipeline,
        traverse_bind_group,
        finalize_pairs_pipeline,
        finalize_pairs_bind_group,
    }
}

#[allow(clippy::too_many_arguments, clippy::too_many_lines)]
fn create_collision_resources(
    device: &wgpu::Device,
    pipelines: &GpuPhysicsPipelines,
    collider_count: usize,
    pair_capacity: usize,
    config: &wgpu::Buffer,
    positions: &wgpu::Buffer,
    rotations: &wgpu::Buffer,
    linear_velocities: &wgpu::Buffer,
    angular_velocities: &wgpu::Buffer,
    masses: &wgpu::Buffer,
    diagnostics: &wgpu::Buffer,
    colliders: &wgpu::Buffer,
    convex_shapes: &wgpu::Buffer,
    suppressed_pairs: &wgpu::Buffer,
    drive_constraints: &wgpu::Buffer,
    body_components: &[u32],
    mechanism_self_collisions: bool,
) -> CollisionResources {
    let body_components = create_readonly_storage_buffer(
        device,
        "mechanic body mechanism components",
        body_components,
    );
    let pairs = create_sized_buffer(
        device,
        "mechanic candidate pairs",
        pair_capacity * size_of::<GpuPair>(),
        wgpu::BufferUsages::STORAGE,
    );
    let contacts = create_sized_buffer(
        device,
        "mechanic contact manifolds",
        pair_capacity * size_of::<GpuContact>(),
        wgpu::BufferUsages::STORAGE,
    );
    let manifold_keys = create_sized_buffer(
        device,
        "mechanic persistent manifold keys",
        pair_capacity * size_of::<u32>(),
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let persistent_manifolds = create_sized_buffer(
        device,
        "mechanic persistent manifolds",
        pair_capacity * size_of::<GpuPersistentManifold>(),
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let concrete = ConstructionMaterial::Concrete.properties();
    let ground_surface = GpuGroundSurface {
        response: [
            concrete.static_friction,
            concrete.dynamic_friction,
            concrete.restitution,
            concrete.rolling_resistance,
        ],
        elasticity: [
            concrete.nominal_block_compliance(),
            concrete.youngs_modulus_pa,
            0.0,
            0.0,
        ],
        plane: [0.0, 1.0, 0.0, 0.0],
    };
    let ground_surfaces = create_storage_buffer(
        device,
        "mechanic collider terrain surfaces",
        &vec![ground_surface; collider_count.max(1)],
    );
    let active_contacts = create_sized_buffer(
        device,
        "mechanic active contact indices",
        pair_capacity.saturating_add(1) * size_of::<u32>(),
        wgpu::BufferUsages::STORAGE,
    );
    let indirect_args = create_sized_buffer(
        device,
        "mechanic indirect dispatch arguments",
        15 * size_of::<u32>(),
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::INDIRECT,
    );
    let velocity_deltas = create_sized_buffer(
        device,
        "mechanic projected velocity deltas",
        MAX_BODIES * 6 * size_of::<i32>(),
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    );
    let world_masses = create_sized_buffer(
        device,
        "mechanic world inverse inertias",
        MAX_BODIES * 64,
        wgpu::BufferUsages::STORAGE,
    );
    let lbvh = create_lbvh_resources(
        device,
        pipelines,
        collider_count,
        config,
        positions,
        rotations,
        diagnostics,
        colliders,
        convex_shapes,
        &pairs,
        suppressed_pairs,
        &indirect_args,
    );

    let shader = shader_module(
        pipelines,
        device,
        "mechanic collision kernels",
        include_str!("kernels/collision.wgsl"),
    );
    let update_world_masses_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic update world inverse inertias",
        &shader,
        "update_world_masses",
    );
    let update_world_masses_bind_group = bind_group(
        device,
        "mechanic world inverse inertia bindings",
        &update_world_masses_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(24, masses),
            entry(26, &world_masses),
        ],
    );
    let narrowphase_entry = if mechanism_self_collisions {
        "narrowphase"
    } else {
        "narrowphase_without_mechanism_self_collisions"
    };
    let narrowphase_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic OBB SAT",
        &shader,
        narrowphase_entry,
    );
    let mut narrowphase_bindings = vec![
        entry(0, config),
        entry(1, positions),
        entry(2, rotations),
        entry(5, diagnostics),
        entry(6, colliders),
        entry(9, &pairs),
        entry(10, &contacts),
        entry(28, convex_shapes),
    ];
    if !mechanism_self_collisions {
        narrowphase_bindings.push(entry(27, &body_components));
    }
    let narrowphase_bind_group = bind_group(
        device,
        "mechanic narrowphase bindings",
        &narrowphase_pipeline,
        &narrowphase_bindings,
    );
    let ground_contacts_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic ground contacts",
        &shader,
        "generate_ground_contacts",
    );
    let terrain_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic terrain BVH contacts",
        &shader,
        "generate_terrain_contacts",
    );
    let ground_contacts_bind_group = bind_group(
        device,
        "mechanic ground contact bindings",
        &ground_contacts_pipeline,
        &[
            entry(0, config),
            entry(1, positions),
            entry(2, rotations),
            entry(5, diagnostics),
            entry(6, colliders),
            entry(10, &contacts),
            entry(28, convex_shapes),
            entry(29, &ground_surfaces),
        ],
    );
    let finalize_contacts_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic finalize contacts",
        &shader,
        "finalize_contacts",
    );
    let finalize_contacts_bind_group = bind_group(
        device,
        "mechanic finalize contact bindings",
        &finalize_contacts_pipeline,
        &[
            entry(0, config),
            entry(5, diagnostics),
            entry(12, &indirect_args),
        ],
    );
    let select_active_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic prepare persistent contacts",
        &shader,
        "prepare_contacts",
    );
    let select_active_bind_group = bind_group(
        device,
        "mechanic persistent contact preparation bindings",
        &select_active_pipeline,
        &[
            entry(0, config),
            entry(3, linear_velocities),
            entry(5, diagnostics),
            entry(10, &contacts),
            entry(14, &manifold_keys),
            entry(15, &persistent_manifolds),
            entry(16, &active_contacts),
            entry(26, &world_masses),
            entry(25, angular_velocities),
        ],
    );
    let finalize_active_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic finalize active contacts",
        &shader,
        "finalize_active_contacts",
    );
    let finalize_active_bind_group = bind_group(
        device,
        "mechanic finalize active contact bindings",
        &finalize_active_pipeline,
        &[
            entry(0, config),
            entry(5, diagnostics),
            entry(12, &indirect_args),
            entry(16, &active_contacts),
        ],
    );
    let count_body_contacts_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic count body contacts",
        &shader,
        "count_body_contacts",
    );
    let count_body_contacts_bind_group = bind_group(
        device,
        "mechanic body contact count bindings",
        &count_body_contacts_pipeline,
        &[
            entry(0, config),
            entry(5, diagnostics),
            entry(10, &contacts),
            entry(16, &active_contacts),
            entry(26, &world_masses),
        ],
    );
    let warm_start_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic warm start contacts",
        &shader,
        "warm_start",
    );
    let warm_start_bind_group = bind_group(
        device,
        "mechanic warm start bindings",
        &warm_start_pipeline,
        &[
            entry(0, config),
            entry(3, linear_velocities),
            entry(5, diagnostics),
            entry(10, &contacts),
            entry(13, &velocity_deltas),
            entry(16, &active_contacts),
            entry(15, &persistent_manifolds),
            entry(26, &world_masses),
            entry(25, angular_velocities),
        ],
    );
    let solve_accumulate_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic accumulate contact impulses",
        &shader,
        "solve_accumulate",
    );
    let solve_accumulate_bind_group = bind_group(
        device,
        "mechanic contact impulse bindings",
        &solve_accumulate_pipeline,
        &[
            entry(0, config),
            entry(3, linear_velocities),
            entry(5, diagnostics),
            entry(10, &contacts),
            entry(13, &velocity_deltas),
            entry(16, &active_contacts),
            entry(15, &persistent_manifolds),
            entry(26, &world_masses),
            entry(25, angular_velocities),
        ],
    );
    let solve_small_mechanism_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic fused small mechanism contact projection",
        &shader,
        "solve_small_mechanism_contacts",
    );
    let solve_small_mechanism_bind_group = bind_group(
        device,
        "mechanic fused small mechanism contact bindings",
        &solve_small_mechanism_pipeline,
        &[
            entry(0, config),
            entry(2, rotations),
            entry(3, linear_velocities),
            entry(10, &contacts),
            entry(15, &persistent_manifolds),
            entry(16, &active_contacts),
            entry(25, angular_velocities),
            entry(26, &world_masses),
            entry(30, drive_constraints),
        ],
    );
    let solve_apply_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic apply contact impulses",
        &shader,
        "solve_apply",
    );
    let solve_apply_bind_group = bind_group(
        device,
        "mechanic contact apply bindings",
        &solve_apply_pipeline,
        &[
            entry(0, config),
            entry(3, linear_velocities),
            entry(13, &velocity_deltas),
            entry(25, angular_velocities),
        ],
    );
    let persist_contacts_pipeline = compute_pipeline(
        pipelines,
        device,
        "mechanic persist contacts",
        &shader,
        "persist_contacts",
    );
    let persist_contacts_bind_group = bind_group(
        device,
        "mechanic persist contact bindings",
        &persist_contacts_pipeline,
        &[
            entry(0, config),
            entry(5, diagnostics),
            entry(10, &contacts),
            entry(15, &persistent_manifolds),
            entry(16, &active_contacts),
        ],
    );
    CollisionResources {
        lbvh,
        body_components,
        _pairs: pairs,
        contacts,
        manifold_keys,
        persistent_manifolds,
        ground_surfaces,
        active_contacts,
        indirect_args,
        velocity_deltas,
        world_masses,
        update_world_masses_pipeline,
        update_world_masses_bind_group,
        narrowphase_pipeline,
        narrowphase_bind_group,
        ground_contacts_pipeline,
        ground_contacts_bind_group,
        terrain_pipeline,
        terrain_bind_group: None,
        terrain_geometry_bind_group: None,
        terrain_triangle_count: 0,
        finalize_contacts_pipeline,
        finalize_contacts_bind_group,
        select_active_pipeline,
        select_active_bind_group,
        finalize_active_pipeline,
        finalize_active_bind_group,
        count_body_contacts_pipeline,
        count_body_contacts_bind_group,
        warm_start_pipeline,
        warm_start_bind_group,
        solve_accumulate_pipeline,
        solve_accumulate_bind_group,
        solve_small_mechanism_pipeline,
        solve_small_mechanism_bind_group,
        solve_apply_pipeline,
        solve_apply_bind_group,
        persist_contacts_pipeline,
        persist_contacts_bind_group,
    }
}

fn contact_pair_capacity(collider_count: usize) -> u32 {
    const MINIMUM_PAIR_CAPACITY: usize = 256;
    let collider_pairs = collider_count.saturating_mul(collider_count.saturating_sub(1)) / 2;
    let required = collider_pairs.saturating_add(collider_count);
    let capacity = if required >= MAX_CONTACT_PAIRS {
        MAX_CONTACT_PAIRS
    } else {
        required.max(MINIMUM_PAIR_CAPACITY).next_power_of_two()
    };
    u32::try_from(capacity).unwrap_or(u32::MAX)
}

fn shader_module(
    pipelines: &GpuPhysicsPipelines,
    device: &wgpu::Device,
    label: &'static str,
    source: &'static str,
) -> wgpu::ShaderModule {
    if let Some(shader) = pipelines.shaders.lock().unwrap().get(label).cloned() {
        return shader;
    }
    let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
        label: Some(label),
        source: wgpu::ShaderSource::Wgsl(Cow::Borrowed(source)),
    });
    pipelines
        .shaders
        .lock()
        .unwrap()
        .insert(label, shader.clone());
    shader
}

fn compute_pipeline(
    pipelines: &GpuPhysicsPipelines,
    device: &wgpu::Device,
    label: &'static str,
    shader: &wgpu::ShaderModule,
    entry_point: &'static str,
) -> wgpu::ComputePipeline {
    let key = (label, entry_point);
    if let Some(pipeline) = pipelines.pipelines.lock().unwrap().get(&key).cloned() {
        return pipeline;
    }
    let pipeline = device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
        label: Some(label),
        layout: None,
        module: shader,
        entry_point: Some(entry_point),
        compilation_options: wgpu::PipelineCompilationOptions::default(),
        cache: None,
    });
    pipelines
        .pipelines
        .lock()
        .unwrap()
        .insert(key, pipeline.clone());
    pipeline
}

fn bind_group(
    device: &wgpu::Device,
    label: &str,
    pipeline: &wgpu::ComputePipeline,
    entries: &[wgpu::BindGroupEntry<'_>],
) -> wgpu::BindGroup {
    device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some(label),
        layout: &pipeline.get_bind_group_layout(0),
        entries,
    })
}

fn timestamp_writes(
    timestamps: Option<&TimestampResources>,
    beginning: Option<u32>,
    end: Option<u32>,
) -> Option<wgpu::ComputePassTimestampWrites<'_>> {
    if beginning.is_none() && end.is_none() {
        return None;
    }
    timestamps.map(|timestamps| wgpu::ComputePassTimestampWrites {
        query_set: &timestamps.query_set,
        beginning_of_pass_write_index: beginning,
        end_of_pass_write_index: end,
    })
}

fn direct_compute_pass(
    encoder: &mut wgpu::CommandEncoder,
    label: &str,
    pipeline: &wgpu::ComputePipeline,
    bindings: &wgpu::BindGroup,
    workgroups: u32,
    timestamp_writes: Option<wgpu::ComputePassTimestampWrites<'_>>,
) {
    let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
        label: Some(label),
        timestamp_writes,
    });
    pass.set_pipeline(pipeline);
    pass.set_bind_group(0, bindings, &[]);
    pass.dispatch_workgroups(workgroups, 1, 1);
}

#[allow(clippy::too_many_arguments)]
fn indirect_compute_pass(
    encoder: &mut wgpu::CommandEncoder,
    label: &str,
    pipeline: &wgpu::ComputePipeline,
    bindings: &wgpu::BindGroup,
    indirect_args: &wgpu::Buffer,
    indirect_offset: u64,
    timestamp_writes: Option<wgpu::ComputePassTimestampWrites<'_>>,
) {
    let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
        label: Some(label),
        timestamp_writes,
    });
    pass.set_pipeline(pipeline);
    pass.set_bind_group(0, bindings, &[]);
    pass.dispatch_workgroups_indirect(indirect_args, indirect_offset);
}

fn indirect_dispatch_in_pass<'a>(
    pass: &mut wgpu::ComputePass<'a>,
    pipeline: &'a wgpu::ComputePipeline,
    bindings: &'a wgpu::BindGroup,
    indirect_args: &'a wgpu::Buffer,
    indirect_offset: u64,
) {
    pass.set_pipeline(pipeline);
    pass.set_bind_group(0, bindings, &[]);
    pass.dispatch_workgroups_indirect(indirect_args, indirect_offset);
}

fn entry(binding: u32, buffer: &wgpu::Buffer) -> wgpu::BindGroupEntry<'_> {
    wgpu::BindGroupEntry {
        binding,
        resource: buffer.as_entire_binding(),
    }
}

fn create_uniform_buffer<T: Pod>(device: &wgpu::Device, label: &str, value: &T) -> wgpu::Buffer {
    device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: Some(label),
        contents: bytes_of(value),
        usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
    })
}

fn create_storage_buffer<T: Pod>(device: &wgpu::Device, label: &str, values: &[T]) -> wgpu::Buffer {
    create_buffer(
        device,
        label,
        values,
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
    )
}

fn create_state_buffer<T: Pod>(device: &wgpu::Device, label: &str, values: &[T]) -> wgpu::Buffer {
    create_buffer(
        device,
        label,
        values,
        wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::COPY_SRC,
    )
}

fn create_readonly_storage_buffer<T: Pod>(
    device: &wgpu::Device,
    label: &str,
    values: &[T],
) -> wgpu::Buffer {
    create_buffer(device, label, values, wgpu::BufferUsages::STORAGE)
}

fn create_buffer<T: Pod>(
    device: &wgpu::Device,
    label: &str,
    values: &[T],
    usage: wgpu::BufferUsages,
) -> wgpu::Buffer {
    if values.is_empty() {
        return device.create_buffer(&wgpu::BufferDescriptor {
            label: Some(label),
            size: u64::try_from(size_of::<T>().max(16)).unwrap_or(16),
            usage,
            mapped_at_creation: false,
        });
    }
    device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
        label: Some(label),
        contents: cast_slice(values),
        usage,
    })
}

fn create_sized_buffer(
    device: &wgpu::Device,
    label: &str,
    size: usize,
    usage: wgpu::BufferUsages,
) -> wgpu::Buffer {
    device.create_buffer(&wgpu::BufferDescriptor {
        label: Some(label),
        size: u64::try_from(size).unwrap_or(u64::MAX),
        usage,
        mapped_at_creation: false,
    })
}

fn vec4(vector: bevy_math::Vec3, w: f32) -> [f32; 4] {
    [vector.x, vector.y, vector.z, w]
}

fn wrapping_u32(value: u64) -> u32 {
    let bytes = value.to_le_bytes();
    u32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]])
}

#[allow(clippy::cast_precision_loss)]
fn diagnostic_units(value: u32) -> f32 {
    value as f32 / 1_000_000.0
}

fn timestamp_milliseconds(start: u64, end: u64, period_nanoseconds: f64) -> f64 {
    let ticks = end.wrapping_sub(start);
    let bounded_ticks = u32::try_from(ticks).unwrap_or(u32::MAX);
    f64::from(bounded_ticks) * period_nanoseconds / 1_000_000.0
}

#[cfg(test)]
const FULL_CYLINDER_GROUND_FIRST: u32 = 1;

#[derive(Clone, Copy, Debug, Default, PartialEq)]
struct CylinderGroundData {
    center_radius: f32,
    outer_radius: f32,
    role: u32,
}

fn full_cylinder_ground_data(
    colliders: &[mechanic_core::LocalCollider],
) -> Vec<CylinderGroundData> {
    let mut result = vec![CylinderGroundData::default(); colliders.len()];
    let mut start = 0;
    while start < colliders.len() {
        let source_part = colliders[start].source_part;
        let mut end = start + 1;
        while end < colliders.len() && colliders[end].source_part == source_part {
            end += 1;
        }
        let group = &colliders[start..end];
        // Gate on the compiled shape, never on the run length: a shaped cuboid
        // that happened to fuse into sixteen pieces would otherwise be mistaken
        // for a cylinder and given analytic ground contacts.
        let cuboid_extents = |collider: &mechanic_core::LocalCollider| match &collider.shape {
            mechanic_core::ColliderShape::Cuboid {
                local_rotation,
                half_extents,
            } => Some((*local_rotation, *half_extents)),
            mechanic_core::ColliderShape::Convex(_) => None,
        };
        if group.len() == mechanic_core::CYLINDER_COLLIDER_COUNT
            && group
                .iter()
                .all(|collider| cuboid_extents(collider).is_some())
        {
            let radial_sum = group
                .iter()
                .filter_map(cuboid_extents)
                .map(|(rotation, _)| rotation * Vec3::X)
                .sum::<Vec3>();
            if radial_sum.length_squared() < 1.0e-8 {
                let cylinder_center = group
                    .iter()
                    .map(|collider| collider.local_center)
                    .sum::<Vec3>()
                    * (1.0 / 16.0);
                let center_radius = (group[0].local_center - cylinder_center).length();
                let outer_radius = center_radius
                    + cuboid_extents(&group[0])
                        .expect("every row in a cylinder run is a box")
                        .1
                        .x;
                for (segment, row) in result[start..end].iter_mut().enumerate() {
                    *row = CylinderGroundData {
                        center_radius,
                        outer_radius,
                        role: u32::try_from(segment + 1).expect("cylinder segment fits u32"),
                    };
                }
            }
        }
        start = end;
    }
    result
}

fn map_for_read(device: &wgpu::Device, buffer: &wgpu::Buffer) -> Result<(), GpuReadbackError> {
    let (sender, receiver) = mpsc::sync_channel(1);
    buffer.map_async(wgpu::MapMode::Read, .., move |result| {
        let _ = sender.send(result);
    });
    device
        .poll(wgpu::PollType::wait_indefinitely())
        .map_err(|error| GpuReadbackError::DevicePoll(error.to_string()))?;
    receiver
        .recv()
        .map_err(|_| GpuReadbackError::CallbackLost)?
        .map_err(|error| GpuReadbackError::BufferMap(error.to_string()))
}

fn create_async_readback_slot(
    device: &wgpu::Device,
    body_count: u32,
    coordinate_count: u32,
    timestamps_enabled: bool,
    index: usize,
) -> AsyncReadbackSlot {
    let readback_buffer = |label: String, size: u64| {
        device.create_buffer(&wgpu::BufferDescriptor {
            label: Some(&label),
            size: size.max(4),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        })
    };
    let snapshot_size = u64::from(body_count) * 16;
    AsyncReadbackSlot {
        diagnostics: readback_buffer(
            format!("mechanic async diagnostics {index}"),
            u64::try_from(size_of::<GpuDiagnostics>()).unwrap_or(32),
        ),
        timestamps: timestamps_enabled
            .then(|| readback_buffer(format!("mechanic async timestamps {index}"), 224)),
        positions: readback_buffer(
            format!("mechanic async snapshot positions {index}"),
            snapshot_size,
        ),
        rotations: readback_buffer(
            format!("mechanic async snapshot rotations {index}"),
            snapshot_size,
        ),
        linear_velocities: readback_buffer(
            format!("mechanic async linear velocities {index}"),
            snapshot_size,
        ),
        angular_velocities: readback_buffer(
            format!("mechanic async angular velocities {index}"),
            snapshot_size,
        ),
        coordinates: readback_buffer(
            format!("mechanic async coordinates {index}"),
            u64::from(coordinate_count) * 8,
        ),
        pending: None,
    }
}

fn mapped_rows<T: Pod>(buffer: &wgpu::Buffer, count: u32) -> Vec<T> {
    if count == 0 {
        return Vec::new();
    }
    let bytes = buffer.get_mapped_range(..u64::from(count) * size_of::<T>() as u64);
    bytes
        .chunks_exact(size_of::<T>())
        .map(bytemuck::pod_read_unaligned)
        .collect()
}

// A later mapping callback must not overtake an earlier incomplete snapshot.
fn oldest_completed_readback(pending: impl Iterator<Item = (usize, u64, u8)>) -> Option<usize> {
    pending
        .min_by_key(|&(_, sequence, _)| sequence)
        .and_then(|(index, _, remaining)| (remaining == 0).then_some(index))
}

fn begin_async_mapping(
    slot: &mut AsyncReadbackSlot,
    submission_sequence: u64,
    tick_index: u64,
    snapshot_slot: u8,
    submitted_at: Instant,
    timing: bool,
) {
    let callback_count = 6 + u8::from(slot.timestamps.is_some());
    let (sender, receiver) = mpsc::sync_channel(usize::from(callback_count));
    let map = |buffer: &wgpu::Buffer,
               sender: mpsc::SyncSender<(Result<(), String>, Option<Instant>)>| {
        buffer.map_async(wgpu::MapMode::Read, .., move |result| {
            let observed_at = timing.then(Instant::now);
            let _ = sender.send((result.map_err(|error| error.to_string()), observed_at));
        });
    };
    map(&slot.diagnostics, sender.clone());
    if let Some(timestamps) = &slot.timestamps {
        map(timestamps, sender.clone());
    }
    map(&slot.positions, sender.clone());
    map(&slot.rotations, sender.clone());
    map(&slot.linear_velocities, sender.clone());
    map(&slot.angular_velocities, sender.clone());
    map(&slot.coordinates, sender);
    slot.pending = Some(PendingAsyncReadback {
        submission_sequence,
        tick_index,
        snapshot_slot,
        receiver,
        remaining_callbacks: callback_count,
        submitted_at,
        callbacks_completed_at: None,
    });
}

fn unmap_async_slot(slot: &AsyncReadbackSlot) {
    slot.diagnostics.unmap();
    if let Some(timestamps) = &slot.timestamps {
        timestamps.unmap();
    }
    slot.positions.unmap();
    slot.rotations.unmap();
    slot.linear_velocities.unmap();
    slot.angular_velocities.unmap();
    slot.coordinates.unmap();
}

fn read_vec4_buffer(
    device: &wgpu::Device,
    buffer: &wgpu::Buffer,
    byte_len: u64,
) -> Result<Vec<[f32; 4]>, GpuReadbackError> {
    map_for_read(device, buffer)?;
    let values = {
        let bytes = buffer.get_mapped_range(0..byte_len);
        cast_slice::<u8, [f32; 4]>(&bytes).to_vec()
    };
    buffer.unmap();
    Ok(values)
}

#[cfg(test)]
mod tests {
    use super::ASYNC_READBACK_RING_SIZE;
    use bevy_math::{IVec3, Vec3};
    use mechanic_core::{
        BearingSpec, BuildCommand, BuildOutcome, BuildPose, ConstructionGraph,
        ConstructionMaterial, CoordinateDrive, CuboidSpec, CylinderDimensions, CylinderSpec,
        DriveMode, EngineKind, FaceKind, FaceRef, GearboxConfig, GridRotation, PartId,
        PipeBendDimensions, PipeBendSpec, RigidLinkSpec, ServoSpec, WeldSpec,
    };

    use crate::GpuMechanismCoordinate;

    use super::{
        EXTERNAL_IMPULSE_BATCH_CAPACITY, FULL_CYLINDER_GROUND_FIRST, GpuExternalImpulse,
        GpuGroundPlane, GpuGroundPlaneError, GpuImpulseError, GpuPhysics, GpuPhysicsConfig,
        GpuPhysicsPipelines, contact_pair_capacity, full_cylinder_ground_data,
        uses_fused_contact_schedule, uses_fused_velocity_schedule,
    };

    #[test]
    fn fused_small_mechanism_schedule_has_explicit_size_and_scene_boundaries() {
        assert!(uses_fused_velocity_schedule(64, 256));
        assert!(!uses_fused_velocity_schedule(65, 256));
        assert!(!uses_fused_velocity_schedule(64, 257));

        assert!(uses_fused_contact_schedule(4, true));
        assert!(uses_fused_contact_schedule(64, true));
        assert!(!uses_fused_contact_schedule(65, true));
        assert!(uses_fused_contact_schedule(64, false));
        assert!(!uses_fused_contact_schedule(65, false));
    }

    #[test]
    fn collision_buffers_scale_with_the_scene_up_to_the_hard_limit() {
        assert_eq!(contact_pair_capacity(0), 256);
        assert_eq!(contact_pair_capacity(1), 256);
        assert_eq!(contact_pair_capacity(16), 256);
        assert_eq!(contact_pair_capacity(1_024), 1_048_576);
        assert_eq!(
            contact_pair_capacity(crate::MAX_COLLIDERS),
            u32::try_from(crate::MAX_CONTACT_PAIRS).unwrap()
        );
    }

    #[test]
    fn replacement_scene_reuses_every_compiled_shader_and_pipeline() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        graph
            .apply(BuildCommand::Spawn(
                CuboidSpec::new([1; 3], BuildPose::default()).unwrap(),
            ))
            .unwrap();
        let creation = graph.compile().unwrap();
        let pipelines = GpuPhysicsPipelines::new();
        let first = GpuPhysics::new_with_pipelines(
            &device,
            &queue,
            &creation,
            GpuPhysicsConfig::default(),
            &pipelines,
        )
        .unwrap();
        let shader_count = pipelines.shaders.lock().unwrap().len();
        let pipeline_count = pipelines.pipelines.lock().unwrap().len();
        drop(first);

        let _replacement = GpuPhysics::new_with_pipelines(
            &device,
            &queue,
            &creation,
            GpuPhysicsConfig::default(),
            &pipelines,
        )
        .unwrap();

        assert!(shader_count > 0);
        assert!(pipeline_count > shader_count);
        assert_eq!(pipelines.shaders.lock().unwrap().len(), shader_count);
        assert_eq!(pipelines.pipelines.lock().unwrap().len(), pipeline_count);
    }

    #[test]
    fn physics_wgsl_parses_and_validates_without_a_gpu() {
        for (name, source) in [
            ("physics", include_str!("kernels/physics.wgsl")),
            ("collision", include_str!("kernels/collision.wgsl")),
            ("lbvh", include_str!("kernels/lbvh.wgsl")),
            ("bearings", include_str!("kernels/bearings.wgsl")),
            ("mechanism", include_str!("kernels/mechanism.wgsl")),
            ("articulated", include_str!("kernels/articulated.wgsl")),
            ("closure", include_str!("kernels/closure.wgsl")),
            ("snapshot", include_str!("kernels/snapshot.wgsl")),
        ] {
            let module = naga::front::wgsl::parse_str(source)
                .unwrap_or_else(|error| panic!("{name} WGSL parses: {error}"));
            naga::valid::Validator::new(
                naga::valid::ValidationFlags::all(),
                naga::valid::Capabilities::all(),
            )
            .validate(&module)
            .unwrap_or_else(|error| panic!("{name} WGSL validates: {error:#?}"));
        }
    }

    #[test]
    fn gated_recovery_timestamps_remain_ordered() {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle());
        let adapter =
            pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions::default()))
                .unwrap();
        if !adapter.features().contains(wgpu::Features::TIMESTAMP_QUERY) {
            return;
        }
        let (device, queue) = pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
            required_features: wgpu::Features::TIMESTAMP_QUERY,
            ..Default::default()
        }))
        .unwrap();
        let mut gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &pendulum_creation(false),
            GpuPhysicsConfig {
                ground_plane_enabled: false,
                ..Default::default()
            },
        )
        .unwrap();
        let mut chunk = super::terrain::tests::rigid_chunk();
        chunk.origin.0.y -= 100.0;
        gpu.write_terrain_chunks(&device, &queue, [&chunk], bevy_math::DVec3::ZERO)
            .unwrap();
        for tick in 1..=30 {
            gpu.dispatch_tick(&device, &queue, tick);
            let result = gpu.read_last_tick(&device).unwrap();
            assert_eq!(result.error_flags, 0);
            assert_eq!(result.contact_count, 0);
            let stages = result.kernel_timings.unwrap();
            assert!(stages.terrain_recovery_ms > 0.0);
            assert!(
                stages.recovery_projection_ms <= stages.terrain_recovery_ms,
                "invalid nested span: {stages:?}"
            );
            assert!(stages.terrain_recovery_ms <= result.gpu_tick_ms.unwrap());
        }
    }

    fn pendulum_creation(grounded: bool) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let mut spawn = |units| {
            let spec =
                CuboidSpec::new([4, 4, 4], BuildPose::new(units, GridRotation::default())).unwrap();
            let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap()
            else {
                unreachable!()
            };
            part
        };
        let root = spawn(IVec3::new(0, 2, 0));
        let arm_a = spawn(IVec3::new(4, 2, 0));
        let arm_b = spawn(IVec3::new(4, 2, 4));
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(arm_a, FaceKind::PositiveZ),
                second: FaceRef::part(arm_b, FaceKind::NegativeZ),
            }))
            .unwrap();
        if grounded {
            graph
                .apply(BuildCommand::Weld(WeldSpec {
                    first: FaceRef::part(root, FaceKind::NegativeY),
                    second: FaceRef::ground(),
                }))
                .unwrap();
        }
        graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(root, FaceKind::PositiveX),
                FaceRef::part(arm_a, FaceKind::NegativeX),
                Vec3::new(0.5, 0.5, 0.0),
                Vec3::X,
            )))
            .unwrap();
        graph.compile().unwrap()
    }

    fn tall_pendulum_creation(second_link: bool) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let (support, arm, child) = {
            let mut spawn = |units| {
                let spec =
                    CuboidSpec::new([2, 2, 2], BuildPose::new(units, GridRotation::default()))
                        .unwrap();
                let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap()
                else {
                    unreachable!()
                };
                part
            };
            let support = (0..7)
                .map(|row| spawn(IVec3::new(0, row * 2 + 1, 0)))
                .collect::<Vec<_>>();
            let arm = (0..4)
                .map(|column| spawn(IVec3::new(2, 13, column * 2)))
                .collect::<Vec<_>>();
            let child = second_link.then(|| {
                (0..3)
                    .map(|row| spawn(IVec3::new(2, row * 2 + 13, 8)))
                    .collect::<Vec<_>>()
            });
            (support, arm, child)
        };
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(support[0], FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        for pair in support.windows(2) {
            graph
                .apply(BuildCommand::Weld(WeldSpec {
                    first: FaceRef::part(pair[0], FaceKind::PositiveY),
                    second: FaceRef::part(pair[1], FaceKind::NegativeY),
                }))
                .unwrap();
        }
        for pair in arm.windows(2) {
            graph
                .apply(BuildCommand::Weld(WeldSpec {
                    first: FaceRef::part(pair[0], FaceKind::PositiveZ),
                    second: FaceRef::part(pair[1], FaceKind::NegativeZ),
                }))
                .unwrap();
        }
        graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(support[6], FaceKind::PositiveX),
                FaceRef::part(arm[0], FaceKind::NegativeX),
                Vec3::new(0.25, 3.25, 0.0),
                Vec3::X,
            )))
            .unwrap();
        if let Some(child) = child {
            for pair in child.windows(2) {
                graph
                    .apply(BuildCommand::Weld(WeldSpec {
                        first: FaceRef::part(pair[0], FaceKind::PositiveY),
                        second: FaceRef::part(pair[1], FaceKind::NegativeY),
                    }))
                    .unwrap();
            }
            graph
                .apply(BuildCommand::AddBearing(BearingSpec::new(
                    FaceRef::part(arm[3], FaceKind::PositiveZ),
                    FaceRef::part(child[0], FaceKind::NegativeZ),
                    Vec3::new(0.5, 3.25, 1.75),
                    Vec3::Z,
                )))
                .unwrap();
        }
        graph.compile().unwrap()
    }

    fn branching_pendulum_creation(
        arm_count: usize,
        hanging: bool,
    ) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let root = CuboidSpec::new(
            [8, 4, 8],
            BuildPose::new(IVec3::new(0, 2, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(root) = graph.apply(BuildCommand::Spawn(root)).unwrap() else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(root, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        let bar = CuboidSpec::new(
            [24, 2, 2],
            BuildPose::from_half_grid(IVec3::new(0, 10, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(bar) = graph.apply(BuildCommand::Spawn(bar)).unwrap() else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(root, FaceKind::PositiveY),
                FaceRef::part(bar, FaceKind::NegativeY),
                Vec3::new(0.0, 1.0, 0.0),
                Vec3::Y,
            )))
            .unwrap();

        for (center, bar_face, arm_face, anchor, axis) in [
            (
                IVec3::new(26, if hanging { 7 } else { 16 }, 1),
                FaceKind::PositiveX,
                FaceKind::NegativeX,
                Vec3::new(3.0, 1.25, 0.0),
                Vec3::X,
            ),
            (
                IVec3::new(-26, if hanging { 7 } else { 16 }, -1),
                FaceKind::NegativeX,
                FaceKind::PositiveX,
                Vec3::new(-3.0, 1.25, 0.0),
                Vec3::NEG_X,
            ),
        ]
        .into_iter()
        .take(arm_count)
        {
            let arm = CuboidSpec::new(
                [2, 8, 2],
                BuildPose::from_half_grid(center, GridRotation::default()),
            )
            .unwrap();
            let BuildOutcome::Spawned(arm) = graph.apply(BuildCommand::Spawn(arm)).unwrap() else {
                unreachable!()
            };
            graph
                .apply(BuildCommand::AddBearing(BearingSpec::new(
                    FaceRef::part(bar, bar_face),
                    FaceRef::part(arm, arm_face),
                    anchor,
                    axis,
                )))
                .unwrap();
        }
        graph.compile().unwrap()
    }

    fn swinging_arm_with_coaxial_rotor_creation() -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let root = CuboidSpec::new(
            [8, 8, 8],
            BuildPose::new(IVec3::new(0, 4, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(root) = graph.apply(BuildCommand::Spawn(root)).unwrap() else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(root, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();

        let arm = CuboidSpec::new(
            [2, 2, 24],
            BuildPose::from_half_grid(IVec3::new(10, 10, 24), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(arm) = graph.apply(BuildCommand::Spawn(arm)).unwrap() else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(root, FaceKind::PositiveX),
                FaceRef::part(arm, FaceKind::NegativeX),
                Vec3::new(1.0, 1.25, 0.25),
                Vec3::X,
            )))
            .unwrap();

        let rotor = CylinderSpec::new(
            CylinderDimensions::new(0.25, 0.20, 0.75).unwrap(),
            BuildPose::from_half_grid(IVec3::new(10, 5, 46), GridRotation::default()),
        );
        let BuildOutcome::Spawned(rotor) = graph.apply(BuildCommand::SpawnCylinder(rotor)).unwrap()
        else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(arm, FaceKind::NegativeY),
                FaceRef::part(rotor, FaceKind::PositiveY),
                Vec3::new(1.25, 1.0, 5.75),
                Vec3::NEG_Y,
            )))
            .unwrap();
        graph.compile().unwrap()
    }

    fn relative_bearing_rotation(
        snapshot: &[crate::GpuTransform],
        bearing: &mechanic_core::CompiledBearing,
    ) -> bevy_math::Quat {
        let a = bevy_math::Quat::from_array(snapshot[bearing.compound_a as usize].rotation);
        let b = bevy_math::Quat::from_array(snapshot[bearing.compound_b as usize].rotation);
        a.conjugate() * b
    }

    fn run_long_pendulum(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        creation: &mechanic_core::CompiledCreation,
        collisions_enabled: bool,
    ) -> (Vec<f32>, Vec<f32>, super::GpuTickReadback) {
        let gpu = GpuPhysics::new_with_config(
            device,
            queue,
            creation,
            GpuPhysicsConfig {
                collisions_enabled,
                ..Default::default()
            },
        )
        .unwrap();
        for tick in 1..=1_200 {
            gpu.dispatch_tick(device, queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let current = gpu.read_snapshot_transforms(device, queue, 0).unwrap();
        let previous = gpu.read_snapshot_transforms(device, queue, 2).unwrap();
        let diagnostics = gpu.read_last_tick(device).unwrap();
        let mut angles = Vec::with_capacity(creation.bearings.len());
        let mut angular_speeds = Vec::with_capacity(creation.bearings.len());
        for bearing in &creation.bearings {
            let current_relative = relative_bearing_rotation(&current, bearing);
            let previous_relative = relative_bearing_rotation(&previous, bearing);
            angles.push(
                2.0 * current_relative
                    .xyz()
                    .dot(bearing.local_axis_a)
                    .atan2(current_relative.w),
            );
            let delta = previous_relative.conjugate() * current_relative;
            angular_speeds.push(2.0 * delta.xyz().length().atan2(delta.w.abs()) * 60.0);
        }
        (angles, angular_speeds, diagnostics)
    }

    #[test]
    fn tall_single_and_double_pendulums_dissipate_energy() {
        let Some((device, queue)) = test_device() else {
            return;
        };

        let single = tall_pendulum_creation(false);
        let assert_compacted_topology =
            |creation: &mechanic_core::CompiledCreation, part_count, body_count| {
                assert_eq!(creation.part_to_compound.len(), part_count);
                assert_eq!(creation.compounds.len(), body_count);
                assert_eq!(creation.bearings.len(), body_count - 1);
                assert_eq!(creation.colliders.len(), body_count);
                for compound in &creation.compounds {
                    assert_eq!(compound.collider_range.len(), 1);
                    let collider = &creation.colliders[compound.collider_range.start as usize];
                    let mechanic_core::ColliderShape::Cuboid {
                        local_rotation,
                        half_extents,
                    } = collider.shape
                    else {
                        panic!("compacted pendulum link must remain a cuboid");
                    };
                    assert_eq!(local_rotation, bevy_math::Quat::IDENTITY);
                    let (minimum, maximum) = match compound.source_parts.len() {
                        7 => (Vec3::new(-0.25, 0.0, -0.25), Vec3::new(0.25, 3.5, 0.25)),
                        4 => (Vec3::new(0.25, 3.0, -0.25), Vec3::new(0.75, 3.5, 1.75)),
                        3 => (Vec3::new(0.25, 3.0, 1.75), Vec3::new(0.75, 4.5, 2.25)),
                        count => panic!("unexpected pendulum link with {count} parts"),
                    };
                    let center = compound.root_translation + collider.local_center;
                    assert!((center - half_extents).abs_diff_eq(minimum, 1.0e-6));
                    assert!((center + half_extents).abs_diff_eq(maximum, 1.0e-6));
                    assert_eq!(compound.is_static, compound.source_parts.len() == 7);
                }
            };
        assert_compacted_topology(&single, 11, 2);
        let (single_angles, single_speeds, single_diagnostics) =
            run_long_pendulum(&device, &queue, &single, true);
        assert_eq!(single_diagnostics.error_flags, 0);
        assert_eq!(single_diagnostics.active_contact_count, 0);
        assert!(
            (single_angles[0] - std::f32::consts::FRAC_PI_2).abs() < 0.02,
            "single pendulum angle was {}",
            single_angles[0]
        );
        assert!(single_speeds[0] < 0.2);

        let double = tall_pendulum_creation(true);
        assert_compacted_topology(&double, 14, 3);
        let (free_angles, free_speeds, free_diagnostics) =
            run_long_pendulum(&device, &queue, &double, false);
        assert_eq!(free_diagnostics.error_flags, 0);
        assert!(
            (free_angles[0] - std::f32::consts::FRAC_PI_2).abs() < 0.02,
            "double pendulum retained free angles {free_angles:?} and speeds {free_speeds:?}"
        );
        assert!(
            (free_angles[1] + std::f32::consts::FRAC_PI_2).abs() < 0.02,
            "double pendulum retained free angles {free_angles:?} and speeds {free_speeds:?}"
        );
        assert!(
            free_speeds.iter().all(|speed| *speed < 1.0e-4),
            "double pendulum retained free speeds {free_speeds:?}"
        );

        let (_, contact_speeds, contact_diagnostics) =
            run_long_pendulum(&device, &queue, &double, true);
        assert_eq!(contact_diagnostics.error_flags, 0);
        assert!(
            contact_speeds.iter().all(|speed| *speed < 1.0e-4),
            "double pendulum retained contact speeds {contact_speeds:?}"
        );
    }

    #[test]
    fn branching_pendulum_reaches_rest_instead_of_retaining_spin() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        for (arm_count, hanging) in [(1, false), (2, false), (1, true), (2, true)] {
            let creation = branching_pendulum_creation(arm_count, hanging);
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            if arm_count == 1 && hanging {
                gpu.initialize_mechanism_coordinates(
                    &queue,
                    &[
                        GpuMechanismCoordinate {
                            position: 0.0,
                            velocity: 0.0,
                        },
                        GpuMechanismCoordinate {
                            position: 0.35,
                            velocity: 0.0,
                        },
                    ],
                )
                .unwrap();
            }
            let sample = |tick: u64| {
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let current = gpu
                    .read_snapshot_transforms(&device, &queue, u8::try_from(tick % 3).unwrap())
                    .unwrap();
                let previous = gpu
                    .read_snapshot_transforms(
                        &device,
                        &queue,
                        u8::try_from((tick - 1) % 3).unwrap(),
                    )
                    .unwrap();
                creation
                    .bearings
                    .iter()
                    .map(|bearing| {
                        let current_relative = relative_bearing_rotation(&current, bearing);
                        let previous_relative = relative_bearing_rotation(&previous, bearing);
                        let delta = previous_relative.conjugate() * current_relative;
                        2.0 * delta.xyz().length().atan2(delta.w.abs()) * 60.0
                    })
                    .collect::<Vec<_>>()
            };
            for tick in 1..=1_200 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let early = sample(1_200);
            for tick in 1_201..=2_400 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let late = sample(2_400);
            assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
            assert!(
                late.iter().all(|speed| *speed < 1.0e-4)
                    && late
                        .iter()
                        .zip(&early)
                        .all(|(late, early)| *late <= *early + 1.0e-5),
                "{arm_count}-arm hanging={hanging} bearing speeds grew from {early:?} to {late:?}"
            );
        }
    }

    #[test]
    fn moving_coaxial_rotor_does_not_gain_perpetual_spin() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let creation = swinging_arm_with_coaxial_rotor_creation();
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        gpu.initialize_mechanism_coordinates(
            &queue,
            &[
                GpuMechanismCoordinate {
                    position: 0.35,
                    velocity: 0.0,
                },
                GpuMechanismCoordinate {
                    position: 0.0,
                    velocity: 0.0,
                },
            ],
        )
        .unwrap();
        let sample = |tick: u64| {
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let current = gpu
                .read_snapshot_transforms(&device, &queue, u8::try_from(tick % 3).unwrap())
                .unwrap();
            let previous = gpu
                .read_snapshot_transforms(&device, &queue, u8::try_from((tick - 1) % 3).unwrap())
                .unwrap();
            creation
                .bearings
                .iter()
                .map(|bearing| {
                    let current_relative = relative_bearing_rotation(&current, bearing);
                    let previous_relative = relative_bearing_rotation(&previous, bearing);
                    let delta = previous_relative.conjugate() * current_relative;
                    2.0 * delta.xyz().length().atan2(delta.w.abs()) * 60.0
                })
                .collect::<Vec<_>>()
        };
        for tick in 1..=1_200 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let early_speeds = sample(1_200);
        for tick in 1_201..=2_400 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let late_speeds = sample(2_400);
        let diagnostics = gpu.read_last_tick(&device).unwrap();
        assert_eq!(diagnostics.error_flags, 0, "{diagnostics:?}");
        assert!(
            late_speeds.iter().all(|speed| *speed < 0.02)
                && late_speeds
                    .iter()
                    .zip(&early_speeds)
                    .all(|(late, early)| *late <= *early + 1.0e-5),
            "bearing state gained speed from {early_speeds:?} to {late_speeds:?}"
        );
    }

    /// Grounded base plus a hinged arm wired to one control block.
    ///
    /// `loaded` extends the arm sideways off the hinge axis so gravity applies a
    /// real torque; otherwise the arm's centre of mass sits on the axis.
    fn driven_arm(
        axis: Vec3,
        limits: mechanic_core::DriveLimits,
        program: mechanic_core::DriveProgram,
        loaded: bool,
    ) -> (ConstructionGraph, mechanic_core::CompiledCreation) {
        let mut graph = ConstructionGraph::new();
        let mut spawn = |units| {
            let spec =
                CuboidSpec::new([4, 4, 4], BuildPose::new(units, GridRotation::default())).unwrap();
            let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap()
            else {
                unreachable!()
            };
            part
        };
        let (base_units, arm_units, source_face, target_face, anchor) = if axis == Vec3::X {
            (
                IVec3::new(0, 2, 0),
                IVec3::new(4, 2, 0),
                FaceKind::PositiveX,
                FaceKind::NegativeX,
                Vec3::new(0.5, 0.5, 0.0),
            )
        } else {
            (
                IVec3::new(0, 2, 0),
                IVec3::new(0, 6, 0),
                FaceKind::PositiveY,
                FaceKind::NegativeY,
                Vec3::new(0.0, 1.0, 0.0),
            )
        };
        let base = spawn(base_units);
        let arm = spawn(arm_units);
        let outrigger = loaded.then(|| spawn(arm_units + IVec3::new(0, 0, 4)));
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(base, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        if let Some(outrigger) = outrigger {
            graph
                .apply(BuildCommand::Weld(WeldSpec {
                    first: FaceRef::part(arm, FaceKind::PositiveZ),
                    second: FaceRef::part(outrigger, FaceKind::NegativeZ),
                }))
                .unwrap();
        }
        let BuildOutcome::BearingAdded(bearing) = graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(base, source_face),
                FaceRef::part(arm, target_face),
                anchor,
                axis,
            )))
            .unwrap()
        else {
            unreachable!()
        };
        let BuildOutcome::Spawned(controller) = graph
            .apply(BuildCommand::SpawnController(
                mechanic_core::ControllerSpec::new(BuildPose::new(
                    IVec3::new(0, 40, 0),
                    GridRotation::default(),
                )),
            ))
            .unwrap()
        else {
            unreachable!()
        };
        let mut link = mechanic_core::DriveLinkSpec::new(controller, bearing);
        link.limits = limits;
        link.program = program;
        graph.apply(BuildCommand::AddDriveLink(link)).unwrap();
        let mut creation = graph.compile().unwrap();
        creation.coordinate_drives[0] = test_coordinate_drive(
            &creation,
            limits,
            program
                .state(0)
                .expect("test program has one state")
                .target(),
        );
        (graph, creation)
    }

    fn test_coordinate_drive(
        creation: &mechanic_core::CompiledCreation,
        limits: mechanic_core::DriveLimits,
        target: mechanic_core::DriveTarget,
    ) -> CoordinateDrive {
        let axis_inertia = creation.loop_topology.coordinate_axis_inertia[0];
        let torque = limits.max_torque_newton_meters();
        let acceleration = if torque.is_infinite() {
            100.0
        } else {
            torque / axis_inertia
        };
        CoordinateDrive {
            mode: if target.angle().is_some() {
                DriveMode::Angle
            } else {
                DriveMode::Speed
            },
            target_speed: target.speed().unwrap_or(0.0),
            target_angle: target.angle().unwrap_or(0.0),
            max_speed: limits.max_speed_rad_s(),
            max_acceleration: acceleration,
            source_a_max_acceleration: acceleration,
            source_a_no_load_speed: limits.max_speed_rad_s(),
            source_b_max_acceleration: 0.0,
            source_b_no_load_speed: 0.0,
            min_angle: limits.min_angle(),
            max_angle: limits.max_angle(),
        }
    }

    /// Signed joint angle of the first bearing, read back from a snapshot.
    fn joint_angle(
        snapshot: &[crate::GpuTransform],
        creation: &mechanic_core::CompiledCreation,
    ) -> f32 {
        let bearing = &creation.bearings[0];
        let delta = relative_bearing_rotation(snapshot, bearing);
        let axis = bearing.local_axis_a.normalize();
        2.0 * delta.xyz().dot(axis).atan2(delta.w)
    }

    fn run_driven_arm(
        creation: &mechanic_core::CompiledCreation,
        ticks: u64,
    ) -> Option<(f32, super::GpuTickReadback)> {
        let (device, queue) = test_device()?;
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            creation,
            GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            },
        )
        .unwrap();
        for tick in 1..=ticks {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let snapshot = gpu
            .read_snapshot_transforms(&device, &queue, u8::try_from(ticks % 3).unwrap())
            .unwrap();
        let diagnostics = gpu.read_last_tick(&device).unwrap();
        Some((joint_angle(&snapshot, creation), diagnostics))
    }

    /// Limits with the given maximum torque and no travel stops.
    fn limits(max_speed: f32, torque: f32) -> mechanic_core::DriveLimits {
        mechanic_core::DriveLimits::new(max_speed, torque, None).expect("test limits are in range")
    }

    /// Single-state program holding one target forever.
    fn holding(target: mechanic_core::DriveTarget) -> mechanic_core::DriveProgram {
        mechanic_core::DriveProgram::new(
            &[mechanic_core::DriveState::new(target).expect("test target is in range")],
            false,
        )
        .expect("a one-state program is valid")
    }

    #[test]
    fn speed_state_advances_a_bearing_coordinate_at_its_target_speed() {
        let (_, creation) = driven_arm(
            Vec3::X,
            limits(3.0, f32::INFINITY),
            holding(mechanic_core::DriveTarget::Speed(1.0)),
            false,
        );
        let Some((angle, diagnostics)) = run_driven_arm(&creation, 60) else {
            return;
        };

        assert_eq!(diagnostics.error_flags, 0);
        assert!(
            (angle - 1.0).abs() < 0.05,
            "one second at 1 rad/s should reach about 1 rad, got {angle}"
        );
    }

    #[test]
    fn negative_target_speed_drives_the_joint_the_other_way() {
        let (_, creation) = driven_arm(
            Vec3::X,
            limits(3.0, f32::INFINITY),
            holding(mechanic_core::DriveTarget::Speed(-1.0)),
            false,
        );
        let Some((angle, diagnostics)) = run_driven_arm(&creation, 60) else {
            return;
        };

        assert_eq!(diagnostics.error_flags, 0);
        assert!(
            (angle + 1.0).abs() < 0.05,
            "a negative target speed should reach about -1 rad, got {angle}"
        );
    }

    #[test]
    fn max_speed_caps_a_faster_state_target() {
        let (_, creation) = driven_arm(
            Vec3::X,
            limits(0.5, f32::INFINITY),
            holding(mechanic_core::DriveTarget::Speed(3.0)),
            false,
        );
        let Some((angle, diagnostics)) = run_driven_arm(&creation, 60) else {
            return;
        };

        assert_eq!(diagnostics.error_flags, 0);
        assert!(
            (angle - 0.5).abs() < 0.05,
            "the row's 0.5 rad/s ceiling should hold the joint to 0.5 rad, got {angle}"
        );
    }

    #[test]
    fn angle_state_reaches_its_target_and_holds_without_overshooting() {
        let (_, creation) = driven_arm(
            Vec3::X,
            limits(3.0, 400.0),
            holding(mechanic_core::DriveTarget::Angle(0.8)),
            false,
        );
        // Long enough that a servo which overshoots would be caught swinging
        // back through the target rather than sitting on it.
        let Some((angle, diagnostics)) = run_driven_arm(&creation, 240) else {
            return;
        };

        assert_eq!(diagnostics.error_flags, 0);
        assert!(
            (angle - 0.8).abs() < 0.02,
            "the joint should settle on its 0.8 rad target, got {angle}"
        );
    }

    #[test]
    fn weak_drive_stalls_lifting_a_gravity_loaded_arm() {
        // The outrigger hangs off the hinge axis, so gravity applies a positive
        // torque about it. Driving negative means the motor must lift that load,
        // which is the only direction in which stalling is observable.
        let program = holding(mechanic_core::DriveTarget::Speed(-1.0));
        let (_, strong_creation) = driven_arm(Vec3::X, limits(3.0, f32::INFINITY), program, true);
        let (_, weak_creation) = driven_arm(Vec3::X, limits(3.0, 0.5), program, true);

        let Some((strong_angle, strong_diagnostics)) = run_driven_arm(&strong_creation, 60) else {
            return;
        };
        let (weak_angle, weak_diagnostics) = run_driven_arm(&weak_creation, 60).unwrap();

        assert_eq!(strong_diagnostics.error_flags, 0);
        assert_eq!(weak_diagnostics.error_flags, 0);
        assert!(
            (strong_angle + 1.0).abs() < 0.05,
            "an unlimited motor holds its target under load, got {strong_angle}"
        );
        assert!(
            weak_angle > strong_angle + 0.5,
            "a 0.5 N·m motor should stall well short of {strong_angle}, got {weak_angle}"
        );
    }

    #[test]
    fn driven_coordinate_stops_and_holds_at_its_travel_limit() {
        let stopped = mechanic_core::DriveLimits::new(3.0, f32::INFINITY, Some((-0.2, 0.2)))
            .expect("test limits are in range");
        let (_, creation) = driven_arm(
            Vec3::X,
            stopped,
            holding(mechanic_core::DriveTarget::Speed(1.0)),
            false,
        );
        let Some((angle, diagnostics)) = run_driven_arm(&creation, 120) else {
            return;
        };

        assert_eq!(diagnostics.error_flags, 0);
        assert!(
            (angle - 0.2).abs() < 0.02,
            "the joint should hold at its 0.2 rad limit, got {angle}"
        );
    }

    #[test]
    fn vertical_axis_drive_is_not_zeroed_by_the_sleep_clamp() {
        // Below GRAVITY_ALIGNED_BEARING_SLEEP_SPEED, which stops passive joints.
        let (_, creation) = driven_arm(
            Vec3::Y,
            limits(3.0, f32::INFINITY),
            holding(mechanic_core::DriveTarget::Speed(0.002)),
            false,
        );
        let Some((angle, diagnostics)) = run_driven_arm(&creation, 600) else {
            return;
        };

        assert_eq!(diagnostics.error_flags, 0);
        assert!(
            angle > 0.015,
            "ten seconds at 0.002 rad/s should still turn the joint, got {angle}"
        );
    }

    #[test]
    fn reprogramming_a_wire_changes_the_drive_without_reloading_the_scene() {
        let (mut graph, creation) = driven_arm(
            Vec3::X,
            limits(3.0, f32::INFINITY),
            holding(mechanic_core::DriveTarget::Speed(1.0)),
            false,
        );
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &creation,
            GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            },
        )
        .unwrap();

        assert_eq!(
            gpu.write_mechanism_drives(&queue, &[]),
            Err(super::GpuPhysicsError::DriveStateCount {
                provided: 0,
                required: 1,
            })
        );

        let (link, drive_spec) = graph
            .drive_links()
            .map(|(id, spec)| (id, *spec))
            .next()
            .unwrap();
        graph
            .apply(BuildCommand::SetDriveLink {
                link,
                limits: limits(3.0, f32::INFINITY),
                program: holding(mechanic_core::DriveTarget::Speed(-2.0)),
                name: mechanic_core::DriveName::EMPTY,
                actuator: drive_spec.actuator,
            })
            .unwrap();
        let target = graph
            .drive_links()
            .next()
            .and_then(|(_, spec)| spec.resolved_target(0))
            .unwrap();
        let rows = [test_coordinate_drive(
            &creation,
            limits(3.0, f32::INFINITY),
            target,
        )]
        .into_iter()
        .map(crate::GpuMechanismDrive::from)
        .collect::<Vec<_>>();
        gpu.write_mechanism_drives(&queue, &rows).unwrap();

        for tick in 1..=60 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let snapshot = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
        let angle = joint_angle(&snapshot, &creation);
        assert!(
            (angle + 2.0).abs() < 0.1,
            "the live reprogram should drive -2 rad/s, got {angle}"
        );
    }

    fn mixed_linear_creation(copies: i32, close_loop: bool) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        for copy in 0..copies {
            let z_ticks = copy * 1600;
            let mut spawn = |dimensions, x, y| {
                spawned_part(
                    graph
                        .apply(BuildCommand::Spawn(
                            CuboidSpec::new(
                                dimensions,
                                BuildPose::from_position_ticks(
                                    IVec3::new(x, y, z_ticks),
                                    GridRotation::default(),
                                ),
                            )
                            .unwrap(),
                        ))
                        .unwrap(),
                )
            };
            let base = spawn([4, 4, 4], 0, 200);
            let carriage = spawn([1, 1, 1], 290, 200);
            let arm = spawn([1, 1, 1], 390, 200);
            let support = close_loop.then(|| spawn([1, 1, 1], 530, 200));
            graph
                .apply(BuildCommand::Weld(WeldSpec {
                    first: FaceRef::part(base, FaceKind::NegativeY),
                    second: FaceRef::ground(),
                }))
                .unwrap();
            let z = f32::from(i16::try_from(copy).unwrap()) * 4.0;
            let linear_kind = |normal, length| {
                mechanic_core::BearingKind::Linear(mechanic_core::LinearBearing {
                    dimensions: mechanic_core::LinearBearingDimensions::new(length, 0.1).unwrap(),
                    mount_normal: normal,
                    face: mechanic_core::CarriageFace::Top,
                })
            };
            graph
                .apply(BuildCommand::AddBearing(
                    BearingSpec::new(
                        FaceRef::part(base, FaceKind::PositiveX),
                        FaceRef::part(carriage, FaceKind::NegativeX),
                        Vec3::new(0.5, 0.5, z),
                        Vec3::Z,
                    )
                    .with_kind(linear_kind(Vec3::X, 1.0)),
                ))
                .unwrap();
            graph
                .apply(BuildCommand::AddBearing(BearingSpec::new(
                    FaceRef::part(carriage, FaceKind::PositiveX),
                    FaceRef::part(arm, FaceKind::NegativeX),
                    Vec3::new(0.85, 0.5, z),
                    Vec3::X,
                )))
                .unwrap();
            if let Some(support) = support {
                graph
                    .apply(BuildCommand::RigidLink(RigidLinkSpec {
                        first: base,
                        second: support,
                    }))
                    .unwrap();
                graph
                    .apply(BuildCommand::AddBearing(
                        BearingSpec::new(
                            FaceRef::part(support, FaceKind::NegativeX),
                            FaceRef::part(arm, FaceKind::PositiveX),
                            Vec3::new(1.2, 0.5, z),
                            Vec3::Z,
                        )
                        .with_kind(linear_kind(Vec3::NEG_X, 0.5)),
                    ))
                    .unwrap();
            }
        }
        graph.compile().unwrap()
    }

    fn assert_mixed_linear_constraints(
        gpu: &GpuPhysics,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        creation: &mechanic_core::CompiledCreation,
        tick: u64,
    ) -> Vec<crate::GpuTransform> {
        let snapshot = gpu
            .read_snapshot_transforms(device, queue, u8::try_from(tick % 3).unwrap())
            .unwrap();
        for (index, bearing) in creation.bearings.iter().enumerate() {
            let a = snapshot[bearing.compound_a as usize];
            let b = snapshot[bearing.compound_b as usize];
            let qa = bevy_math::Quat::from_array(a.rotation);
            let qb = bevy_math::Quat::from_array(b.rotation);
            let delta = transform_position(b) + qb * bearing.local_anchor_b
                - transform_position(a)
                - qa * bearing.local_anchor_a;
            let axis = qa * bearing.local_axis_a;
            let (position_error, rotation_error) = match bearing.kind {
                mechanic_core::BearingKind::Linear(_)
                | mechanic_core::BearingKind::Suspension(_) => {
                    let displacement = delta.dot(axis);
                    let [lower, upper] = bearing.kind.bounds();
                    let residual = delta - axis * displacement.clamp(lower, upper);
                    let rotation = qa.conjugate() * qb;
                    (
                        residual.length(),
                        2.0 * rotation.xyz().length().atan2(rotation.w.abs()),
                    )
                }
                mechanic_core::BearingKind::Rotational => {
                    let other_axis = qb * bearing.local_axis_b;
                    (
                        delta.length(),
                        axis.cross(other_axis).length().atan2(axis.dot(other_axis)),
                    )
                }
            };
            assert!(
                position_error <= mechanic_core::ANCHOR_TOLERANCE_METERS,
                "tick {tick}, bearing {index} {:?}: position error {position_error}",
                bearing.kind
            );
            assert!(
                rotation_error.to_degrees() <= mechanic_core::AXIS_TOLERANCE_DEGREES,
                "tick {tick}, bearing {index} {:?}: rotation error {} degrees",
                bearing.kind,
                rotation_error.to_degrees()
            );
        }
        let diagnostics = gpu.read_last_tick(device).unwrap();
        assert_eq!(diagnostics.error_flags, 0, "tick {tick}: {diagnostics:?}");
        assert!(
            diagnostics.anchor_residual_meters <= mechanic_core::ANCHOR_TOLERANCE_METERS,
            "{diagnostics:?}"
        );
        assert!(
            diagnostics.axis_residual_degrees <= mechanic_core::AXIS_TOLERANCE_DEGREES,
            "{diagnostics:?}"
        );
        snapshot
    }

    #[test]
    fn linear_mixed_chains_preserve_constraints_in_small_and_parallel_routes() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        for copies in [1, 33] {
            let mut creation = mixed_linear_creation(copies, false);
            assert_eq!(creation.loop_topology.closure_bearings.len(), 0);
            assert_eq!(
                uses_fused_velocity_schedule(
                    u32::try_from(creation.bearings.len()).unwrap(),
                    u32::try_from(creation.compounds.len()).unwrap()
                ),
                copies == 1
            );
            for bearing in &creation.bearings {
                let coordinate = bearing.coordinate_index.unwrap() as usize;
                creation.coordinate_drives[coordinate] = linear_speed_drive(0.5);
            }
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            for tick in 1..=90 {
                gpu.dispatch_tick(&device, &queue, tick);
                if tick == 1 || tick % 10 == 0 {
                    assert_mixed_linear_constraints(&gpu, &device, &queue, &creation, tick);
                }
            }
            let (position, snapshot) = linear_test_snapshot(&gpu, &device, &queue, &creation, 90);
            assert!(
                (position - 0.425).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
                "{position}"
            );
            let relative = relative_bearing_rotation(&snapshot, &creation.bearings[1]);
            assert!(
                relative.xyz().length() > 0.1,
                "rotational child failed to move: {relative:?}"
            );
        }
    }

    #[test]
    fn linear_mixed_loops_enforce_narrower_closure_stops_in_all_routes() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        for copies in [1, 22] {
            let mut creation = mixed_linear_creation(copies, true);
            assert_eq!(
                creation.loop_topology.closure_bearings.len(),
                usize::try_from(copies).unwrap()
            );
            assert!(
                creation
                    .bearings
                    .iter()
                    .filter(|b| b.coordinate_index.is_none())
                    .all(|b| matches!(b.kind, mechanic_core::BearingKind::Linear(_)))
            );
            assert_eq!(
                uses_fused_velocity_schedule(
                    u32::try_from(creation.bearings.len()).unwrap(),
                    u32::try_from(creation.compounds.len()).unwrap()
                ),
                copies == 1
            );
            for bearing in &creation.bearings {
                if bearing.kind.is_translational()
                    && let Some(coordinate) = bearing.coordinate_index
                {
                    creation.coordinate_drives[coordinate as usize] = linear_speed_drive(0.5);
                }
            }
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            for tick in 1..=90 {
                gpu.dispatch_tick(&device, &queue, tick);
                if tick == 1 || tick % 5 == 0 {
                    assert_mixed_linear_constraints(&gpu, &device, &queue, &creation, tick);
                }
            }
            let (position, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 90);
            assert!(
                (position - 0.175).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
                "linear closure's narrower end stop was not enforced: {position}"
            );
        }
    }

    #[test]
    fn linear_mixed_loops_lock_orientation_after_off_centre_impacts() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        for copies in [1, 22] {
            let creation = mixed_linear_creation(copies, true);
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            for bearing in creation
                .bearings
                .iter()
                .filter(|bearing| matches!(bearing.kind, mechanic_core::BearingKind::Rotational))
            {
                let child = &creation.compounds[bearing.compound_b as usize];
                gpu.apply_impulse(
                    &device,
                    &queue,
                    bearing.compound_b,
                    child.root_translation + Vec3::Y * 0.1,
                    Vec3::Z * child.mass_properties.mass * 0.1,
                )
                .unwrap();
            }
            for tick in 1..=30 {
                gpu.dispatch_tick(&device, &queue, tick);
                assert_mixed_linear_constraints(&gpu, &device, &queue, &creation, tick);
            }
        }
    }

    fn linear_test_creation(axis: Vec3, grounded: bool) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let base = spawned_part(
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new(
                        [4, 4, 4],
                        BuildPose::new(IVec3::new(0, 2, 0), GridRotation::default()),
                    )
                    .unwrap(),
                ))
                .unwrap(),
        );
        let carriage = spawned_part(
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new(
                        [1, 1, 1],
                        BuildPose::from_position_ticks(
                            IVec3::new(290, 200, 0),
                            GridRotation::default(),
                        ),
                    )
                    .unwrap(),
                ))
                .unwrap(),
        );
        if grounded {
            graph
                .apply(BuildCommand::Weld(WeldSpec {
                    first: FaceRef::part(base, FaceKind::NegativeY),
                    second: FaceRef::ground(),
                }))
                .unwrap();
        }
        graph
            .apply(BuildCommand::AddBearing(
                BearingSpec::new(
                    FaceRef::part(base, FaceKind::PositiveX),
                    FaceRef::part(carriage, FaceKind::NegativeX),
                    Vec3::new(0.5, 0.5, 0.0),
                    axis,
                )
                .with_kind(mechanic_core::BearingKind::Linear(
                    mechanic_core::LinearBearing {
                        dimensions: mechanic_core::LinearBearingDimensions::default(),
                        mount_normal: Vec3::X,
                        face: mechanic_core::CarriageFace::Top,
                    },
                )),
            ))
            .unwrap();
        graph.compile().unwrap()
    }

    fn linear_test_snapshot(
        gpu: &GpuPhysics,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        creation: &mechanic_core::CompiledCreation,
        tick: u64,
    ) -> (f32, Vec<crate::GpuTransform>) {
        let snapshot = gpu
            .read_snapshot_transforms(device, queue, u8::try_from(tick % 3).unwrap())
            .unwrap();
        let bearing = creation.bearings[0];
        let a = snapshot[bearing.compound_a as usize];
        let b = snapshot[bearing.compound_b as usize];
        let rotation_a = bevy_math::Quat::from_array(a.rotation);
        let rotation_b = bevy_math::Quat::from_array(b.rotation);
        let separation = transform_position(b) + rotation_b * bearing.local_anchor_b
            - transform_position(a)
            - rotation_a * bearing.local_anchor_a;
        let axis = rotation_a * bearing.local_axis_a;
        let displacement = separation.dot(axis);
        let sideways = (separation - axis * displacement).length();
        assert!(
            sideways <= mechanic_core::ANCHOR_TOLERANCE_METERS,
            "tick {tick}: transverse displacement {sideways} m"
        );
        let relative_rotation = rotation_a.conjugate() * rotation_b;
        let orientation_error = (2.0
            * relative_rotation
                .xyz()
                .length()
                .atan2(relative_rotation.w.abs()))
        .to_degrees();
        assert!(
            orientation_error <= mechanic_core::AXIS_TOLERANCE_DEGREES,
            "tick {tick}: relative rotation {orientation_error} degrees"
        );
        let [minimum, maximum] = bearing.kind.bounds();
        assert!(
            displacement >= minimum - mechanic_core::ANCHOR_TOLERANCE_METERS
                && displacement <= maximum + mechanic_core::ANCHOR_TOLERANCE_METERS,
            "tick {tick}: displacement {displacement} outside [{minimum}, {maximum}]"
        );
        let diagnostics = gpu.read_last_tick(device).unwrap();
        assert_eq!(diagnostics.error_flags, 0, "tick {tick}: {diagnostics:?}");
        assert!(
            diagnostics.anchor_residual_meters <= mechanic_core::ANCHOR_TOLERANCE_METERS,
            "{diagnostics:?}"
        );
        assert!(
            diagnostics.axis_residual_degrees <= mechanic_core::AXIS_TOLERANCE_DEGREES,
            "{diagnostics:?}"
        );
        (displacement, snapshot)
    }

    #[test]
    fn linear_passive_vertical_carriage_hits_both_physical_stops_without_power() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        for axis in [Vec3::Y, Vec3::NEG_Y] {
            let creation = linear_test_creation(axis, true);
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            let mut last = 0.0;
            for tick in 1..=120 {
                gpu.dispatch_tick(&device, &queue, tick);
                if tick % 10 == 0 {
                    let (position, _) =
                        linear_test_snapshot(&gpu, &device, &queue, &creation, tick);
                    assert!(
                        (position - last) * axis.y <= mechanic_core::ANCHOR_TOLERANCE_METERS,
                        "passive stop rebounded from {last} to {position}"
                    );
                    last = position;
                }
            }
            assert!(
                (last + axis.y * 0.425).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
                "gravity did not reach the end stop: {last}"
            );
        }
    }

    #[test]
    fn linear_off_centre_impact_locks_sideways_motion_and_all_rotation() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        let creation = linear_test_creation(Vec3::Z, true);
        let bearing = creation.bearings[0];
        let body = &creation.compounds[bearing.compound_b as usize];
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &creation,
            GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            },
        )
        .unwrap();
        gpu.apply_impulse(
            &device,
            &queue,
            bearing.compound_b,
            body.root_translation + Vec3::Y * 0.1,
            Vec3::new(3.0, 2.0, 8.0) * body.mass_properties.mass,
        )
        .unwrap();
        for tick in 1..=90 {
            gpu.dispatch_tick(&device, &queue, tick);
            linear_test_snapshot(&gpu, &device, &queue, &creation, tick);
        }
        let (position, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 90);
        assert!(
            (position - 0.425).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
            "impact failed to reach the stop: {position}"
        );
    }

    #[test]
    fn linear_floating_mount_receives_end_stop_reaction_after_impact() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        for sign in [-1.0, 1.0] {
            let creation = linear_test_creation(Vec3::Z, false);
            let bearing = creation.bearings[0];
            let child = &creation.compounds[bearing.compound_b as usize];
            let base = &creation.compounds[bearing.compound_a as usize];
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            gpu.apply_impulse(
                &device,
                &queue,
                bearing.compound_b,
                child.root_translation,
                Vec3::Z * sign * 20.0 * child.mass_properties.mass,
            )
            .unwrap();
            for tick in 1..=60 {
                gpu.dispatch_tick(&device, &queue, tick);
                linear_test_snapshot(&gpu, &device, &queue, &creation, tick);
            }
            let (position, snapshot) = linear_test_snapshot(&gpu, &device, &queue, &creation, 60);
            assert!(
                (position - sign * 0.425).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
                "floating impact did not remain at stop: {position}"
            );
            let movement =
                transform_position(snapshot[bearing.compound_a as usize]) - base.root_translation;
            assert!(
                movement.z * sign > 0.01,
                "mount received no stop reaction: {movement:?}"
            );
        }
    }

    fn linear_speed_drive(speed: f32) -> CoordinateDrive {
        CoordinateDrive {
            mode: DriveMode::Speed,
            target_speed: speed,
            target_angle: 0.0,
            max_speed: 2.0,
            max_acceleration: 100.0,
            source_a_max_acceleration: 100.0,
            source_a_no_load_speed: 2.0,
            source_b_max_acceleration: 0.0,
            source_b_no_load_speed: 0.0,
            min_angle: f32::NEG_INFINITY,
            max_angle: f32::INFINITY,
        }
    }

    #[test]
    fn linear_position_drive_seeks_and_holds_against_gravity_after_reprogramming() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        let mut creation = linear_test_creation(Vec3::Y, true);
        let position_drive = |target| CoordinateDrive {
            mode: DriveMode::Angle,
            target_angle: target,
            min_angle: -0.25,
            max_angle: 0.25,
            ..linear_speed_drive(0.0)
        };
        creation.coordinate_drives[0] = position_drive(0.15);
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &creation,
            GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            },
        )
        .unwrap();
        for (phase, target) in [(0, 0.15), (1, -0.20)] {
            gpu.write_mechanism_drives(
                &queue,
                &[crate::GpuMechanismDrive::from(position_drive(target))],
            )
            .unwrap();
            for offset in 1..=180 {
                let tick = phase * 180 + offset;
                gpu.dispatch_tick(&device, &queue, tick);
                let (position, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, tick);
                if offset > 120 {
                    assert!(
                        (position - target).abs() < 0.001,
                        "position {position}, target {target}"
                    );
                }
            }
        }
    }

    #[test]
    fn linear_sustained_power_respects_stops_and_reverses_immediately() {
        let (device, queue) = test_device().expect("linear GPU regression requires an adapter");
        let mut creation = linear_test_creation(Vec3::Z, true);
        creation.coordinate_drives[0] = linear_speed_drive(1.0);
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &creation,
            GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            },
        )
        .unwrap();
        for tick in 1..=120 {
            gpu.dispatch_tick(&device, &queue, tick);
            linear_test_snapshot(&gpu, &device, &queue, &creation, tick);
        }
        let (upper, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 120);
        assert!(
            (upper - 0.425).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
            "{upper}"
        );
        gpu.write_mechanism_drives(
            &queue,
            &[crate::GpuMechanismDrive::from(linear_speed_drive(-1.0))],
        )
        .unwrap();
        gpu.dispatch_tick(&device, &queue, 121);
        let (reversed, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 121);
        assert!(
            reversed < upper - 1.0e-4,
            "reverse remained stuck: {upper} -> {reversed}"
        );
        for tick in 122..=240 {
            gpu.dispatch_tick(&device, &queue, tick);
            linear_test_snapshot(&gpu, &device, &queue, &creation, tick);
        }
        let (lower, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 240);
        assert!(
            (lower + 0.425).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
            "{lower}"
        );
        gpu.write_mechanism_drives(
            &queue,
            &[crate::GpuMechanismDrive::from(CoordinateDrive::default())],
        )
        .unwrap();
        for tick in 241..=270 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let (unpowered, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 270);
        assert!(
            (unpowered - lower).abs() <= mechanic_core::ANCHOR_TOLERANCE_METERS,
            "removing power moved stationary horizontal carriage: {lower} -> {unpowered}"
        );
    }

    fn suspension_test_creation(
        spec: mechanic_core::SuspensionSpec,
        vertical: bool,
        copies: i32,
    ) -> mechanic_core::CompiledCreation {
        suspension_test_creation_with_anchor(spec, vertical, copies, true)
    }

    fn suspension_test_creation_with_anchor(
        spec: mechanic_core::SuspensionSpec,
        vertical: bool,
        copies: i32,
        grounded: bool,
    ) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let axis = if vertical { Vec3::Y } else { Vec3::X };
        let source_face = if vertical {
            FaceKind::PositiveY
        } else {
            FaceKind::PositiveX
        };
        let target_face = if vertical {
            FaceKind::NegativeY
        } else {
            FaceKind::NegativeX
        };
        for copy in 0..copies {
            let base_ticks = IVec3::new(0, 200, copy * 1600);
            #[allow(clippy::cast_possible_truncation)]
            let spacing_ticks = ((spec.initial_length() + 0.625) / 0.0025).round() as i32;
            let offset = if vertical { IVec3::Y } else { IVec3::X } * spacing_ticks;
            let mut spawn = |ticks, dimensions| {
                spawned_part(
                    graph
                        .apply(BuildCommand::Spawn(
                            CuboidSpec::new(
                                dimensions,
                                BuildPose::from_position_ticks(ticks, GridRotation::default()),
                            )
                            .unwrap(),
                        ))
                        .unwrap(),
                )
            };
            let base = spawn(base_ticks, [4, 4, 4]);
            let tip = spawn(base_ticks + offset, [1, 1, 1]);
            if grounded {
                graph
                    .apply(BuildCommand::Weld(WeldSpec {
                        first: FaceRef::part(base, FaceKind::NegativeY),
                        second: FaceRef::ground(),
                    }))
                    .unwrap();
            }
            graph
                .apply(BuildCommand::AddBearing(
                    BearingSpec::new(
                        FaceRef::part(base, source_face),
                        FaceRef::part(tip, target_face),
                        base_ticks.as_vec3() * 0.0025 + axis * 0.5,
                        axis,
                    )
                    .with_kind(mechanic_core::BearingKind::Suspension(spec)),
                ))
                .unwrap();
        }
        graph.compile().unwrap()
    }

    fn suspension_test_gpu(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        creation: &mechanic_core::CompiledCreation,
    ) -> GpuPhysics {
        GpuPhysics::new_with_config(
            device,
            queue,
            creation,
            GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            },
        )
        .unwrap()
    }

    #[test]
    fn suspension_loaded_spring_equilibrium_in_small_and_parallel_routes() {
        use mechanic_core::{ShockSpec, SpringSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let spring = SpringSpec::default();
        let spec = SuspensionSpec::new(Some(spring), Some(ShockSpec::default()), None).unwrap();
        for copies in [1, 65] {
            let creation = suspension_test_creation(spec, true, copies);
            assert_eq!(
                uses_fused_velocity_schedule(
                    u32::try_from(creation.bearings.len()).unwrap(),
                    u32::try_from(creation.compounds.len()).unwrap()
                ),
                copies == 1
            );
            let bearing = creation.bearings[0];
            let expected = creation.compounds[bearing.compound_b as usize]
                .mass_properties
                .mass
                * 9.81
                / spring.rate();
            let gpu = suspension_test_gpu(&device, &queue, &creation);
            for tick in 1..=360 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let (displacement, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 360);
            assert!(
                (-displacement - expected).abs() < expected * 0.1 + 0.0001,
                "copies {copies}: compression {}, equilibrium {expected}",
                -displacement
            );
            assert_mixed_linear_constraints(&gpu, &device, &queue, &creation, 360);
            eprintln!(
                "suspension copies {copies}: {:?}",
                gpu.read_last_tick(&device).unwrap()
            );
        }
    }

    #[test]
    fn suspension_damper_starting_stroke_is_force_free_and_rebound_is_stronger() {
        use mechanic_core::{ShockBodyEnd, ShockSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let spec = SuspensionSpec::new(
            None,
            Some(ShockSpec::new(0.5, 0.1, ShockBodyEnd::Source, 0.075, 1.0, 1.6).unwrap()),
            None,
        )
        .unwrap();
        let creation = suspension_test_creation(spec, false, 1);
        let mut distances = Vec::new();
        for speed in [0.0_f32, -0.1, 0.1] {
            let gpu = suspension_test_gpu(&device, &queue, &creation);
            let bearing = creation.bearings[0];
            let body = &creation.compounds[bearing.compound_b as usize];
            if speed != 0.0 {
                gpu.apply_impulse(
                    &device,
                    &queue,
                    bearing.compound_b,
                    body.root_translation,
                    Vec3::X * speed * body.mass_properties.mass,
                )
                .unwrap();
            }
            for tick in 1..=60 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let (position, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 60);
            distances.push(position.abs());
            if speed == 0.0 {
                assert!(
                    position.abs() < 0.00001,
                    "stationary damper moved {position}"
                );
            } else {
                assert!(
                    position * speed > 0.0
                        && position.abs() < speed.abs() * 60.0 * crate::FIXED_DT_SECONDS * 0.9,
                    "damper failed to decay: speed {speed}, travel {position}"
                );
            }
        }
        assert!(
            distances[2] < distances[1] * 0.9,
            "compression/rebound travel {distances:?}"
        );
    }

    #[test]
    fn suspension_spring_oscillates_and_preload_reduces_loaded_compression() {
        use mechanic_core::{SpringSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let mut compressions = Vec::new();
        for preload in [0.0, 0.025] {
            let spring = SpringSpec::new(0.5, 0.16, 0.12, 6, preload).unwrap();
            let spec = SuspensionSpec::new(Some(spring), None, None).unwrap();
            let creation = suspension_test_creation(spec, true, 1);
            let gpu = suspension_test_gpu(&device, &queue, &creation);
            let mut samples = Vec::new();
            for tick in 1..=60 {
                gpu.dispatch_tick(&device, &queue, tick);
                samples.push(-linear_test_snapshot(&gpu, &device, &queue, &creation, tick).0);
            }
            if preload == 0.0 {
                assert!(samples.windows(2).any(|s| s[1] > s[0] + 0.00001));
                assert!(
                    samples.windows(2).any(|s| s[1] < s[0] - 0.00001),
                    "no spring rebound: {samples:?}"
                );
            }
            compressions.push(samples.iter().copied().fold(0.0_f32, f32::max));
        }
        assert!(
            compressions[1] < compressions[0] * 0.1,
            "preload had no effect: {compressions:?}"
        );
    }

    #[test]
    fn suspension_shock_bottoms_and_rubber_supports_load_in_both_body_orientations() {
        use mechanic_core::{BumpStopSpec, ShockBodyEnd, ShockSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let mut masses = Vec::new();
        for body_end in [ShockBodyEnd::Source, ShockBodyEnd::Opposite] {
            for with_stop in [false, true] {
                let shock = ShockSpec::new(0.5, 0.1, body_end, 0.0, 1.0, 1.6).unwrap();
                let stop = with_stop.then(|| BumpStopSpec::new(0.05, 0.06).unwrap());
                let spec = SuspensionSpec::new(None, Some(shock), stop).unwrap();
                let creation = suspension_test_creation(spec, true, 1);
                let bearing = creation.bearings[0];
                let mass = creation.compounds[bearing.compound_b as usize]
                    .mass_properties
                    .mass;
                if !with_stop {
                    masses.push(mass);
                }
                let gpu = suspension_test_gpu(&device, &queue, &creation);
                for tick in 1..=360 {
                    gpu.dispatch_tick(&device, &queue, tick);
                }
                let (position, _) = linear_test_snapshot(&gpu, &device, &queue, &creation, 360);
                let compression = -position;
                if with_stop {
                    assert!(
                        compression > spec.bump_contact().unwrap(),
                        "rubber never contacted: {compression}"
                    );
                    assert!(
                        compression < spec.compression_limit().0,
                        "rubber reached crush limit under small load"
                    );
                    let force = spec.elastic_force(compression);
                    assert!(
                        (force - mass * 9.81).abs() < mass * 9.81 * 0.15,
                        "rubber load mismatch: force {force}, load {}",
                        mass * 9.81
                    );
                } else {
                    assert!(
                        (compression - spec.compression_limit().0).abs() < 0.0001,
                        "shock failed to bottom: {compression}, limit {}",
                        spec.compression_limit().0
                    );
                }
            }
        }
        assert!(
            masses[1] > masses[0],
            "body-end reversal did not move body mass: {masses:?}"
        );
    }

    #[test]
    fn suspension_passive_forces_preserve_mixed_loop_closures_in_both_routes() {
        use mechanic_core::{BearingKind, ShockSpec, SpringSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let spec = SuspensionSpec::new(
            Some(SpringSpec::default()),
            Some(ShockSpec::default()),
            None,
        )
        .unwrap();
        for copies in [1, 22] {
            // Reuse compiled mixed-loop topology to isolate the passive solver.
            // Graph placement and suspension mass ownership have separate fixtures.
            let mut creation = mixed_linear_creation(copies, true);
            for bearing in &mut creation.bearings {
                if bearing.kind.is_translational() {
                    bearing.kind = BearingKind::Suspension(spec);
                }
            }
            assert_eq!(
                creation.loop_topology.closure_bearings.len(),
                usize::try_from(copies).unwrap()
            );
            let gpu = suspension_test_gpu(&device, &queue, &creation);
            let bearing = creation.bearings[0];
            let body = &creation.compounds[bearing.compound_b as usize];
            gpu.apply_impulse(
                &device,
                &queue,
                bearing.compound_b,
                body.root_translation,
                Vec3::NEG_Z * body.mass_properties.mass,
            )
            .unwrap();
            let mut minimum = 0.0_f32;
            for tick in 1..=90 {
                gpu.dispatch_tick(&device, &queue, tick);
                if tick % 5 == 0 {
                    assert_mixed_linear_constraints(&gpu, &device, &queue, &creation, tick);
                    minimum =
                        minimum.min(linear_test_snapshot(&gpu, &device, &queue, &creation, tick).0);
                }
            }
            assert!(
                minimum < -0.001,
                "loop suspension failed to compress: {minimum}"
            );
        }
    }

    #[test]
    fn suspension_floating_mount_receives_bottom_out_reaction() {
        use mechanic_core::{ShockBodyEnd, ShockSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let spec = SuspensionSpec::new(
            None,
            Some(ShockSpec::new(0.5, 0.1, ShockBodyEnd::Source, 0.075, 0.0, 0.0).unwrap()),
            None,
        )
        .unwrap();
        for copies in [1, 65] {
            let creation = suspension_test_creation_with_anchor(spec, false, copies, false);
            let gpu = suspension_test_gpu(&device, &queue, &creation);
            let bearing = creation.bearings[0];
            let tip = &creation.compounds[bearing.compound_b as usize];
            let base = &creation.compounds[bearing.compound_a as usize];
            gpu.apply_impulse(
                &device,
                &queue,
                bearing.compound_b,
                tip.root_translation,
                Vec3::NEG_X * 20.0 * tip.mass_properties.mass,
            )
            .unwrap();
            for tick in 1..=15 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let (position, snapshot) = linear_test_snapshot(&gpu, &device, &queue, &creation, 15);
            assert!(
                (position - spec.bounds()[0]).abs() < 0.0001,
                "floating shock did not bottom: {position}"
            );
            let movement =
                transform_position(snapshot[bearing.compound_a as usize]) - base.root_translation;
            assert!(
                movement.x < -0.0001,
                "floating mount received no reaction: {movement:?}"
            );
        }
    }

    #[test]
    #[allow(clippy::float_cmp)] // Held velocities must be exactly zero.
    fn suspension_holds_suppress_passive_forces_and_release_restores_spring_motion() {
        use mechanic_core::{ShockBodyEnd, ShockSpec, SpringSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let spec = SuspensionSpec::new(
            Some(SpringSpec::default()),
            Some(ShockSpec::new(0.5, 0.1, ShockBodyEnd::Source, 0.05, 1.0, 1.6).unwrap()),
            None,
        )
        .unwrap();
        for copies in [1, 65] {
            let creation = suspension_test_creation_with_anchor(spec, false, copies, false);
            let gpu = suspension_test_gpu(&device, &queue, &creation);
            gpu.enable_async_readback();
            let poses = creation
                .compounds
                .iter()
                .map(|body| crate::GpuTransform {
                    position: body.root_translation.extend(0.0).to_array(),
                    rotation: body.root_rotation.to_array(),
                })
                .collect::<Vec<_>>();
            let mut holds = vec![true; poses.len()];
            gpu.set_body_holds(&queue, &holds).unwrap();
            gpu.prescribe_held_poses(&queue, &poses).unwrap();
            for tick in 1..=3 {
                gpu.dispatch_tick(&device, &queue, tick);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
                assert_eq!(state.diagnostics.error_flags, 0);
                assert_eq!(state.transforms, poses);
                assert!(
                    state
                        .velocities
                        .iter()
                        .all(|v| v.linear == [0.0; 4] && v.angular == [0.0; 4])
                );
            }
            let bearing = creation.bearings[0];
            holds[bearing.compound_a as usize] = false;
            holds[bearing.compound_b as usize] = false;
            gpu.set_body_holds(&queue, &holds).unwrap();
            let mut last = None;
            for tick in 4..=33 {
                gpu.dispatch_tick(&device, &queue, tick);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
                assert_eq!(state.diagnostics.error_flags, 0);
                for (index, held) in holds.iter().enumerate() {
                    if *held {
                        assert_eq!(state.transforms[index], poses[index]);
                    }
                }
                last = Some(state);
            }
            let state = last.unwrap();
            let base = bearing.compound_a as usize;
            assert!(
                state.transforms[base].position[0] < poses[base].position[0] - 0.00001,
                "released mount received no spring reaction"
            );
            let tip = bearing.compound_b as usize;
            assert!(
                state.transforms[tip].position[0] > poses[tip].position[0] + 0.02,
                "released spring did not extend from initial compression"
            );
        }
    }

    #[test]
    fn suspension_rubber_crush_limit_resists_sustained_overload_in_both_routes() {
        use mechanic_core::{BumpStopSpec, ShockSpec, SuspensionSpec};
        let (device, queue) = test_device().expect("suspension regression requires a GPU");
        let spec = SuspensionSpec::new(
            None,
            Some(ShockSpec::default()),
            Some(BumpStopSpec::new(0.05, 0.06).unwrap()),
        )
        .unwrap();
        let force = spec.elastic_force(spec.compression_limit().0) * 4.0;
        for copies in [1, 65] {
            let creation = suspension_test_creation(spec, false, copies);
            let gpu = suspension_test_gpu(&device, &queue, &creation);
            let bearing = creation.bearings[0];
            let body = &creation.compounds[bearing.compound_b as usize];
            let mut contact_point = body.root_translation;
            let mut position = 0.0;
            for tick in 1..=60 {
                gpu.apply_impulse(
                    &device,
                    &queue,
                    bearing.compound_b,
                    contact_point,
                    Vec3::NEG_X * force * crate::FIXED_DT_SECONDS,
                )
                .unwrap();
                gpu.dispatch_tick(&device, &queue, tick);
                let (displacement, snapshot) =
                    linear_test_snapshot(&gpu, &device, &queue, &creation, tick);
                position = displacement;
                contact_point = transform_position(snapshot[bearing.compound_b as usize]);
            }
            assert!(
                (-position - spec.compression_limit().0).abs() < 0.0001,
                "rubber failed to stop at 55% crush: {} vs {}",
                -position,
                spec.compression_limit().0
            );
        }
    }

    fn test_device() -> Option<(wgpu::Device, wgpu::Queue)> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor::new_without_display_handle());
        let adapter = pollster::block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::LowPower,
            compatible_surface: None,
            force_fallback_adapter: false,
        }))
        .ok()?;
        eprintln!("GPU test adapter: {:?}", adapter.get_info());
        pollster::block_on(adapter.request_device(&wgpu::DeviceDescriptor {
            label: Some("mechanic articulated test device"),
            ..Default::default()
        }))
        .ok()
    }

    #[allow(clippy::too_many_lines)]
    fn colliding_pipe_mechanism(grounded: bool) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let pose =
            |ticks, rotation| BuildPose::from_position_ticks(IVec3::from_array(ticks), rotation);
        let base = spawned_part(
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new([16, 1, 16], pose([0, -50, 0], GridRotation::default()))
                        .unwrap(),
                ))
                .unwrap(),
        );
        let carriage = spawned_part(
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new([1, 1, 1], pose([0, 90, 0], GridRotation::default()))
                        .unwrap()
                        .with_material(ConstructionMaterial::Aluminium),
                ))
                .unwrap(),
        );
        let mut stems = Vec::new();
        for (points, bend_rotation, tip_rotation, length, material) in [
            (
                [[0, 190, 0], [0, 340, 0], [-250, 340, 0]],
                GridRotation::new(0, 0, 1),
                GridRotation::new(0, 0, 1),
                0.25,
                ConstructionMaterial::Aluminium,
            ),
            (
                [[500, 100, 450], [500, 300, 450], [750, 300, 450]],
                GridRotation::new(0, 2, 1),
                GridRotation::new(0, 0, 3),
                0.5,
                ConstructionMaterial::Steel,
            ),
        ] {
            let stem = spawned_part(
                graph
                    .apply(BuildCommand::SpawnCylinder(
                        CylinderSpec::new(
                            CylinderDimensions::new(0.25, 0.0, length).unwrap(),
                            pose(points[0], GridRotation::default()),
                        )
                        .with_material(material),
                    ))
                    .unwrap(),
            );
            let bend = spawned_part(
                graph
                    .apply(BuildCommand::SpawnPipeBend(
                        PipeBendSpec::new(
                            PipeBendDimensions::new(0.25, 0.0, 0.25).unwrap(),
                            pose(points[1], bend_rotation),
                        )
                        .with_material(material),
                    ))
                    .unwrap(),
            );
            let tip = spawned_part(
                graph
                    .apply(BuildCommand::SpawnCylinder(
                        CylinderSpec::new(
                            CylinderDimensions::new(0.25, 0.0, 0.75).unwrap(),
                            pose(points[2], tip_rotation),
                        )
                        .with_material(material),
                    ))
                    .unwrap(),
            );
            for second in [bend, tip] {
                graph
                    .apply(BuildCommand::RigidLink(RigidLinkSpec {
                        first: stem,
                        second,
                    }))
                    .unwrap();
            }
            stems.push(stem);
        }
        graph
            .apply(BuildCommand::AddBearing(
                BearingSpec::new(
                    FaceRef::part(base, FaceKind::PositiveY),
                    FaceRef::part(carriage, FaceKind::NegativeY),
                    Vec3::ZERO,
                    Vec3::X,
                )
                .with_kind(mechanic_core::BearingKind::Linear(
                    mechanic_core::LinearBearing {
                        dimensions: mechanic_core::LinearBearingDimensions::new(1.75, 0.4).unwrap(),
                        mount_normal: Vec3::Y,
                        face: mechanic_core::CarriageFace::Top,
                    },
                )),
            ))
            .unwrap();
        for (parent, child, anchor) in [
            (carriage, stems[0], Vec3::new(0.0, 0.35, 0.0)),
            (base, stems[1], Vec3::new(1.25, 0.0, 1.125)),
        ] {
            graph
                .apply(BuildCommand::AddBearing(BearingSpec::new(
                    FaceRef::part(parent, FaceKind::PositiveY),
                    FaceRef::part(child, FaceKind::NegativeY),
                    anchor,
                    Vec3::Y,
                )))
                .unwrap();
        }
        let creation = graph
            .compile_with_static_parts(grounded.then_some(base))
            .unwrap();
        let pipe_bodies = stems
            .iter()
            .map(|part| {
                creation
                    .part_to_compound
                    .iter()
                    .find(|(p, _)| p == part)
                    .unwrap()
                    .1
            })
            .collect::<Vec<_>>();
        assert_eq!(creation.loop_topology.mechanism_components.len(), 1);
        assert!(
            !creation
                .collision_suppression
                .contains(&[pipe_bodies[0], pipe_bodies[1]])
        );
        creation
    }

    #[test]
    fn dense_pipe_contacts_on_bearings_and_a_rail_remain_bounded() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        for grounded in [true, false] {
            for rail_position in [0.4, 0.5] {
                let creation = colliding_pipe_mechanism(grounded);
                let gpu = GpuPhysics::new_with_config(
                    &device,
                    &queue,
                    &creation,
                    GpuPhysicsConfig {
                        ground_plane_enabled: false,
                        ..Default::default()
                    },
                )
                .unwrap();
                gpu.dispatch_tick(&device, &queue, 1);
                let coordinates = [
                    GpuMechanismCoordinate {
                        position: rail_position,
                        velocity: 0.3,
                    },
                    GpuMechanismCoordinate {
                        position: 3.0 * std::f32::consts::FRAC_PI_4,
                        velocity: 0.0,
                    },
                    GpuMechanismCoordinate {
                        position: std::f32::consts::FRAC_PI_2,
                        velocity: 0.0,
                    },
                ];
                gpu.initialize_mechanism_coordinates(&queue, &coordinates)
                    .unwrap();
                let mut encoder =
                    device.create_command_encoder(&wgpu::CommandEncoderDescriptor::default());
                gpu.encode_mechanism_forward_kinematics(&mut encoder, None, 0);
                super::direct_compute_pass(
                    &mut encoder,
                    "initialize pipe motion",
                    &gpu.mechanism.reconstruct_velocities_pipeline,
                    &gpu.mechanism.reconstruct_velocities_bind_group,
                    1,
                    None,
                );
                queue.submit([encoder.finish()]);
                let mut maximum_contacts = 0;
                let mut maximum_speed = 0.0_f32;
                for tick in 2..=600 {
                    gpu.dispatch_tick(&device, &queue, tick);
                    device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                    let state = copy_state_rows::<GpuMechanismCoordinate>(
                        &device,
                        &queue,
                        &gpu.mechanism.coordinates,
                        gpu.mechanism.coordinate_count,
                    );
                    let diagnostics = gpu.read_last_tick(&device).unwrap();
                    assert_eq!(diagnostics.error_flags, 0);
                    maximum_contacts = maximum_contacts.max(diagnostics.active_contact_count);
                    for coordinate in state {
                        maximum_speed = maximum_speed.max(coordinate.velocity.abs());
                        assert!(
                            coordinate.position.is_finite()
                                && coordinate.velocity.is_finite()
                                && coordinate.velocity.abs() < 3.0,
                            "grounded={grounded} rail={rail_position} tick={tick}: {coordinate:?}"
                        );
                    }
                }
                eprintln!(
                    "pipe contacts: grounded={grounded} rail={rail_position} max_contacts={maximum_contacts} max_joint_speed={maximum_speed}"
                );
                assert!(
                    maximum_contacts > 8,
                    "fixture must exercise dense internal contacts"
                );
            }
        }
    }

    struct ArticulatedCarFixture {
        creation: mechanic_core::CompiledCreation,
        chassis: u32,
        dynamic_bodies: Vec<u32>,
        wheel_bodies: Vec<u32>,
    }

    fn spawned_part(outcome: BuildOutcome) -> PartId {
        let BuildOutcome::Spawned(part) = outcome else {
            unreachable!()
        };
        part
    }

    fn articulated_car_fixture() -> ArticulatedCarFixture {
        let mut graph = ConstructionGraph::new();
        let chassis_spec = CuboidSpec::new(
            [8, 2, 12],
            BuildPose::new(IVec3::new(0, 5, 0), GridRotation::default()),
        )
        .unwrap();
        let chassis_part = spawned_part(graph.apply(BuildCommand::Spawn(chassis_spec)).unwrap());

        let mut knuckles = Vec::new();
        let mut wheels = Vec::new();
        for z_units in [-4, 4] {
            let anchor_z = if z_units < 0 { -1.0 } else { 1.0 };
            for x_units in [-3, 3] {
                let steering_anchor_x = if x_units < 0 { -0.75 } else { 0.75 };
                let knuckle_spec = CuboidSpec::new(
                    [2, 2, 2],
                    BuildPose::new(IVec3::new(x_units, 3, z_units), GridRotation::default()),
                )
                .unwrap();
                let knuckle = spawned_part(graph.apply(BuildCommand::Spawn(knuckle_spec)).unwrap());
                knuckles.push(knuckle);

                let wheel_spec = CylinderSpec::new(
                    CylinderDimensions::new(1.0, 0.0, 0.5).unwrap(),
                    BuildPose::new(
                        IVec3::new(if x_units < 0 { -5 } else { 5 }, 3, z_units),
                        GridRotation::new(0, 0, 1),
                    ),
                );
                let wheel = spawned_part(
                    graph
                        .apply(BuildCommand::SpawnCylinder(wheel_spec))
                        .unwrap(),
                );
                wheels.push(wheel);

                graph
                    .apply(BuildCommand::AddBearing(BearingSpec::new(
                        FaceRef::part(chassis_part, FaceKind::NegativeY),
                        FaceRef::part(knuckle, FaceKind::PositiveY),
                        Vec3::new(steering_anchor_x, 1.0, anchor_z),
                        Vec3::NEG_Y,
                    )))
                    .unwrap();
                let (source_face, target_face, axis, anchor_x) = if x_units < 0 {
                    (FaceKind::NegativeX, FaceKind::NegativeY, Vec3::NEG_X, -1.0)
                } else {
                    (FaceKind::PositiveX, FaceKind::PositiveY, Vec3::X, 1.0)
                };
                graph
                    .apply(BuildCommand::AddBearing(BearingSpec::new(
                        FaceRef::part(knuckle, source_face),
                        FaceRef::part(wheel, target_face),
                        Vec3::new(anchor_x, 0.75, anchor_z),
                        axis,
                    )))
                    .unwrap();
            }
        }

        let wall_spec = CuboidSpec::new(
            [16, 8, 2],
            BuildPose::new(IVec3::new(0, 4, -10), GridRotation::default()),
        )
        .unwrap();
        let wall = spawned_part(graph.apply(BuildCommand::Spawn(wall_spec)).unwrap());
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(wall, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();

        let creation = graph.compile().unwrap();
        let body_for = |part| {
            creation
                .part_to_compound
                .iter()
                .find_map(|(candidate, body)| (*candidate == part).then_some(*body))
                .unwrap()
        };
        let chassis = body_for(chassis_part);
        let mut dynamic_bodies = vec![chassis];
        dynamic_bodies.extend(knuckles.iter().copied().map(body_for));
        let wheel_bodies = wheels.iter().copied().map(body_for).collect::<Vec<_>>();
        dynamic_bodies.extend(wheel_bodies.iter().copied());
        dynamic_bodies.sort_unstable();
        dynamic_bodies.dedup();
        ArticulatedCarFixture {
            creation,
            chassis,
            dynamic_bodies,
            wheel_bodies,
        }
    }

    fn pipe_bend_suspension_car_fixture() -> ArticulatedCarFixture {
        // The overshoot-only fixture models a heavy hydraulic steering rack.
        // Powered steering coverage below uses the production Servo torque.
        pipe_bend_suspension_car_fixture_with_steering_torque(64_000.0)
    }

    #[allow(clippy::too_many_lines)]
    fn pipe_bend_suspension_car_fixture_with_steering_torque(
        steering_torque: f32,
    ) -> ArticulatedCarFixture {
        pipe_bend_car_fixture(steering_torque, false)
    }

    #[allow(clippy::too_many_lines)]
    fn pipe_bend_car_fixture(
        steering_torque: f32,
        front_steering_only: bool,
    ) -> ArticulatedCarFixture {
        let mut graph = ConstructionGraph::new();
        let static_marker = spawned_part(
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new(
                        [2, 2, 2],
                        BuildPose::new(IVec3::new(0, 1, -400), GridRotation::default()),
                    )
                    .unwrap(),
                ))
                .unwrap(),
        );
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(static_marker, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        let chassis_spec = CuboidSpec::new(
            [12, 1, 8],
            BuildPose::from_position_ticks(IVec3::new(0, 450, 0), GridRotation::default()),
        )
        .unwrap()
        .with_material(ConstructionMaterial::Stone);
        let chassis_part = spawned_part(graph.apply(BuildCommand::Spawn(chassis_spec)).unwrap());
        let bend_dimensions = PipeBendDimensions::new(0.2, 0.0, 0.25).unwrap();

        let corners = [
            (600, 1.5, 1, 0.875, 1.125),
            (-600, -1.5, 1, 0.875, 1.125),
            (-600, -1.5, -1, -0.875, -1.125),
            (600, 1.5, -1, -0.875, -1.125),
        ];
        let mut bends = [None; 4];
        let mut wheels = [None; 4];
        // Match the unfavorable child-before-parent ordering of a garage-built
        // car. Correct contact support must not depend on creation order.
        for (wheel, corner) in [
            (true, 0),
            (false, 1),
            (true, 1),
            (false, 2),
            (true, 2),
            (false, 3),
            (false, 0),
            (true, 3),
        ] {
            let (x_ticks, _, z_sign, _, _) = corners[corner];
            let bend_rotation = if z_sign > 0 {
                GridRotation::new(0, 3, 3)
            } else {
                GridRotation::new(0, 1, 3)
            };
            let wheel_rotation = if z_sign > 0 {
                GridRotation::new(1, 0, 0)
            } else {
                GridRotation::new(1, 2, 2)
            };
            if wheel {
                wheels[corner] = Some(spawned_part(
                    graph
                        .apply(BuildCommand::SpawnCylinder(
                            CylinderSpec::new(
                                CylinderDimensions::new(0.95, 0.0, 0.25).unwrap(),
                                BuildPose::from_position_ticks(
                                    IVec3::new(x_ticks, 290, z_sign * 500),
                                    wheel_rotation,
                                ),
                            )
                            .with_material(ConstructionMaterial::Rubber),
                        ))
                        .unwrap(),
                ));
            } else {
                bends[corner] = Some(spawned_part(
                    graph
                        .apply(BuildCommand::SpawnPipeBend(PipeBendSpec::new(
                            bend_dimensions,
                            BuildPose::from_position_ticks(
                                IVec3::new(x_ticks, 300, z_sign * 350),
                                bend_rotation,
                            ),
                        )))
                        .unwrap(),
                ));
            }
        }
        let ballast = spawned_part(
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new(
                        [4, 3, 4],
                        BuildPose::new(IVec3::new(-1, 5, 0), GridRotation::default()),
                    )
                    .unwrap(),
                ))
                .unwrap(),
        );
        graph
            .apply(BuildCommand::RigidLink(RigidLinkSpec {
                first: chassis_part,
                second: ballast,
            }))
            .unwrap();
        let bends = bends.map(Option::unwrap);
        let wheels = wheels.map(Option::unwrap);
        for corner in [0, 3, 2, 1] {
            let (_, x, _, bend_z, _) = corners[corner];
            if front_steering_only && x < 0.0 {
                graph
                    .apply(BuildCommand::RigidLink(RigidLinkSpec {
                        first: chassis_part,
                        second: bends[corner],
                    }))
                    .unwrap();
                continue;
            }
            graph
                .apply(BuildCommand::AddBearing(BearingSpec::new(
                    FaceRef::part(chassis_part, FaceKind::NegativeY),
                    FaceRef::part(bends[corner], FaceKind::NegativeX),
                    Vec3::new(x, 1.0, bend_z),
                    Vec3::NEG_Y,
                )))
                .unwrap();
        }
        for corner in [1, 0, 3, 2] {
            let (_, x, z_sign, _, wheel_z) = corners[corner];
            graph
                .apply(BuildCommand::AddBearing(BearingSpec::new(
                    FaceRef::part(bends[corner], FaceKind::PositiveY),
                    FaceRef::part(wheels[corner], FaceKind::NegativeY),
                    Vec3::new(x, 0.75, wheel_z),
                    if z_sign > 0 { Vec3::Z } else { Vec3::NEG_Z },
                )))
                .unwrap();
        }

        let mut creation = graph.compile().unwrap();
        for coordinate in 0..if front_steering_only { 2 } else { 4 } {
            let acceleration =
                steering_torque / creation.loop_topology.coordinate_axis_inertia[coordinate];
            let drive = &mut creation.coordinate_drives[coordinate];
            *drive = CoordinateDrive {
                mode: DriveMode::Angle,
                target_speed: 0.0,
                target_angle: 0.0,
                max_speed: std::f32::consts::PI,
                max_acceleration: acceleration,
                source_a_max_acceleration: acceleration,
                source_a_no_load_speed: std::f32::consts::PI,
                source_b_max_acceleration: 0.0,
                source_b_no_load_speed: 0.0,
                min_angle: -std::f32::consts::FRAC_PI_4,
                max_angle: std::f32::consts::FRAC_PI_4,
            };
        }
        let body_for = |part| {
            creation
                .part_to_compound
                .iter()
                .find_map(|(candidate, body)| (*candidate == part).then_some(*body))
                .unwrap()
        };
        let chassis = body_for(chassis_part);
        let mut dynamic_bodies = vec![chassis];
        dynamic_bodies.extend(bends.into_iter().map(body_for));
        let wheel_bodies = wheels.iter().copied().map(body_for).collect::<Vec<_>>();
        dynamic_bodies.extend(wheel_bodies.iter().copied());
        dynamic_bodies.sort_unstable();
        dynamic_bodies.dedup();
        ArticulatedCarFixture {
            creation,
            chassis,
            dynamic_bodies,
            wheel_bodies,
        }
    }

    fn rigid_axle_car_fixture() -> ArticulatedCarFixture {
        let mut graph = ConstructionGraph::new();
        let chassis_part = spawned_part(
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new(
                        [12, 2, 11],
                        BuildPose::from_position_ticks(
                            IVec3::new(0, 300, 0),
                            GridRotation::default(),
                        ),
                    )
                    .unwrap()
                    .with_material(ConstructionMaterial::Stone),
                ))
                .unwrap(),
        );
        let mut wheels = Vec::new();
        for x_ticks in [-400_i32, 400] {
            for z_ticks in [-600_i32, 600] {
                let z_sign = z_ticks.signum();
                let anchor_x = if x_ticks < 0 { -1.0 } else { 1.0 };
                let anchor_z = if z_ticks < 0 { -1.375 } else { 1.375 };
                let wheel = spawned_part(
                    graph
                        .apply(BuildCommand::SpawnCylinder(
                            CylinderSpec::new(
                                CylinderDimensions::new(0.95, 0.0, 0.25).unwrap(),
                                BuildPose::from_position_ticks(
                                    IVec3::new(x_ticks, 200, z_ticks),
                                    if z_sign > 0 {
                                        GridRotation::new(1, 0, 0)
                                    } else {
                                        GridRotation::new(1, 2, 2)
                                    },
                                ),
                            )
                            .with_material(ConstructionMaterial::Rubber),
                        ))
                        .unwrap(),
                );
                wheels.push(wheel);
                graph
                    .apply(BuildCommand::AddBearing(BearingSpec::new(
                        FaceRef::part(
                            chassis_part,
                            if z_sign > 0 {
                                FaceKind::PositiveZ
                            } else {
                                FaceKind::NegativeZ
                            },
                        ),
                        FaceRef::part(wheel, FaceKind::NegativeY),
                        Vec3::new(anchor_x, 0.5, anchor_z),
                        if z_sign > 0 { Vec3::Z } else { Vec3::NEG_Z },
                    )))
                    .unwrap();
            }
        }

        let mut creation = graph.compile().unwrap();
        for drive in &mut creation.coordinate_drives {
            drive.mode = DriveMode::Speed;
            drive.target_speed = 0.0;
            drive.max_speed = std::f32::consts::TAU * 6.0;
        }
        let body_for = |part| {
            creation
                .part_to_compound
                .iter()
                .find_map(|(candidate, body)| (*candidate == part).then_some(*body))
                .unwrap()
        };
        let chassis = body_for(chassis_part);
        let wheel_bodies = wheels.into_iter().map(body_for).collect::<Vec<_>>();
        let mut dynamic_bodies = vec![chassis];
        dynamic_bodies.extend(wheel_bodies.iter().copied());
        ArticulatedCarFixture {
            creation,
            chassis,
            dynamic_bodies,
            wheel_bodies,
        }
    }

    #[test]
    fn full_cylinder_ground_contacts_match_visual_wheel_radius() {
        let fixture = articulated_car_fixture();
        let ground_data = full_cylinder_ground_data(&fixture.creation.colliders);
        let analytic = ground_data
            .iter()
            .filter(|ground| ground.role != 0)
            .collect::<Vec<_>>();
        let primary = ground_data
            .iter()
            .filter(|ground| ground.role == FULL_CYLINDER_GROUND_FIRST)
            .collect::<Vec<_>>();
        let secondary_count = ground_data
            .iter()
            .filter(|ground| ground.role > FULL_CYLINDER_GROUND_FIRST)
            .count();
        assert_eq!(primary.len(), 4);
        assert_eq!(analytic.len(), 64);
        assert_eq!(secondary_count, 60);
        assert!(analytic.iter().all(|ground| {
            (ground.center_radius - 0.25).abs() < 1.0e-6
                && (ground.outer_radius - 0.5).abs() < 1.0e-6
        }));
        for role in 1..=16 {
            assert_eq!(
                analytic.iter().filter(|ground| ground.role == role).count(),
                4
            );
        }

        let mut sector_graph = ConstructionGraph::new();
        let sector_dimensions = CylinderDimensions::new(1.0, 0.0, 0.5)
            .unwrap()
            .with_sweep_angle_degrees(180)
            .unwrap();
        sector_graph
            .apply(BuildCommand::SpawnCylinder(CylinderSpec::new(
                sector_dimensions,
                BuildPose::default(),
            )))
            .unwrap();
        let sector = sector_graph.compile().unwrap();
        assert!(
            full_cylinder_ground_data(&sector.colliders)
                .iter()
                .all(|ground| ground.role == 0)
        );
    }

    fn transform_position(transform: crate::GpuTransform) -> Vec3 {
        Vec3::new(
            transform.position[0],
            transform.position[1],
            transform.position[2],
        )
    }

    fn snapshot_speed(current: crate::GpuTransform, previous: crate::GpuTransform) -> f32 {
        (transform_position(current) - transform_position(previous)).length() * 60.0
    }

    fn bearing_speed(
        current: &[crate::GpuTransform],
        previous: &[crate::GpuTransform],
        bearing: &mechanic_core::CompiledBearing,
    ) -> f32 {
        let current_relative = relative_bearing_rotation(current, bearing);
        let previous_relative = relative_bearing_rotation(previous, bearing);
        let delta = previous_relative.conjugate() * current_relative;
        2.0 * delta.xyz().length().atan2(delta.w.abs()) * 60.0
    }

    #[test]
    fn gpu_pipelines_construct_on_noop_backend() {
        let (device, queue) = wgpu::Device::noop(&wgpu::DeviceDescriptor {
            label: Some("mechanic pipeline validation device"),
            ..Default::default()
        });
        let creation = pendulum_creation(true);
        for mechanism_self_collisions in [true, false] {
            GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: true,
                    ground_plane_enabled: true,
                    mechanism_self_collisions,
                    solver_iterations: 8,
                },
            )
            .unwrap();
        }
    }

    #[test]
    fn collider_local_ground_planes_support_bodies_at_different_heights() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        let low = match graph
            .apply(BuildCommand::Spawn(
                CuboidSpec::new(
                    [4; 3],
                    BuildPose::from_half_grid(IVec3::new(-16, 16, 0), GridRotation::default()),
                )
                .unwrap(),
            ))
            .unwrap()
        {
            BuildOutcome::Spawned(part) => part,
            other => panic!("unexpected build outcome {other:?}"),
        };
        let high = match graph
            .apply(BuildCommand::Spawn(
                CuboidSpec::new(
                    [4; 3],
                    BuildPose::from_half_grid(IVec3::new(16, 16, 0), GridRotation::default()),
                )
                .unwrap(),
            ))
            .unwrap()
        {
            BuildOutcome::Spawned(part) => part,
            other => panic!("unexpected build outcome {other:?}"),
        };
        let creation = graph.compile().unwrap();
        let body_for = |part| {
            creation
                .part_to_compound
                .iter()
                .find_map(|(candidate, body)| (*candidate == part).then_some(*body as usize))
                .unwrap()
        };
        let planes = creation
            .colliders
            .iter()
            .map(|collider| GpuGroundPlane {
                normal: Vec3::Y,
                offset: if collider.source_part == low {
                    0.0
                } else {
                    0.75
                },
            })
            .collect::<Vec<_>>();
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        assert_eq!(
            gpu.write_ground_planes(&queue, &planes[..1]),
            Err(GpuGroundPlaneError::PlaneCount {
                provided: 1,
                expected: 2,
            })
        );
        gpu.write_ground_planes(&queue, &planes).unwrap();
        for tick in 1..=180 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let snapshot = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let low_y = snapshot[body_for(low)].position[1];
        let high_y = snapshot[body_for(high)].position[1];
        assert!((low_y - 0.5).abs() < 0.02, "low body settled at {low_y}");
        assert!(
            (high_y - 1.25).abs() < 0.02,
            "high body settled at {high_y}"
        );
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
    }

    #[test]
    fn late_mapping_callbacks_cannot_reorder_publication() {
        assert_eq!(
            super::oldest_completed_readback([(2, 7, 1), (0, 8, 0)].into_iter()),
            None
        );
        assert_eq!(
            super::oldest_completed_readback([(2, 7, 0), (0, 8, 0)].into_iter()),
            Some(2)
        );
    }

    #[test]
    fn submission_sequence_and_execution_evidence_survive_scheduler_gaps() {
        let (device, queue) =
            test_device().expect("execution evidence requires a real GPU adapter");
        let creation = pendulum_creation(false);
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &creation,
            GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            },
        )
        .unwrap();
        gpu.enable_async_readback();
        for (sequence, tick) in [(1, 4), (2, 22)] {
            let submission = gpu.dispatch_tick(&device, &queue, tick);
            assert_eq!(submission.submission_sequence, sequence);
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let completed = gpu.poll_tick_readback(&device).unwrap().unwrap();
            assert_eq!(completed.submission_sequence, sequence);
            assert_eq!(completed.tick_index, tick);
            assert_eq!(completed.diagnostics.error_flags, 0);
            let evidence = completed.diagnostics.execution;
            assert_eq!(
                evidence.integrated_bodies as usize,
                creation.compounds.len()
            );
            assert_eq!(evidence.published_bodies as usize, creation.compounds.len());
            assert_eq!(
                evidence.validated_bearings as usize,
                creation.bearings.len()
            );
            assert_eq!(evidence.stage_mask, 1 | 2 | 32 | 64);
        }
        queue.write_buffer(
            &gpu.diagnostics,
            0,
            bytemuck::bytes_of(&crate::INVALID_NUMERIC_FLAG),
        );
        gpu.dispatch_tick(&device, &queue, 23);
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let completed = gpu.poll_tick_readback(&device).unwrap().unwrap();
        assert_ne!(completed.diagnostics.error_flags, 0);
        assert_eq!(completed.diagnostics.execution.integrated_bodies, 0);
        assert_eq!(completed.diagnostics.execution.published_bodies, 0);
    }

    #[test]
    fn callback_timing_distinguishes_servicing_from_later_consumption() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let creation = pendulum_creation(false);
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        gpu.enable_async_readback();
        gpu.enable_readback_timing();
        gpu.dispatch_tick(&device, &queue, 1);
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let serviced = std::time::Instant::now();
        std::thread::sleep(std::time::Duration::from_millis(5));
        let readback = gpu.poll_tick_readback(&device).unwrap().unwrap();
        let callback = readback.callbacks_completed_at.unwrap();
        assert!(callback <= serviced);
        assert_eq!(readback.callbacks_during_poll, Some(false));
        assert!(callback.elapsed() >= std::time::Duration::from_millis(5));
        assert!(readback.submission_to_callbacks_ms.unwrap() <= readback.submission_to_readback_ms);
        assert_eq!(readback.diagnostics.error_flags, 0);
        assert_eq!(
            gpu.async_readback_slots_available(),
            ASYNC_READBACK_RING_SIZE
        );
    }

    #[test]
    fn asynchronous_tick_readback_is_monotonic_and_tick_matched() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let creation = pendulum_creation(false);
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        gpu.enable_async_readback();
        let ring = u64::try_from(ASYNC_READBACK_RING_SIZE).unwrap();
        for tick in 1..=ring {
            let started = std::time::Instant::now();
            let submission = gpu.dispatch_tick(&device, &queue, tick);
            let elapsed_ms = started.elapsed().as_secs_f64() * 1_000.0;
            let timings = submission.cpu_timings;
            let stages = [
                timings.encoding_ms,
                timings.finalization_ms,
                timings.submission_ms,
                timings.readback_setup_ms,
            ];
            assert!(
                stages
                    .iter()
                    .all(|value| value.is_finite() && *value >= 0.0)
            );
            assert!(stages.iter().sum::<f64>() <= elapsed_ms);
            assert_eq!(submission.tick_index, tick);
        }
        // A full ring is the app's submission budget: the backlog waits on the
        // CPU rather than growing an unbounded GPU queue.
        assert_eq!(gpu.async_readback_slots_available(), 0);
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();

        let mut completed = Vec::new();
        while let Some(readback) = gpu.poll_tick_readback(&device).unwrap() {
            assert_eq!(readback.callbacks_completed_at, None);
            assert_eq!(readback.submission_to_callbacks_ms, None);
            assert_eq!(readback.callbacks_during_poll, None);
            assert_eq!(readback.snapshot_slot, (readback.tick_index % 3) as u8);
            assert_eq!(readback.transforms.len(), creation.compounds.len());
            completed.push(readback.tick_index);
        }
        assert_eq!(
            gpu.async_readback_slots_available(),
            ASYNC_READBACK_RING_SIZE
        );
        gpu.dispatch_tick(&device, &queue, ring + 1);
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let readback = gpu.poll_tick_readback(&device).unwrap().unwrap();
        completed.push(readback.tick_index);
        assert_eq!(
            completed,
            (1..=ring + 1).collect::<Vec<_>>(),
            "every submitted tick is read back once, in order"
        );
    }

    fn copy_state_rows<T: bytemuck::Pod>(
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        source: &wgpu::Buffer,
        count: u32,
    ) -> Vec<T> {
        let size = u64::from(count) * size_of::<T>() as u64;
        let destination = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("independent state verification"),
            size,
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::MAP_READ,
            mapped_at_creation: false,
        });
        let mut encoder = device.create_command_encoder(&wgpu::CommandEncoderDescriptor::default());
        encoder.copy_buffer_to_buffer(source, 0, &destination, 0, size);
        queue.submit([encoder.finish()]);
        super::map_for_read(device, &destination).unwrap();
        let rows = super::mapped_rows(&destination, count);
        destination.unmap();
        rows
    }

    #[test]
    fn authoritative_readback_keeps_velocities_and_coordinates_with_their_tick() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        for creation in [
            pendulum_creation(false),
            linear_test_creation(Vec3::Z, true),
        ] {
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            gpu.enable_async_readback();
            gpu.initialize_mechanism_coordinates(
                &queue,
                &[crate::GpuMechanismCoordinate {
                    position: 0.1,
                    velocity: 0.3,
                }],
            )
            .unwrap();
            let mut expected = Vec::new();
            for tick in 1..=3 {
                gpu.dispatch_tick(&device, &queue, tick);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                // Independently copy authoritative buffers now; delayed async
                // consumption must still return these values after later ticks.
                expected.push((
                    copy_state_rows::<[f32; 4]>(
                        &device,
                        &queue,
                        &gpu.linear_velocities,
                        gpu.body_count,
                    ),
                    copy_state_rows::<[f32; 4]>(
                        &device,
                        &queue,
                        &gpu.angular_velocities,
                        gpu.body_count,
                    ),
                    copy_state_rows::<crate::GpuMechanismCoordinate>(
                        &device,
                        &queue,
                        &gpu.mechanism.coordinates,
                        gpu.mechanism.coordinate_count,
                    ),
                ));
            }
            for (index, (linear, angular, coordinates)) in expected.into_iter().enumerate() {
                let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
                assert_eq!(state.tick_index, index as u64 + 1);
                assert_eq!(state.diagnostics.error_flags, 0);
                assert_eq!(state.coordinates, coordinates);
                assert_eq!(
                    state
                        .velocities
                        .iter()
                        .map(|v| v.linear)
                        .collect::<Vec<_>>(),
                    linear
                );
                assert_eq!(
                    state
                        .velocities
                        .iter()
                        .map(|v| v.angular)
                        .collect::<Vec<_>>(),
                    angular
                );
                assert!(
                    state
                        .coordinates
                        .iter()
                        .all(|q| q.position.is_finite() && q.velocity.is_finite())
                );
            }
        }
    }

    #[test]
    #[allow(clippy::float_cmp)] // Held velocities must remain exactly zero.
    fn held_rotational_and_linear_components_ignore_drives_impulses_and_reconstruction() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        for creation in [
            pendulum_creation(false),
            linear_test_creation(Vec3::Z, false),
            mixed_linear_creation(1, true),
        ] {
            let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
            gpu.enable_async_readback();
            let mut poses = creation
                .compounds
                .iter()
                .enumerate()
                .map(|(body, compound)| crate::GpuTransform {
                    position: (compound.root_translation + Vec3::Y * 5.0)
                        .extend(0.0)
                        .to_array(),
                    // Deliberately violate joint alignment during a prescribed animation.
                    rotation: bevy_math::Quat::from_rotation_y(if body == 0 { 0.7 } else { -1.0 })
                        .to_array(),
                })
                .collect::<Vec<_>>();
            let holds = vec![true; poses.len()];
            gpu.set_body_holds(&queue, &holds).unwrap();
            gpu.prescribe_held_poses(&queue, &poses).unwrap();
            let mut drives = creation
                .coordinate_drives
                .iter()
                .copied()
                .map(crate::GpuMechanismDrive::from)
                .collect::<Vec<_>>();
            for drive in &mut drives {
                drive.mode = crate::DRIVE_MODE_SPEED;
                drive.target_speed = 10.0;
                drive.max_speed = 10.0;
                drive.max_acceleration = 1000.0;
            }
            gpu.write_mechanism_drives(&queue, &drives).unwrap();
            for tick in 1..=8 {
                for (body, pose) in poses.iter().enumerate() {
                    gpu.apply_impulse(
                        &device,
                        &queue,
                        u32::try_from(body).unwrap(),
                        transform_position(*pose) + Vec3::X,
                        Vec3::new(1.0e5, -1.0e5, 1.0e5),
                    )
                    .unwrap();
                }
                gpu.dispatch_tick(&device, &queue, tick);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
                assert_eq!(state.diagnostics.error_flags, 0);
                assert_eq!(state.transforms, poses);
                assert!(
                    state
                        .velocities
                        .iter()
                        .all(|v| v.linear == [0.0; 4] && v.angular == [0.0; 4])
                );
                assert!(
                    state
                        .coordinates
                        .iter()
                        .all(|q| q.position == 0.0 && q.velocity == 0.0)
                );
            }
            // Free-fall release assertions below apply to the ungrounded fixtures.
            if creation.compounds.iter().any(|body| body.is_static) {
                continue;
            }
            for (pose, compound) in poses.iter_mut().zip(&creation.compounds) {
                pose.rotation = compound.root_rotation.to_array();
            }
            gpu.prescribe_held_poses(&queue, &poses).unwrap();
            gpu.write_mechanism_drives(
                &queue,
                &vec![crate::GpuMechanismDrive::PASSIVE; drives.len()],
            )
            .unwrap();
            gpu.set_body_holds(&queue, &vec![false; poses.len()])
                .unwrap();
            gpu.dispatch_tick(&device, &queue, 9);
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let released = gpu.poll_tick_readback(&device).unwrap().unwrap();
            assert_eq!(released.diagnostics.error_flags, 0);
            assert!(
                released
                    .velocities
                    .iter()
                    .all(|v| v.linear[1] < 0.0 && v.linear[1] > -0.2)
            );
        }
    }

    #[test]
    fn held_body_supports_a_falling_neighbor_without_moving() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        for y in [8, 16] {
            graph
                .apply(BuildCommand::Spawn(
                    CuboidSpec::new(
                        [4; 3],
                        BuildPose::new(IVec3::new(0, y, 0), GridRotation::default()),
                    )
                    .unwrap(),
                ))
                .unwrap();
        }
        let creation = graph.compile().unwrap();
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        gpu.enable_async_readback();
        gpu.set_body_holds(&queue, &[true, false]).unwrap();
        let mut final_state = None;
        for tick in 1..=120 {
            gpu.dispatch_tick(&device, &queue, tick);
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
            assert_eq!(state.diagnostics.error_flags, 0);
            assert!((state.transforms[0].position[1] - 2.0).abs() < 1.0e-6);
            final_state = Some(state);
        }
        let y = final_state.unwrap().transforms[1].position[1];
        assert!(
            (y - 3.0).abs() < 0.03,
            "neighbor must land on held body: {y}"
        );
    }

    #[test]
    fn releasing_a_loaded_hold_discards_only_changed_contact_warmstarts() {
        let (device, queue) = test_device().expect("hold release regression requires an adapter");
        let mut graph = ConstructionGraph::new();
        for x in [0, 16] {
            for y in [8, 12] {
                graph
                    .apply(BuildCommand::Spawn(
                        CuboidSpec::new(
                            [4; 3],
                            BuildPose::new(IVec3::new(x, y, 0), GridRotation::default()),
                        )
                        .unwrap(),
                    ))
                    .unwrap();
            }
        }
        let creation = graph.compile().unwrap();
        let config = GpuPhysicsConfig {
            solver_iterations: 1,
            ground_plane_enabled: false,
            ..Default::default()
        };
        let released = GpuPhysics::new_with_config(&device, &queue, &creation, config).unwrap();
        let unchanged = GpuPhysics::new_with_config(&device, &queue, &creation, config).unwrap();
        for gpu in [&released, &unchanged] {
            gpu.enable_async_readback();
            gpu.set_body_holds(&queue, &[true, false, true, false])
                .unwrap();
        }
        let mut last_state = None;
        for tick in 1..=60 {
            for gpu in [&released, &unchanged] {
                gpu.dispatch_tick(&device, &queue, tick);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
                assert_eq!(state.diagnostics.error_flags, 0);
                last_state = Some(state);
            }
        }
        let state = last_state.unwrap();
        let cold = GpuPhysics::new_with_config(&device, &queue, &creation, config).unwrap();
        cold.enable_async_readback();
        cold.set_body_holds(&queue, &[false, false, true, false])
            .unwrap();
        cold.write_body_states(&queue, &state.transforms, &state.velocities)
            .unwrap();
        released
            .set_body_holds(&queue, &[false, false, true, false])
            .unwrap();
        let mut results = Vec::new();
        for gpu in [&released, &unchanged, &cold] {
            gpu.dispatch_tick(&device, &queue, 61);
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
            assert_eq!(state.diagnostics.error_flags, 0);
            results.push(state);
        }
        // The released pair must behave like the same state with an empty cache.
        // The unrelated pair must retain its prior cache and match the control.
        for (bodies, reference) in [(0..2, 2), (2..4, 1)] {
            for body in bodies {
                let actual = results[0].velocities[body];
                let expected = results[reference].velocities[body];
                for (actual, expected) in actual
                    .linear
                    .into_iter()
                    .chain(actual.angular)
                    .zip(expected.linear.into_iter().chain(expected.angular))
                {
                    assert!((actual - expected).abs() < 1.0e-5, "{actual} != {expected}");
                }
            }
        }
    }

    #[test]
    fn restored_authoritative_state_continues_rotational_and_linear_motion() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        for creation in [
            pendulum_creation(false),
            linear_test_creation(Vec3::Z, false),
        ] {
            let config = GpuPhysicsConfig {
                collisions_enabled: false,
                ..Default::default()
            };
            let original = GpuPhysics::new_with_config(&device, &queue, &creation, config).unwrap();
            original.enable_async_readback();
            original
                .initialize_mechanism_coordinates(
                    &queue,
                    &[crate::GpuMechanismCoordinate {
                        position: 0.1,
                        velocity: 0.3,
                    }],
                )
                .unwrap();
            original.dispatch_tick(&device, &queue, 1);
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let saved = original.poll_tick_readback(&device).unwrap().unwrap();
            assert_eq!(saved.diagnostics.error_flags, 0);
            let replacement =
                GpuPhysics::new_with_config(&device, &queue, &creation, config).unwrap();
            replacement.enable_async_readback();
            replacement
                .write_body_states(&queue, &saved.transforms, &saved.velocities)
                .unwrap();
            replacement
                .initialize_mechanism_coordinates(&queue, &saved.coordinates)
                .unwrap();
            original.dispatch_tick(&device, &queue, 2);
            replacement.dispatch_tick(&device, &queue, 2);
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let expected = original.poll_tick_readback(&device).unwrap().unwrap();
            let actual = replacement.poll_tick_readback(&device).unwrap().unwrap();
            assert_eq!(actual.diagnostics.error_flags, 0);
            for (actual, expected) in actual.transforms.iter().zip(&expected.transforms) {
                for (a, b) in actual
                    .position
                    .iter()
                    .chain(&actual.rotation)
                    .zip(expected.position.iter().chain(&expected.rotation))
                {
                    assert!((a - b).abs() < 1.0e-5, "restored pose diverged: {a} != {b}");
                }
            }
            for (actual, expected) in actual.velocities.iter().zip(&expected.velocities) {
                for (a, b) in actual
                    .linear
                    .iter()
                    .chain(&actual.angular)
                    .zip(expected.linear.iter().chain(&expected.angular))
                {
                    assert!(
                        (a - b).abs() < 1.0e-4,
                        "restored velocity diverged: {a} != {b}"
                    );
                }
            }
            for (actual, expected) in actual.coordinates.iter().zip(&expected.coordinates) {
                assert!((actual.position - expected.position).abs() < 1.0e-5);
                assert!((actual.velocity - expected.velocity).abs() < 1.0e-4);
            }
        }
    }

    #[test]
    fn authoritative_readback_supports_scenes_without_joints() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        graph
            .apply(BuildCommand::Spawn(
                CuboidSpec::new(
                    [1; 3],
                    BuildPose::new(IVec3::new(0, 80, 0), GridRotation::default()),
                )
                .unwrap(),
            ))
            .unwrap();
        let creation = graph.compile().unwrap();
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        gpu.enable_async_readback();
        for tick in 1..=3 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let mut previous_velocity = 0.0;
        for tick in 1..=3 {
            let state = gpu.poll_tick_readback(&device).unwrap().unwrap();
            assert_eq!(state.tick_index, tick);
            assert_eq!(state.diagnostics.error_flags, 0);
            assert!(state.coordinates.is_empty());
            assert_eq!(state.velocities.len(), 1);
            let velocity = state.velocities[0].linear[1];
            assert!(
                velocity < previous_velocity,
                "gravity must accelerate on each captured tick"
            );
            previous_velocity = velocity;
        }
    }

    #[test]
    fn off_centre_external_impulse_changes_linear_and_angular_motion() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        let spec = CuboidSpec::new(
            [4, 4, 4],
            BuildPose::new(IVec3::new(0, 8, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap() else {
            unreachable!()
        };
        let creation = graph.compile().unwrap();
        let body = creation.part_to_compound[0].1;
        let initial = creation.compounds[body as usize].root_translation;
        let properties = creation.compounds[body as usize].mass_properties;
        let arm = Vec3::Y * 0.5;
        let impulse = Vec3::X * properties.mass;
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        gpu.apply_impulse(&device, &queue, body, initial + arm, impulse)
            .unwrap();
        gpu.dispatch_tick(&device, &queue, 1);
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let snapshot = gpu.read_snapshot_transforms(&device, &queue, 1).unwrap();
        let expected_displacement = impulse.x / properties.mass * 0.999 * crate::FIXED_DT_SECONDS;
        assert!(
            (snapshot[body as usize].position[0] - initial.x - expected_displacement).abs()
                < 1.0e-5
        );
        let angular_velocity = properties.inverse_inertia * arm.cross(impulse) * 0.98;
        let half_spin = angular_velocity * (0.5 * crate::FIXED_DT_SECONDS);
        let expected_rotation =
            bevy_math::Quat::from_xyzw(half_spin.x, half_spin.y, half_spin.z, 1.0).normalize();
        assert!(
            bevy_math::Quat::from_array(snapshot[body as usize].rotation)
                .abs_diff_eq(expected_rotation, 1.0e-5)
        );
        assert_eq!(creation.part_to_compound[0].0, part);
    }

    #[test]
    fn external_impulse_batches_chunk_repeated_rows_and_validate_atomically() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        graph
            .apply(BuildCommand::Spawn(
                CuboidSpec::new(
                    [4, 4, 4],
                    BuildPose::new(IVec3::new(0, 8, 0), GridRotation::default()),
                )
                .unwrap(),
            ))
            .unwrap();
        let creation = graph.compile().unwrap();
        let initial = creation.compounds[0].root_translation;
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();

        let mut invalid =
            vec![GpuExternalImpulse::new(0, initial, Vec3::X); EXTERNAL_IMPULSE_BATCH_CAPACITY + 1];
        invalid[EXTERNAL_IMPULSE_BATCH_CAPACITY].metadata[0] = 1;
        assert_eq!(
            gpu.dispatch_tick_with_impulses(&device, &queue, 1, &invalid)
                .unwrap_err(),
            GpuImpulseError::BodyIndexOutOfRange {
                body_index: 1,
                body_count: 1,
            }
        );
        gpu.dispatch_tick(&device, &queue, 1);
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let unchanged = gpu.read_snapshot_transforms(&device, &queue, 1).unwrap();
        assert!((unchanged[0].position[0] - initial.x).abs() < 1.0e-6);

        let rows = vec![
            GpuExternalImpulse::new(0, initial, Vec3::X * 10.0);
            EXTERNAL_IMPULSE_BATCH_CAPACITY + 1
        ];
        gpu.dispatch_tick_with_impulses(&device, &queue, 2, &rows)
            .unwrap();
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let moved = gpu.read_snapshot_transforms(&device, &queue, 2).unwrap();
        assert!(moved[0].position[0] > initial.x);

        let non_finite = [GpuExternalImpulse::new(0, initial, Vec3::splat(f32::NAN))];
        assert_eq!(
            gpu.dispatch_tick_with_impulses(&device, &queue, 3, &non_finite)
                .unwrap_err(),
            GpuImpulseError::NonFinite
        );
        assert_eq!(
            gpu.apply_impulses(&device, &queue, &rows[..=EXTERNAL_IMPULSE_BATCH_CAPACITY],)
                .unwrap_err(),
            GpuImpulseError::BatchCapacity {
                provided: EXTERNAL_IMPULSE_BATCH_CAPACITY + 1,
                capacity: EXTERNAL_IMPULSE_BATCH_CAPACITY,
            }
        );
    }

    #[test]
    fn offset_ground_contact_applies_angular_impulse_about_compound_centre() {
        let mut graph = ConstructionGraph::new();
        let lower_spec = CuboidSpec::new(
            [2, 2, 2],
            BuildPose::new(IVec3::new(4, 1, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(lower) = graph.apply(BuildCommand::Spawn(lower_spec)).unwrap()
        else {
            unreachable!()
        };
        let upper_spec = CuboidSpec::new(
            [2, 2, 2],
            BuildPose::new(IVec3::new(-4, 9, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(upper) = graph.apply(BuildCommand::Spawn(upper_spec)).unwrap()
        else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::RigidLink(RigidLinkSpec {
                first: lower,
                second: upper,
            }))
            .unwrap();
        let creation = graph.compile().unwrap();
        assert!(creation.colliders[0].local_center.x.abs() > 0.5);
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        for tick in 1..=4 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let snapshot = gpu.read_snapshot_transforms(&device, &queue, 1).unwrap();
        let rotation = bevy_math::Quat::from_array(snapshot[0].rotation);
        assert!(
            rotation.z > 1.0e-4,
            "offset support acted through the compound centre: {rotation:?}"
        );
    }

    #[test]
    fn articulated_car_drop_settles_without_drift_or_ground_penetration() {
        let fixture = articulated_car_fixture();
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                mechanism_self_collisions: false,
                solver_iterations: 8,
                ..Default::default()
            },
        )
        .unwrap();
        let initial_chassis = fixture.creation.compounds[fixture.chassis as usize].root_translation;
        let mut previous_sample_tick = 0;
        let sample_ticks = (10..=300).step_by(10).chain((330..=1_200).step_by(30));
        for sample_tick in sample_ticks {
            for tick in previous_sample_tick + 1..=sample_tick {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            previous_sample_tick = sample_tick;
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let snapshot = gpu
                .read_snapshot_transforms(&device, &queue, (sample_tick % 3) as u8)
                .unwrap();
            let chassis_rotation =
                bevy_math::Quat::from_array(snapshot[fixture.chassis as usize].rotation);
            assert!(
                transform_position(snapshot[fixture.chassis as usize]).y >= 0.74,
                "chassis entered the ground at tick {sample_tick}"
            );
            assert!(
                (chassis_rotation * Vec3::Y).dot(Vec3::Y) > 0.9,
                "unpowered chassis tipped at tick {sample_tick}"
            );
            for &wheel in &fixture.wheel_bodies {
                let wheel_height = transform_position(snapshot[wheel as usize]).y;
                assert!(
                    wheel_height >= 0.495,
                    "wheel {wheel} entered the ground at tick {sample_tick}: y={wheel_height}"
                );
            }
        }

        let current = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let previous = gpu.read_snapshot_transforms(&device, &queue, 2).unwrap();
        let diagnostics = gpu.read_last_tick(&device).unwrap();
        assert_eq!(diagnostics.error_flags, 0);
        assert!(diagnostics.anchor_residual_meters <= mechanic_core::ANCHOR_TOLERANCE_METERS);
        assert!(diagnostics.axis_residual_degrees <= mechanic_core::AXIS_TOLERANCE_DEGREES);
        let chassis_position = transform_position(current[fixture.chassis as usize]);
        let horizontal_drift = Vec3::new(
            chassis_position.x - initial_chassis.x,
            0.0,
            chassis_position.z - initial_chassis.z,
        )
        .length();
        assert!(
            horizontal_drift < 0.05,
            "unpowered chassis drifted {horizontal_drift} m"
        );
        let max_linear_speed = fixture
            .dynamic_bodies
            .iter()
            .map(|&body| snapshot_speed(current[body as usize], previous[body as usize]))
            .fold(0.0_f32, f32::max);
        let max_bearing_speed = fixture
            .creation
            .bearings
            .iter()
            .map(|bearing| bearing_speed(&current, &previous, bearing))
            .fold(0.0_f32, f32::max);
        assert!(
            max_linear_speed < 0.02,
            "linear speed was {max_linear_speed}"
        );
        assert!(
            max_bearing_speed < 0.02,
            "bearing angular speed was {max_bearing_speed}"
        );
    }

    #[test]
    fn curved_suspension_car_lands_without_contact_correction_launch() {
        let fixture = pipe_bend_suspension_car_fixture();
        let ground_data = full_cylinder_ground_data(&fixture.creation.colliders);
        assert_eq!(
            ground_data
                .iter()
                .filter(|data| data.role == FULL_CYLINDER_GROUND_FIRST)
                .count(),
            4
        );
        assert_eq!(fixture.creation.bearings.len(), 8);
        assert_eq!(fixture.dynamic_bodies.len(), 9);
        assert!(
            fixture
                .creation
                .compounds
                .iter()
                .any(|compound| compound.collider_range.len() >= 192)
        );
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                mechanism_self_collisions: false,
                ..Default::default()
            },
        )
        .unwrap();
        let initial_chassis = fixture.creation.compounds[fixture.chassis as usize].root_translation;
        let mut maximum_chassis_height = initial_chassis.y;
        let mut minimum_wheel_height = f32::INFINITY;
        for tick in 1..=1_200 {
            gpu.dispatch_tick(&device, &queue, tick);
            if tick.is_multiple_of(30) {
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let snapshot = gpu
                    .read_snapshot_transforms(&device, &queue, (tick % 3) as u8)
                    .unwrap();
                maximum_chassis_height = maximum_chassis_height
                    .max(transform_position(snapshot[fixture.chassis as usize]).y);
                minimum_wheel_height = fixture
                    .wheel_bodies
                    .iter()
                    .map(|&wheel| transform_position(snapshot[wheel as usize]).y)
                    .fold(minimum_wheel_height, f32::min);
            }
        }

        let diagnostics = gpu.read_last_tick(&device).unwrap();
        let final_snapshot = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let final_wheel_height = fixture
            .wheel_bodies
            .iter()
            .map(|&wheel| transform_position(final_snapshot[wheel as usize]).y)
            .fold(f32::INFINITY, f32::min);
        assert_eq!(diagnostics.error_flags, 0);
        assert_eq!(diagnostics.planned_solver_sweeps, 8);
        assert_eq!(diagnostics.executed_solver_sweeps, 8);
        assert!(
            maximum_chassis_height < initial_chassis.y + 0.5,
            "ground correction launched the chassis from {} m to {maximum_chassis_height} m",
            initial_chassis.y,
        );
        assert!(
            minimum_wheel_height >= 0.39,
            "a wheel sank through the ground to {minimum_wheel_height} m"
        );
        assert!(
            final_wheel_height >= 0.44,
            "a wheel remained below the ground at {final_wheel_height} m"
        );
    }

    #[test]
    fn steering_servos_reach_angle_without_overshooting() {
        let fixture = pipe_bend_suspension_car_fixture();
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                mechanism_self_collisions: false,
                ..Default::default()
            },
        )
        .unwrap();
        for tick in 1..=240 {
            gpu.dispatch_tick(&device, &queue, tick);
        }

        let target = std::f32::consts::FRAC_PI_6;
        let mut drives = fixture
            .creation
            .coordinate_drives
            .iter()
            .copied()
            .map(crate::GpuMechanismDrive::from)
            .collect::<Vec<_>>();
        for drive in &mut drives[..4] {
            drive.target_angle = target;
        }
        gpu.write_mechanism_drives(&queue, &drives).unwrap();

        let bearing_angle = |snapshot: &[crate::GpuTransform], coordinate: usize| {
            let source_bearing = fixture.creation.loop_topology.tree_bearings[coordinate];
            let bearing = fixture
                .creation
                .bearings
                .iter()
                .find(|bearing| bearing.source_bearing == source_bearing)
                .unwrap();
            let relative = relative_bearing_rotation(snapshot, bearing);
            2.0 * relative
                .xyz()
                .dot(bearing.local_axis_a.normalize())
                .atan2(relative.w)
        };
        let mut maximum_angles = [f32::NEG_INFINITY; 4];
        let mut final_angles = [0.0; 4];
        let mut previous_tick = 240;
        for sample_tick in 241..=480 {
            for tick in previous_tick + 1..=sample_tick {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            previous_tick = sample_tick;
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let snapshot = gpu
                .read_snapshot_transforms(&device, &queue, (sample_tick % 3) as u8)
                .unwrap();
            for coordinate in 0..4 {
                let angle = bearing_angle(&snapshot, coordinate);
                maximum_angles[coordinate] = maximum_angles[coordinate].max(angle);
                final_angles[coordinate] = angle;
            }
        }

        let tolerance = 0.15_f32.to_radians();
        for coordinate in 0..4 {
            assert!(
                maximum_angles[coordinate] <= target + tolerance,
                "steering coordinate {coordinate} overshot 30 degrees to {} degrees",
                maximum_angles[coordinate].to_degrees(),
            );
            assert!(
                (final_angles[coordinate] - target).abs() <= tolerance,
                "steering coordinate {coordinate} settled at {} degrees",
                final_angles[coordinate].to_degrees(),
            );
        }
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
    }

    #[test]
    #[allow(clippy::too_many_lines)]
    fn production_servos_hold_steering_under_first_gear_gas_drive() {
        const FIRST_GEAR_RATIO: f32 = 3.0;
        const COMMAND_SPEED: f32 = std::f32::consts::TAU * 6.0;
        const STEERING_COORDINATES: usize = 4;
        const HOLD_TOLERANCE: f32 = std::f32::consts::PI / 180.0;

        let mut fixture = pipe_bend_suspension_car_fixture_with_steering_torque(
            ServoSpec::STALL_TORQUE_NEWTON_METERS,
        );
        assert_eq!(fixture.creation.coordinate_drives.len(), 8);
        for coordinate in 0..STEERING_COORDINATES {
            let inertia = fixture.creation.loop_topology.coordinate_axis_inertia[coordinate];
            let compiled_torque =
                fixture.creation.coordinate_drives[coordinate].source_a_max_acceleration * inertia;
            assert!((compiled_torque - ServoSpec::STALL_TORQUE_NEWTON_METERS).abs() < 0.01);
        }
        for coordinate in STEERING_COORDINATES..fixture.creation.coordinate_drives.len() {
            let source_bearing = fixture.creation.loop_topology.tree_bearings[coordinate];
            let bearing = fixture
                .creation
                .bearings
                .iter()
                .find(|bearing| bearing.source_bearing == source_bearing)
                .unwrap();
            let world_axis = fixture.creation.compounds[bearing.compound_a as usize].root_rotation
                * bearing.local_axis_a;
            let inertia = fixture.creation.loop_topology.coordinate_axis_inertia[coordinate];
            let acceleration =
                EngineKind::Gas.stall_torque_newton_meters() * FIRST_GEAR_RATIO / 4.0 / inertia;
            fixture.creation.coordinate_drives[coordinate] = CoordinateDrive {
                mode: DriveMode::Speed,
                target_speed: 0.0,
                target_angle: 0.0,
                max_speed: EngineKind::Gas.no_load_rpm() * std::f32::consts::TAU
                    / 60.0
                    / FIRST_GEAR_RATIO,
                max_acceleration: acceleration,
                source_a_max_acceleration: 0.0,
                source_a_no_load_speed: 0.0,
                source_b_max_acceleration: acceleration,
                source_b_no_load_speed: EngineKind::Gas.no_load_rpm() * std::f32::consts::TAU
                    / 60.0
                    / FIRST_GEAR_RATIO,
                min_angle: f32::NEG_INFINITY,
                max_angle: f32::INFINITY,
            };
            assert!(world_axis.cross(Vec3::Y).dot(Vec3::X).abs() > 0.99);
        }

        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                mechanism_self_collisions: false,
                ..Default::default()
            },
        )
        .unwrap();
        for tick in 1..=240 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let settled = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let starting_position = transform_position(settled[fixture.chassis as usize]);
        let mut drives = fixture
            .creation
            .coordinate_drives
            .iter()
            .copied()
            .map(crate::GpuMechanismDrive::from)
            .collect::<Vec<_>>();
        for (coordinate, drive) in drives.iter_mut().enumerate().skip(STEERING_COORDINATES) {
            let source_bearing = fixture.creation.loop_topology.tree_bearings[coordinate];
            let bearing = fixture
                .creation
                .bearings
                .iter()
                .find(|bearing| bearing.source_bearing == source_bearing)
                .unwrap();
            let world_axis = fixture.creation.compounds[bearing.compound_a as usize].root_rotation
                * bearing.local_axis_a;
            drive.target_speed = world_axis.cross(Vec3::Y).dot(Vec3::X).signum() * COMMAND_SPEED;
        }
        gpu.write_mechanism_drives(&queue, &drives).unwrap();
        let bearing_angle = |snapshot: &[crate::GpuTransform], coordinate: usize| {
            let source_bearing = fixture.creation.loop_topology.tree_bearings[coordinate];
            let bearing = fixture
                .creation
                .bearings
                .iter()
                .find(|bearing| bearing.source_bearing == source_bearing)
                .unwrap();
            let relative = relative_bearing_rotation(snapshot, bearing);
            2.0 * relative
                .xyz()
                .dot(bearing.local_axis_a.normalize())
                .atan2(relative.w)
        };

        let mut maximum_center_error = 0.0_f32;
        let mut maximum_horizontal_travel = 0.0_f32;
        for sample_tick in (243..=600).step_by(3) {
            for tick in sample_tick - 2..=sample_tick {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let snapshot = gpu
                .read_snapshot_transforms(&device, &queue, (sample_tick % 3) as u8)
                .unwrap();
            let displacement =
                transform_position(snapshot[fixture.chassis as usize]) - starting_position;
            maximum_horizontal_travel = maximum_horizontal_travel
                .max(Vec3::new(displacement.x, 0.0, displacement.z).length());
            for coordinate in 0..STEERING_COORDINATES {
                maximum_center_error =
                    maximum_center_error.max(bearing_angle(&snapshot, coordinate).abs());
            }
        }
        assert!(
            maximum_horizontal_travel > 1.0,
            "first-gear drive moved the chassis only {maximum_horizontal_travel} m",
        );
        assert!(
            maximum_center_error <= HOLD_TOLERANCE,
            "full first-gear drive deflected centred steering by {} degrees",
            maximum_center_error.to_degrees(),
        );

        let target = std::f32::consts::FRAC_PI_6;
        for drive in &mut drives[..STEERING_COORDINATES] {
            drive.target_angle = target;
        }
        gpu.write_mechanism_drives(&queue, &drives).unwrap();
        let mut maximum_settled_error = 0.0_f32;
        let mut final_angles = [0.0; STEERING_COORDINATES];
        for sample_tick in (603..=1_080).step_by(3) {
            for tick in sample_tick - 2..=sample_tick {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let snapshot = gpu
                .read_snapshot_transforms(&device, &queue, (sample_tick % 3) as u8)
                .unwrap();
            for (coordinate, final_angle) in final_angles.iter_mut().enumerate() {
                let angle = bearing_angle(&snapshot, coordinate);
                *final_angle = angle;
                if sample_tick >= 960 {
                    maximum_settled_error = maximum_settled_error.max((angle - target).abs());
                }
            }
        }
        for (coordinate, angle) in final_angles.into_iter().enumerate() {
            assert!(
                (angle - target).abs() <= HOLD_TOLERANCE,
                "steering coordinate {coordinate} reached {} instead of 30 degrees under drive",
                angle.to_degrees(),
            );
        }
        assert!(
            maximum_settled_error <= HOLD_TOLERANCE,
            "powered steering wandered by {} degrees after settling",
            maximum_settled_error.to_degrees(),
        );
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
    }

    #[test]
    #[allow(clippy::too_many_lines)]
    fn front_steered_car_turns_through_ground_friction() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let fixture = pipe_bend_car_fixture(ServoSpec::STALL_TORQUE_NEWTON_METERS, true);
        let pipelines = super::GpuPhysicsPipelines::new();
        let mut turns = Vec::new();
        for target in [-30.0_f32, 0.0, 30.0] {
            let gpu = GpuPhysics::new_with_pipelines(
                &device,
                &queue,
                &fixture.creation,
                GpuPhysicsConfig {
                    mechanism_self_collisions: false,
                    ..Default::default()
                },
                &pipelines,
            )
            .unwrap();
            for tick in 1..=240 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let start = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
            let chassis = fixture.chassis as usize;
            let initial = transform_position(start[chassis]);
            let initial_rotation = bevy_math::Quat::from_array(start[chassis].rotation);
            let mut drives = fixture
                .creation
                .coordinate_drives
                .iter()
                .copied()
                .map(crate::GpuMechanismDrive::from)
                .collect::<Vec<_>>();
            for drive in &mut drives[..2] {
                drive.target_angle = target.to_radians();
            }
            for bearing in &fixture.creation.bearings {
                let coordinate = bearing.coordinate_index.unwrap() as usize;
                if coordinate < 2 {
                    continue;
                }
                let acceleration =
                    1_000.0 / fixture.creation.loop_topology.coordinate_axis_inertia[coordinate];
                drives[coordinate] = crate::GpuMechanismDrive::from(CoordinateDrive {
                    mode: DriveMode::Speed,
                    target_speed: bearing.local_axis_a.cross(Vec3::Y).dot(Vec3::X).signum() * 3.0,
                    max_speed: 3.0,
                    max_acceleration: acceleration,
                    source_b_max_acceleration: acceleration,
                    source_b_no_load_speed: 30.0,
                    ..CoordinateDrive::default()
                });
            }
            gpu.write_mechanism_drives(&queue, &drives).unwrap();
            for tick in 241..=600 {
                gpu.dispatch_tick(&device, &queue, tick);
                if tick % 30 == 0 {
                    let sample = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
                    let up = bevy_math::Quat::from_array(sample[chassis].rotation) * Vec3::Y;
                    assert!(up.y > 0.98, "car tipped at tick {tick}: {up:?}");
                    let height_change = transform_position(sample[chassis]).y - initial.y;
                    assert!(
                        height_change.abs() < 0.15,
                        "car bounced at tick {tick}: {height_change}"
                    );
                    for &wheel in &fixture.wheel_bodies {
                        assert!(
                            sample[wheel as usize].position[1] > 0.44,
                            "wheel sank at tick {tick}"
                        );
                    }
                }
            }
            let end = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
            let forward = initial_rotation.conjugate()
                * bevy_math::Quat::from_array(end[chassis].rotation)
                * Vec3::X;
            let yaw = (-forward.z).atan2(forward.x).to_degrees();
            let displacement =
                initial_rotation.conjugate() * (transform_position(end[chassis]) - initial);
            eprintln!("steer={target} yaw={yaw} displacement={displacement:?}");
            for bearing in &fixture.creation.bearings[..2] {
                let relative = relative_bearing_rotation(&end, bearing);
                let angle =
                    (2.0 * relative.xyz().dot(bearing.local_axis_a).atan2(relative.w)).to_degrees();
                eprintln!("steering angle={angle}");
                assert!(
                    (angle - target).abs() < 3.0,
                    "steering deflected: target {target}, actual {angle}"
                );
            }
            assert!(
                displacement.x > 3.0,
                "car did not drive forward: {displacement:?}"
            );
            assert!(
                forward.y.abs() < 0.1,
                "car tipped while steering: {forward:?}"
            );
            assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
            turns.push((yaw, displacement.z));
        }
        assert!(
            turns[0].0 > 20.0 && turns[0].1 < -1.0,
            "left command did not turn: {turns:?}"
        );
        assert!(
            turns[2].0 < -20.0 && turns[2].1 > 1.0,
            "right command did not turn: {turns:?}"
        );
        assert!(
            turns[1].0.abs() < 2.0 && turns[1].1.abs() < 0.2,
            "straight command drifted: {turns:?}"
        );
        assert!(
            (turns[0].0 + turns[2].0).abs() < 5.0,
            "turns were asymmetric: {turns:?}"
        );
    }

    include!("steering_tests.rs");

    #[test]
    #[allow(clippy::too_many_lines)]
    fn sustained_gas_drive_stays_forward_with_bounded_longitudinal_slip() {
        const COMMAND_SPEED: f32 = std::f32::consts::TAU * 6.0;
        const WHEEL_RADIUS: f32 = 0.475;
        const SAMPLE_TICKS: u64 = 3;
        const SAMPLE_SECONDS: f32 = 0.05;
        const DRIVE_END_TICK: u64 = 3_600;
        const REVERSE_TICKS: u64 = 720;
        const REVERSE_SECONDS: f32 = 12.0;

        let fixture = rigid_axle_car_fixture();
        let mass = fixture
            .dynamic_bodies
            .iter()
            .map(|&body| {
                fixture.creation.compounds[body as usize]
                    .mass_properties
                    .mass
            })
            .sum::<f32>();
        assert!(
            (11_000.0..=12_500.0).contains(&mass),
            "fixture mass was {mass} kg"
        );
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                mechanism_self_collisions: false,
                ..Default::default()
            },
        )
        .unwrap();
        for tick in 1..=240 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let gearbox = GearboxConfig::for_depth(2, true);
        assert_eq!(gearbox.ratios(), [4.0, 3.0, 1.0]);
        let rolling_sign = |bearing: &mechanic_core::CompiledBearing| {
            let world_axis = fixture.creation.compounds[bearing.compound_a as usize].root_rotation
                * bearing.local_axis_a;
            world_axis.cross(Vec3::Y).dot(Vec3::X).signum()
        };
        let make_drives = |ratio: f32, command_speed: f32| {
            let output_speed = EngineKind::Gas.no_load_rpm() * std::f32::consts::TAU / 60.0 / ratio;
            let mut drives = fixture
                .creation
                .coordinate_drives
                .iter()
                .copied()
                .map(crate::GpuMechanismDrive::from)
                .collect::<Vec<_>>();
            for (coordinate, drive) in drives.iter_mut().enumerate() {
                let source_bearing = fixture.creation.loop_topology.tree_bearings[coordinate];
                let bearing = fixture
                    .creation
                    .bearings
                    .iter()
                    .find(|bearing| bearing.source_bearing == source_bearing)
                    .unwrap();
                let acceleration = EngineKind::Gas.stall_torque_newton_meters() * ratio
                    / 4.0
                    / fixture.creation.loop_topology.coordinate_axis_inertia[coordinate];
                *drive = crate::GpuMechanismDrive::from(CoordinateDrive {
                    mode: DriveMode::Speed,
                    target_speed: rolling_sign(bearing) * command_speed,
                    target_angle: 0.0,
                    max_speed: output_speed,
                    max_acceleration: acceleration,
                    source_a_max_acceleration: 0.0,
                    source_a_no_load_speed: 0.0,
                    source_b_max_acceleration: acceleration,
                    source_b_no_load_speed: output_speed,
                    min_angle: f32::NEG_INFINITY,
                    max_angle: f32::INFINITY,
                });
            }
            drives
        };

        let mut ratio = gearbox.ratios()[usize::from(gearbox.reverse_gears())];
        let mut drives = make_drives(ratio, COMMAND_SPEED);
        gpu.write_mechanism_drives(&queue, &drives).unwrap();

        let mut previous = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let initial_x = transform_position(previous[fixture.chassis as usize]).x;
        let mut furthest_x = initial_x;
        let mut maximum_speed = 0.0_f32;
        let mut maximum_speed_tick = 0_u64;
        let mut speed_at_twelve_seconds = 0.0_f32;
        let mut shifted = false;
        let mut maximum_engine_rpm = 0.0_f32;
        let mut slips = Vec::new();
        for sample_tick in (240 + SAMPLE_TICKS..=DRIVE_END_TICK).step_by(3) {
            for tick in sample_tick - SAMPLE_TICKS + 1..=sample_tick {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            let current = gpu
                .read_snapshot_transforms(&device, &queue, (sample_tick % 3) as u8)
                .unwrap();
            let current_x = transform_position(current[fixture.chassis as usize]).x;
            let previous_x = transform_position(previous[fixture.chassis as usize]).x;
            let chassis_speed = (current_x - previous_x) / SAMPLE_SECONDS;
            let wheel_surface_speed = fixture
                .creation
                .bearings
                .iter()
                .map(|bearing| {
                    let angular_velocity = |body: u32| {
                        let current_rotation =
                            bevy_math::Quat::from_array(current[body as usize].rotation);
                        let previous_rotation =
                            bevy_math::Quat::from_array(previous[body as usize].rotation);
                        let mut delta = current_rotation * previous_rotation.conjugate();
                        if delta.w < 0.0 {
                            delta = -delta;
                        }
                        let vector = delta.xyz();
                        if vector.length_squared() <= 1.0e-12 {
                            Vec3::ZERO
                        } else {
                            vector.normalize()
                                * (2.0 * vector.length().atan2(delta.w) / SAMPLE_SECONDS)
                        }
                    };
                    let parent_rotation =
                        bevy_math::Quat::from_array(current[bearing.compound_a as usize].rotation);
                    let axis = parent_rotation * bearing.local_axis_a.normalize();
                    let relative_angular =
                        angular_velocity(bearing.compound_b) - angular_velocity(bearing.compound_a);
                    relative_angular.dot(axis) * axis.cross(Vec3::Y).dot(Vec3::X) * WHEEL_RADIUS
                })
                .sum::<f32>()
                / 4.0;

            furthest_x = furthest_x.max(current_x);
            assert!(
                current_x >= furthest_x - 0.05,
                "forward displacement reversed by {} m at tick {sample_tick}",
                furthest_x - current_x,
            );
            assert!(
                chassis_speed >= -0.05,
                "chassis reversed at {chassis_speed} m/s on tick {sample_tick}",
            );
            if chassis_speed > maximum_speed {
                maximum_speed = chassis_speed;
                maximum_speed_tick = sample_tick;
            }
            if sample_tick == 960 {
                speed_at_twelve_seconds = chassis_speed;
            }
            if chassis_speed > 0.5 {
                let slip = (wheel_surface_speed - chassis_speed).abs()
                    / wheel_surface_speed.abs().max(chassis_speed.abs()).max(0.5);
                slips.push(slip);
            }
            if !shifted {
                let engine_rpm =
                    wheel_surface_speed.abs() / WHEEL_RADIUS * ratio * 60.0 / std::f32::consts::TAU;
                maximum_engine_rpm = maximum_engine_rpm.max(engine_rpm);
                if engine_rpm >= 0.75 * EngineKind::Gas.no_load_rpm() {
                    ratio = 1.0;
                    drives = make_drives(ratio, COMMAND_SPEED);
                    gpu.write_mechanism_drives(&queue, &drives).unwrap();
                    shifted = true;
                }
            }
            previous = current;
        }

        slips.sort_by(f32::total_cmp);
        let p95_slip = slips[(slips.len() * 95 / 100).min(slips.len() - 1)];
        let geared_ceiling = COMMAND_SPEED * WHEEL_RADIUS;
        assert!(
            shifted,
            "automatic first-to-second shift was never reached; peak engine speed {maximum_engine_rpm} RPM, chassis {maximum_speed} m/s"
        );
        assert!(
            speed_at_twelve_seconds >= 8.33,
            "vehicle reached only {speed_at_twelve_seconds} m/s after 12 seconds; peak {maximum_speed}, p95 slip {p95_slip}",
        );
        assert!(
            maximum_speed >= 13.9,
            "vehicle peaked at only {maximum_speed} m/s during sustained drive",
        );
        assert!(
            maximum_speed <= geared_ceiling + 0.25,
            "vehicle exceeded the geared no-load ceiling at tick {maximum_speed_tick}: {maximum_speed} > {geared_ceiling}; 12-second speed {speed_at_twelve_seconds}, p95 slip {p95_slip}",
        );
        assert!(
            p95_slip < 0.10,
            "p95 longitudinal slip was {:.1}%",
            p95_slip * 100.0
        );

        let coast_start = previous;
        for drive in &mut drives {
            drive.target_speed = 0.0;
            drive.max_acceleration = 0.0;
            drive.max_speed = 0.0;
            drive.source_b_max_acceleration = 0.0;
            drive.source_b_no_load_speed = 0.0;
        }
        gpu.write_mechanism_drives(&queue, &drives).unwrap();
        for tick in DRIVE_END_TICK + 1..=DRIVE_END_TICK + 120 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let coast_end = gpu
            .read_snapshot_transforms(&device, &queue, ((DRIVE_END_TICK + 120) % 3) as u8)
            .unwrap();
        let coast_speed = (transform_position(coast_end[fixture.chassis as usize]).x
            - transform_position(coast_start[fixture.chassis as usize]).x)
            / 2.0;
        assert!(
            coast_speed > 1.0,
            "neutral actively stopped the vehicle: {coast_speed} m/s"
        );

        let reverse = make_drives(gearbox.ratios()[0], -COMMAND_SPEED);
        gpu.write_mechanism_drives(&queue, &reverse).unwrap();
        for tick in DRIVE_END_TICK + 121..=DRIVE_END_TICK + 120 + REVERSE_TICKS {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let reverse_end = gpu
            .read_snapshot_transforms(
                &device,
                &queue,
                ((DRIVE_END_TICK + 120 + REVERSE_TICKS) % 3) as u8,
            )
            .unwrap();
        let reverse_speed = (transform_position(reverse_end[fixture.chassis as usize]).x
            - transform_position(coast_end[fixture.chassis as usize]).x)
            / REVERSE_SECONDS;
        assert!(
            reverse_speed < -0.05,
            "explicit reverse did not reverse: {reverse_speed} m/s"
        );
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
    }

    #[test]
    fn struck_articulated_wheel_recovers_without_crossing_ground() {
        let fixture = articulated_car_fixture();
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                mechanism_self_collisions: false,
                ..Default::default()
            },
        )
        .unwrap();
        for tick in 1..=300 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let settled = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let wheel = fixture.wheel_bodies[0];
        let wheel_position = transform_position(settled[wheel as usize]);
        let wheel_mass = fixture.creation.compounds[wheel as usize]
            .mass_properties
            .mass;
        gpu.apply_impulse(
            &device,
            &queue,
            wheel,
            wheel_position,
            Vec3::NEG_Y * wheel_mass * 3.0,
        )
        .unwrap();

        let mut minimum_height = f32::INFINITY;
        let mut previous_sample_tick = 300;
        let sample_ticks = (301..=360).chain((370..=900).step_by(10));
        for sample_tick in sample_ticks {
            for tick in previous_sample_tick + 1..=sample_tick {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            previous_sample_tick = sample_tick;
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let snapshot = gpu
                .read_snapshot_transforms(&device, &queue, (sample_tick % 3) as u8)
                .unwrap();
            minimum_height = minimum_height.min(transform_position(snapshot[wheel as usize]).y);
        }
        let final_snapshot = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let final_height = transform_position(final_snapshot[wheel as usize]).y;
        let chassis_rotation =
            bevy_math::Quat::from_array(final_snapshot[fixture.chassis as usize].rotation);
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
        assert!(
            minimum_height >= 0.44,
            "struck wheel crossed too far into the ground: {minimum_height} m"
        );
        assert!(
            final_height >= 0.495,
            "struck wheel remained in the ground at {final_height} m"
        );
        assert!((chassis_rotation * Vec3::Y).dot(Vec3::Y) > 0.9);
    }

    #[test]
    fn articulated_car_wall_impact_remains_bounded_and_decays() {
        let fixture = articulated_car_fixture();
        let Some((device, queue)) = test_device() else {
            return;
        };
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                mechanism_self_collisions: false,
                ..Default::default()
            },
        )
        .unwrap();
        let chassis_position =
            fixture.creation.compounds[fixture.chassis as usize].root_translation;
        let chassis_mass = fixture.creation.compounds[fixture.chassis as usize]
            .mass_properties
            .mass;
        gpu.apply_impulse(
            &device,
            &queue,
            fixture.chassis,
            chassis_position,
            Vec3::NEG_Z * chassis_mass * 0.35,
        )
        .unwrap();

        let mut maximum_sampled_speed = 0.0_f32;
        let mut maximum_sampled_bearing_speed = 0.0_f32;
        for sample_tick in (30..=1_200).step_by(30) {
            for tick in sample_tick - 29..=sample_tick {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            let current = gpu
                .read_snapshot_transforms(&device, &queue, (sample_tick % 3) as u8)
                .unwrap();
            let previous = gpu
                .read_snapshot_transforms(&device, &queue, ((sample_tick - 1) % 3) as u8)
                .unwrap();
            for &body in &fixture.dynamic_bodies {
                let position = transform_position(current[body as usize]);
                assert!(position.is_finite(), "body {body} became non-finite");
                maximum_sampled_speed = maximum_sampled_speed.max(snapshot_speed(
                    current[body as usize],
                    previous[body as usize],
                ));
            }
            for bearing in &fixture.creation.bearings {
                maximum_sampled_bearing_speed =
                    maximum_sampled_bearing_speed.max(bearing_speed(&current, &previous, bearing));
            }
            assert!(
                transform_position(current[fixture.chassis as usize]).y >= 0.74,
                "chassis entered the ground at tick {sample_tick}"
            );
            for &wheel in &fixture.wheel_bodies {
                assert!(
                    transform_position(current[wheel as usize]).y >= 0.49,
                    "wheel {wheel} entered the ground at tick {sample_tick}"
                );
            }
        }

        let current = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap();
        let previous = gpu.read_snapshot_transforms(&device, &queue, 2).unwrap();
        let diagnostics = gpu.read_last_tick(&device).unwrap();
        assert_eq!(diagnostics.error_flags, 0);
        assert!(diagnostics.anchor_residual_meters <= mechanic_core::ANCHOR_TOLERANCE_METERS);
        assert!(diagnostics.axis_residual_degrees <= mechanic_core::AXIS_TOLERANCE_DEGREES);
        assert!(
            maximum_sampled_speed < 2.0,
            "wall impact accelerated the car to {maximum_sampled_speed} m/s"
        );
        assert!(
            maximum_sampled_bearing_speed < 10.0,
            "wall impact accelerated a bearing to {maximum_sampled_bearing_speed} rad/s"
        );
        let final_speed = fixture
            .dynamic_bodies
            .iter()
            .map(|&body| snapshot_speed(current[body as usize], previous[body as usize]))
            .fold(0.0_f32, f32::max);
        let final_bearing_speed = fixture
            .creation
            .bearings
            .iter()
            .map(|bearing| bearing_speed(&current, &previous, bearing))
            .fold(0.0_f32, f32::max);
        assert!(
            final_speed < 0.02,
            "wall-impact motion did not decay: final speed {final_speed} m/s"
        );
        assert!(
            final_bearing_speed < 0.02,
            "wall-impact bearing motion did not decay: final speed {final_bearing_speed} rad/s"
        );
    }

    #[test]
    fn external_impulse_drives_a_bearing_coordinate() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let creation = pendulum_creation(true);
        let child = creation.bearings[0].compound_b;
        let run = |impulse: Option<Vec3>| {
            let gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    collisions_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            if let Some(impulse) = impulse {
                gpu.apply_impulse(
                    &device,
                    &queue,
                    child,
                    creation.compounds[child as usize].root_translation,
                    impulse,
                )
                .unwrap();
            }
            for tick in 1..=10 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            gpu.read_snapshot_transforms(&device, &queue, 1).unwrap()[child as usize]
        };
        let baseline = run(None);
        let struck = run(Some(Vec3::NEG_Y * 2_000.0));
        let baseline_rotation = bevy_math::Quat::from_array(baseline.rotation);
        let struck_rotation = bevy_math::Quat::from_array(struck.rotation);
        let difference = baseline_rotation.angle_between(struck_rotation);
        assert!(
            difference > 0.01,
            "external impulse changed rotation by only {difference} rad: baseline={baseline_rotation:?}, struck={struck_rotation:?}"
        );
    }

    fn run_ticks(
        creation: &mechanic_core::CompiledCreation,
        ticks: u64,
        collisions_enabled: bool,
    ) -> Option<(Vec<crate::GpuTransform>, crate::GpuTickReadback)> {
        let (device, queue) = test_device()?;
        let gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            creation,
            GpuPhysicsConfig {
                collisions_enabled,
                ground_plane_enabled: true,
                mechanism_self_collisions: true,
                solver_iterations: 16,
            },
        )
        .ok()?;
        for tick in 1..=ticks {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).ok()?;
        let readback = gpu.read_last_tick(&device).ok()?;
        let snapshot = gpu
            .read_snapshot_transforms(&device, &queue, (ticks % 3) as u8)
            .ok()?;
        Some((snapshot, readback))
    }

    #[test]
    fn terrain_triangles_contact_cuboids_convex_parts_and_cylinders_on_slopes_and_walls() {
        let (device, queue) =
            test_device().expect("terrain collider regression requires an adapter");
        let mut cylinder = ConstructionGraph::new();
        cylinder
            .apply(BuildCommand::SpawnCylinder(CylinderSpec::new(
                CylinderDimensions::new(1.0, 0.0, 1.0).unwrap(),
                BuildPose::from_half_grid(IVec3::new(0, 3, 0), GridRotation::default()),
            )))
            .unwrap();
        let shapes = [
            material_cube(ConstructionMaterial::Steel, 3),
            shaped_wedge(3),
            cylinder.compile().unwrap(),
        ];
        for (shape, creation) in shapes.iter().enumerate() {
            for angle in [
                0.0,
                std::f32::consts::FRAC_PI_4,
                std::f32::consts::FRAC_PI_2,
            ] {
                let mut terrain = super::terrain::tests::chunk();
                let rotation = bevy_math::Quat::from_rotation_z(angle);
                for vertex in &mut terrain.vertices {
                    *vertex = (rotation * Vec3::from_array(*vertex)).to_array();
                }
                let mut gpu = GpuPhysics::new_with_config(
                    &device,
                    &queue,
                    creation,
                    GpuPhysicsConfig {
                        ground_plane_enabled: false,
                        ..Default::default()
                    },
                )
                .unwrap();
                gpu.write_terrain_chunks(&device, &queue, [&terrain], bevy_math::DVec3::ZERO)
                    .unwrap();
                gpu.dispatch_tick(&device, &queue, 1);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let readback = gpu.read_last_tick(&device).unwrap();
                assert_eq!(readback.error_flags, 0, "shape {shape}, angle {angle}");
                assert!(
                    readback.active_contact_count > 0,
                    "shape {shape}, angle {angle}: {readback:?}"
                );
            }
        }
    }

    #[test]
    fn terrain_contacts_enter_the_fused_articulated_solver() {
        let (device, queue) =
            test_device().expect("terrain articulated regression requires an adapter");
        let fixture = articulated_car_fixture();
        let mut gpu = GpuPhysics::new_with_config(
            &device,
            &queue,
            &fixture.creation,
            GpuPhysicsConfig {
                ground_plane_enabled: false,
                mechanism_self_collisions: false,
                ..Default::default()
            },
        )
        .unwrap();
        assert_eq!(
            gpu.solver_route(),
            super::GpuSolverRoute::FusedSmallMechanism
        );
        let mut terrain = super::terrain::tests::chunk();
        terrain.origin = mechanic_world::WorldPosition(bevy_math::DVec3::Y * 0.3);
        gpu.write_terrain_chunks(&device, &queue, [&terrain], bevy_math::DVec3::ZERO)
            .unwrap();
        gpu.dispatch_tick(&device, &queue, 1);
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let readback = gpu.read_last_tick(&device).unwrap();
        assert_eq!(readback.error_flags, 0, "{readback:?}");
        assert!(readback.active_contact_count > 0, "{readback:?}");
        assert!(readback.executed_solver_sweeps > 0, "{readback:?}");
    }

    #[test]
    fn rigid_terrain_impact_bounds_hold_for_convex_parts_and_cylinders() {
        let (device, queue) = test_device().expect("terrain impact regression requires an adapter");
        let mut cylinder = ConstructionGraph::new();
        cylinder
            .apply(BuildCommand::SpawnCylinder(CylinderSpec::new(
                CylinderDimensions::new(1.0, 0.0, 1.0).unwrap(),
                BuildPose::from_half_grid(IVec3::new(0, 5, 0), GridRotation::default()),
            )))
            .unwrap();
        for (shape, mut creation) in [shaped_wedge(5), cylinder.compile().unwrap()]
            .into_iter()
            .enumerate()
        {
            for collider in &mut creation.colliders {
                collider.material_properties.restitution = 0.0;
                collider.material_properties.youngs_modulus_pa = 200.0e9;
            }
            for speed in [1.0, 5.0, 20.0] {
                let mut gpu = GpuPhysics::new_with_config(
                    &device,
                    &queue,
                    &creation,
                    GpuPhysicsConfig {
                        ground_plane_enabled: false,
                        ..Default::default()
                    },
                )
                .unwrap();
                gpu.write_terrain_chunks(
                    &device,
                    &queue,
                    [&super::terrain::tests::rigid_chunk()],
                    bevy_math::DVec3::ZERO,
                )
                .unwrap();
                gpu.enable_async_readback();
                gpu.apply_impulse(
                    &device,
                    &queue,
                    0,
                    creation.compounds[0].root_translation,
                    Vec3::NEG_Y * speed * creation.compounds[0].mass_properties.mass,
                )
                .unwrap();
                for tick in 1..=120 {
                    gpu.dispatch_tick(&device, &queue, tick);
                    device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                    let sample = gpu.poll_tick_readback(&device).unwrap().unwrap();
                    assert_eq!(
                        sample.diagnostics.error_flags, 0,
                        "shape {shape}, speed {speed}, tick {tick}"
                    );
                    for collider in &creation.colliders {
                        let pose = sample.transforms[collider.compound_index as usize];
                        let rotation = bevy_math::Quat::from_array(pose.rotation);
                        let minimum = match &collider.shape {
                            mechanic_core::ColliderShape::Cuboid {
                                local_rotation,
                                half_extents,
                            } => {
                                let center = Vec3::from_slice(&pose.position[..3])
                                    + rotation * collider.local_center;
                                center.y
                                    - ((rotation * *local_rotation).inverse() * Vec3::Y)
                                        .abs()
                                        .dot(*half_extents)
                            }
                            mechanic_core::ColliderShape::Convex(convex) => convex
                                .vertices
                                .iter()
                                .map(|vertex| pose.position[1] + (rotation * *vertex).y)
                                .fold(f32::INFINITY, f32::min),
                        };
                        let limit = if tick > 100 { 0.002 } else { 0.005 };
                        assert!(
                            minimum >= -limit,
                            "shape {shape}, speed {speed}, tick {tick}: bottom {minimum}"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn terrain_recovery_preserves_articulated_and_suspension_constraints() {
        use mechanic_core::{ShockSpec, SpringSpec, SuspensionSpec};
        let (device, queue) =
            test_device().expect("articulated terrain regression requires an adapter");
        let suspension = SuspensionSpec::new(
            Some(SpringSpec::default()),
            Some(ShockSpec::default()),
            None,
        )
        .unwrap();
        let scenes = [
            articulated_car_fixture().creation,
            suspension_test_creation_with_anchor(suspension, true, 1, false),
            suspension_test_creation_with_anchor(suspension, true, 65, false),
        ];
        for (scene, mut creation) in scenes.into_iter().enumerate() {
            for collider in &mut creation.colliders {
                collider.material_properties.restitution = 0.0;
                collider.material_properties.youngs_modulus_pa = 200.0e9;
            }
            let mut gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    ground_plane_enabled: false,
                    mechanism_self_collisions: false,
                    ..Default::default()
                },
            )
            .unwrap();
            assert_eq!(
                gpu.solver_route(),
                if scene == 2 {
                    super::GpuSolverRoute::General
                } else {
                    super::GpuSolverRoute::FusedSmallMechanism
                }
            );
            let mut terrain = super::terrain::tests::rigid_chunk();
            for vertex in &mut terrain.vertices {
                vertex[0] *= 100.0;
                vertex[2] *= 100.0;
            }
            gpu.write_terrain_chunks(&device, &queue, [&terrain], bevy_math::DVec3::ZERO)
                .unwrap();
            gpu.enable_async_readback();
            for (body, compound) in creation.compounds.iter().enumerate() {
                if compound.is_static {
                    continue;
                }
                gpu.apply_impulse(
                    &device,
                    &queue,
                    u32::try_from(body).unwrap(),
                    compound.root_translation,
                    Vec3::NEG_Y * 20.0 * compound.mass_properties.mass,
                )
                .unwrap();
            }
            for tick in 1..=120 {
                gpu.dispatch_tick(&device, &queue, tick);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let sample = gpu.poll_tick_readback(&device).unwrap().unwrap();
                assert_eq!(
                    sample.diagnostics.error_flags, 0,
                    "scene {scene}, tick {tick}: {:?}",
                    sample.diagnostics
                );
                let minimum = minimum_dynamic_collider_height(&creation, &sample.transforms);
                assert!(
                    minimum >= -if tick > 100 { 0.002 } else { 0.005 },
                    "scene {scene}, tick {tick}: bottom {minimum}"
                );
            }
        }
    }

    #[test]
    fn terrain_position_recovery_preserves_intentional_restitution() {
        let (device, queue) =
            test_device().expect("terrain restitution regression requires an adapter");
        let mut peaks = Vec::new();
        for restitution in [0.0, 0.8] {
            let mut creation = material_cube(ConstructionMaterial::Steel, 5);
            for collider in &mut creation.colliders {
                collider.material_properties.restitution = restitution;
            }
            let mut gpu = GpuPhysics::new_with_config(
                &device,
                &queue,
                &creation,
                GpuPhysicsConfig {
                    ground_plane_enabled: false,
                    ..Default::default()
                },
            )
            .unwrap();
            gpu.write_terrain_chunks(
                &device,
                &queue,
                [&super::terrain::tests::rigid_chunk()],
                bevy_math::DVec3::ZERO,
            )
            .unwrap();
            gpu.enable_async_readback();
            gpu.apply_impulse(
                &device,
                &queue,
                0,
                creation.compounds[0].root_translation,
                Vec3::NEG_Y * 5.0 * creation.compounds[0].mass_properties.mass,
            )
            .unwrap();
            let mut peak = f32::NEG_INFINITY;
            for tick in 1..=30 {
                gpu.dispatch_tick(&device, &queue, tick);
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let sample = gpu.poll_tick_readback(&device).unwrap().unwrap();
                assert_eq!(sample.diagnostics.error_flags, 0);
                peak = peak.max(sample.velocities[0].linear[1]);
            }
            peaks.push(peak);
        }
        assert!(
            peaks[0] < 0.001,
            "inelastic terrain contact rebounded: {peaks:?}"
        );
        assert!(
            peaks[1] > 1.0,
            "intentional restitution disappeared: {peaks:?}"
        );
    }

    fn minimum_dynamic_collider_height(
        creation: &mechanic_core::CompiledCreation,
        transforms: &[crate::GpuTransform],
    ) -> f32 {
        creation
            .colliders
            .iter()
            .filter(|collider| !creation.compounds[collider.compound_index as usize].is_static)
            .map(|collider| {
                let pose = transforms[collider.compound_index as usize];
                let rotation = bevy_math::Quat::from_array(pose.rotation);
                match &collider.shape {
                    mechanic_core::ColliderShape::Cuboid {
                        local_rotation,
                        half_extents,
                    } => {
                        let center = Vec3::from_slice(&pose.position[..3])
                            + rotation * collider.local_center;
                        center.y
                            - ((rotation * *local_rotation).inverse() * Vec3::Y)
                                .abs()
                                .dot(*half_extents)
                    }
                    mechanic_core::ColliderShape::Convex(convex) => convex
                        .vertices
                        .iter()
                        .map(|vertex| pose.position[1] + (rotation * *vertex).y)
                        .fold(f32::INFINITY, f32::min),
                }
            })
            .fold(f32::INFINITY, f32::min)
    }

    fn material_cube(
        material: ConstructionMaterial,
        center_half_units_y: i32,
    ) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        graph
            .apply(BuildCommand::Spawn(
                CuboidSpec::new(
                    [4; 3],
                    BuildPose::from_half_grid(
                        IVec3::new(0, center_half_units_y, 0),
                        GridRotation::default(),
                    ),
                )
                .unwrap()
                .with_material(material),
            ))
            .unwrap();
        graph.compile().unwrap()
    }

    /// A block whose top +z edge is collapsed onto the bottom, dropped from
    /// `center_half_units_y`.
    fn shaped_wedge(center_half_units_y: i32) -> mechanic_core::CompiledCreation {
        let spec = CuboidSpec::new(
            [4; 3],
            BuildPose::from_half_grid(
                IVec3::new(0, center_half_units_y, 0),
                GridRotation::default(),
            ),
        )
        .unwrap();
        let mut graph = ConstructionGraph::new();
        graph.apply(BuildCommand::Spawn(spec)).unwrap();
        let cells = mechanic_core::part_cells(spec);
        let region = mechanic_core::ShapeRegion::new(
            cells.corner_half_units(IVec3::ZERO, 0),
            cells.counts(),
            ConstructionMaterial::Steel,
        )
        .expect("the block spans at least one cell");
        let mechanic_core::BuildOutcome::RegionAdded(id) =
            graph.apply(BuildCommand::AddRegion(region)).unwrap()
        else {
            panic!("adding a region reports the region it added")
        };
        // Drop the top pair of cage corners on +z a whole cell onto the corners
        // below them, which slopes the whole top face.
        let cell = i16::try_from(mechanic_core::STEPS_PER_CELL).expect("a cell is twenty steps");
        graph
            .apply(BuildCommand::SetRegionVertices {
                region: id,
                vertices: vec![([0, 1, 1], [0, -cell, 0]), ([1, 1, 1], [0, -cell, 0])],
            })
            .expect("collapsing an edge is a legal shape");
        graph.compile().unwrap()
    }

    #[test]
    fn a_shaped_part_compiles_to_convex_collider_rows() {
        let creation = shaped_wedge(8);
        assert!(
            creation
                .colliders
                .iter()
                .any(|collider| !collider.shape.is_cuboid()),
            "shaping must produce convex collider rows, not boxes"
        );
        assert!(
            creation.colliders.len() < 64,
            "fusing should keep the row count small; got {}",
            creation.colliders.len()
        );
    }

    #[test]
    fn a_shaped_wedge_settles_on_the_ground_without_failing() {
        // The whole point of shaping being truthful: the solver has to accept
        // convex rows and bring them to rest like any other body.
        let Some((device, queue)) = test_device() else {
            return;
        };
        let creation = shaped_wedge(8);
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        for tick in 1..=180 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        assert_eq!(
            gpu.read_last_tick(&device).unwrap().error_flags,
            0,
            "convex colliders must not raise a failure flag"
        );
        let y = gpu
            .read_snapshot_transforms(&device, &queue, (180 % 3) as u8)
            .unwrap()[0]
            .position[1];
        assert!(
            y.is_finite() && y > -0.1,
            "the wedge should rest on the ground rather than sink; y={y}"
        );
        assert!(
            y < 1.0,
            "the wedge should have fallen from its 1 m drop; y={y}"
        );
    }

    #[test]
    fn higher_friction_material_loses_more_sliding_speed() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let slide = |material| {
            let creation = material_cube(material, 4);
            let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
            let mass = creation.compounds[0].mass_properties.mass;
            gpu.apply_impulse(&device, &queue, 0, Vec3::new(0.0, 0.5, 0.0), Vec3::X * mass)
                .unwrap();
            for tick in 1..=90 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            gpu.read_snapshot_transforms(&device, &queue, 0).unwrap()[0].position[0]
        };
        let plastic_distance = slide(ConstructionMaterial::Plastic);
        let concrete_distance = slide(ConstructionMaterial::Concrete);
        assert!(
            concrete_distance < plastic_distance - 0.02,
            "concrete slid {concrete_distance} m while plastic slid {plastic_distance} m",
        );
    }

    #[test]
    fn static_friction_holds_a_sub_threshold_load_while_kinetic_friction_slows_sliding() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let creation = material_cube(ConstructionMaterial::Aluminium, 4);
        let mass = creation.compounds[0].mass_properties.mass;
        let contact_center = Vec3::new(0.0, 0.5, 0.0);
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        for tick in 1..=60 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        let static_load_impulse = mass * 9.81 * crate::FIXED_DT_SECONDS * 0.62;
        for tick in 61..=120 {
            gpu.apply_impulse(
                &device,
                &queue,
                0,
                contact_center,
                Vec3::X * static_load_impulse,
            )
            .unwrap();
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let stuck = gpu.read_snapshot_transforms(&device, &queue, 0).unwrap()[0];
        assert!(
            stuck.position[0].abs() < 0.01,
            "sub-threshold static load moved the cube {} m",
            stuck.position[0],
        );

        let sliding = GpuPhysics::new(&device, &queue, &creation).unwrap();
        sliding
            .apply_impulse(&device, &queue, 0, contact_center, Vec3::X * mass * 3.0)
            .unwrap();
        for tick in 1..=2 {
            sliding.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let early = sliding
            .read_snapshot_transforms(&device, &queue, 2)
            .unwrap()[0];
        let initial = sliding
            .read_snapshot_transforms(&device, &queue, 1)
            .unwrap()[0];
        let early_speed = snapshot_speed(early, initial);
        for tick in 3..=20 {
            sliding.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let late = sliding
            .read_snapshot_transforms(&device, &queue, 2)
            .unwrap()[0];
        let previous = sliding
            .read_snapshot_transforms(&device, &queue, 1)
            .unwrap()[0];
        let late_speed = snapshot_speed(late, previous);
        assert!(
            late_speed < early_speed - 0.5,
            "sliding speed did not decay: {early_speed} to {late_speed}"
        );
        assert!(
            late_speed > 0.5,
            "kinetic friction used the static limit: final speed {late_speed}"
        );
    }

    #[test]
    fn higher_rolling_resistance_stops_an_otherwise_identical_cylinder_sooner() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        graph
            .apply(BuildCommand::SpawnCylinder(
                CylinderSpec::new(
                    CylinderDimensions::new(1.0, 0.0, 1.0).unwrap(),
                    BuildPose::new(IVec3::new(0, 2, 0), GridRotation::new(0, 0, 1)),
                )
                .with_material(ConstructionMaterial::Steel),
            ))
            .unwrap();
        let base = graph.compile().unwrap();
        let roll = |rolling_resistance: f32| {
            let mut creation = base.clone();
            for collider in &mut creation.colliders {
                collider.material_properties.rolling_resistance = rolling_resistance;
            }
            let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
            let mass = creation.compounds[0].mass_properties.mass;
            gpu.apply_impulse(
                &device,
                &queue,
                0,
                Vec3::new(0.0, 0.75, 0.0),
                Vec3::Z * mass * 2.0,
            )
            .unwrap();
            for tick in 1..=120 {
                gpu.dispatch_tick(&device, &queue, tick);
            }
            device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
            assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
            gpu.read_snapshot_transforms(&device, &queue, 0).unwrap()[0].position[2]
        };
        let low_distance = roll(0.002);
        let high_distance = roll(0.040);
        assert!(
            high_distance < low_distance - 0.05,
            "high rolling resistance travelled {high_distance} m; low travelled {low_distance} m",
        );
    }

    #[test]
    fn flat_disc_stops_sliding_without_long_term_contact_drift() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        graph
            .apply(BuildCommand::SpawnCylinder(CylinderSpec::new(
                CylinderDimensions::new(1.0, 0.0, 0.5).unwrap(),
                BuildPose::new(IVec3::new(0, 4, 0), GridRotation::default()),
            )))
            .unwrap();
        let creation = graph.compile().unwrap();
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        let mass = creation.compounds[0].mass_properties.mass;
        gpu.apply_impulse(
            &device,
            &queue,
            0,
            Vec3::new(0.35, 0.65, 0.0),
            Vec3::new(1.0, -0.35, 0.2) * mass,
        )
        .unwrap();

        for tick in 1..=600 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let settled =
            transform_position(gpu.read_snapshot_transforms(&device, &queue, 0).unwrap()[0]);

        for tick in 601..=1_200 {
            gpu.dispatch_tick(&device, &queue, tick);
        }
        device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
        let later =
            transform_position(gpu.read_snapshot_transforms(&device, &queue, 0).unwrap()[0]);
        let tail_drift = Vec3::new(later.x - settled.x, 0.0, later.z - settled.z).length();
        assert!(
            tail_drift < 0.005,
            "flat disc drifted {tail_drift} m after it should have stopped"
        );
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
    }

    #[test]
    fn flat_disc_landing_on_another_disc_does_not_gain_energy() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let mut graph = ConstructionGraph::new();
        let dimensions = CylinderDimensions::new(1.0, 0.0, 0.25).unwrap();
        let BuildOutcome::Spawned(lower) = graph
            .apply(BuildCommand::SpawnCylinder(
                CylinderSpec::new(
                    dimensions,
                    BuildPose::from_half_grid(IVec3::new(0, 1, 0), GridRotation::default()),
                )
                .with_material(ConstructionMaterial::Concrete),
            ))
            .unwrap()
        else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(lower, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        graph
            .apply(BuildCommand::SpawnCylinder(
                CylinderSpec::new(
                    dimensions,
                    BuildPose::new(IVec3::new(0, 4, 0), GridRotation::default()),
                )
                .with_material(ConstructionMaterial::Concrete),
            ))
            .unwrap();
        let creation = graph.compile().unwrap();
        let dynamic_body = creation
            .compounds
            .iter()
            .position(|compound| !compound.is_static)
            .unwrap();
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        let mut maximum_height_after_impact = 0.0_f32;
        for tick in 1..=120 {
            gpu.dispatch_tick(&device, &queue, tick);
            if tick >= 25 {
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                let position = transform_position(
                    gpu.read_snapshot_transforms(&device, &queue, (tick % 3) as u8)
                        .unwrap()[dynamic_body],
                );
                maximum_height_after_impact = maximum_height_after_impact.max(position.y);
                assert!(position.is_finite(), "stacked disc became non-finite");
                assert!(
                    position.x.abs() < 0.25 && position.z.abs() < 0.25,
                    "stacked disc was launched sideways to {position:?}"
                );
            }
        }
        assert!(
            maximum_height_after_impact < 0.9,
            "stacked disc rebounded above {maximum_height_after_impact} m"
        );
        assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
    }

    #[test]
    fn lower_modulus_allows_more_transient_penetration_without_failure() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let base = material_cube(ConstructionMaterial::Steel, 16);
        let minimum_height = |youngs_modulus_pa: f32| {
            let mut creation = base.clone();
            for collider in &mut creation.colliders {
                collider.material_properties.youngs_modulus_pa = youngs_modulus_pa;
            }
            let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
            let mut minimum = f32::INFINITY;
            for tick in 1..=60 {
                gpu.dispatch_tick(&device, &queue, tick);
                if tick >= 25 {
                    device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                    minimum = minimum.min(
                        gpu.read_snapshot_transforms(&device, &queue, (tick % 3) as u8)
                            .unwrap()[0]
                            .position[1],
                    );
                }
            }
            assert_eq!(gpu.read_last_tick(&device).unwrap().error_flags, 0);
            minimum
        };
        let stiff_height = minimum_height(200.0e9);
        let soft_height = minimum_height(0.01e9);
        assert!(
            soft_height < stiff_height - 1.0e-4,
            "soft contact reached {soft_height} m; stiff contact reached {stiff_height} m",
        );
        assert!(
            soft_height > 0.4,
            "soft contact became unstable at {soft_height} m"
        );
    }

    #[test]
    fn plastic_rebounds_more_than_concrete() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let rebound_height = |material| {
            let creation = material_cube(material, 16);
            let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
            let mut maximum_after_impact = 0.5_f32;
            for tick in 1..=100 {
                gpu.dispatch_tick(&device, &queue, tick);
                if tick >= 40 {
                    device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                    let y = gpu
                        .read_snapshot_transforms(&device, &queue, (tick % 3) as u8)
                        .unwrap()[0]
                        .position[1];
                    maximum_after_impact = maximum_after_impact.max(y);
                }
            }
            maximum_after_impact
        };
        let plastic_height = rebound_height(ConstructionMaterial::Plastic);
        let concrete_height = rebound_height(ConstructionMaterial::Concrete);
        assert!(
            plastic_height > concrete_height + 0.05,
            "plastic rebounded to {plastic_height} m while concrete reached {concrete_height} m",
        );
    }

    #[test]
    fn sub_threshold_ground_contact_settles_without_repeated_bounce() {
        let Some((device, queue)) = test_device() else {
            return;
        };
        let creation = material_cube(ConstructionMaterial::Plastic, 4);
        let gpu = GpuPhysics::new(&device, &queue, &creation).unwrap();
        let mass = creation.compounds[0].mass_properties.mass;
        gpu.apply_impulse(
            &device,
            &queue,
            0,
            Vec3::new(0.0, 0.5, 0.0),
            Vec3::NEG_Y * mass * 0.5,
        )
        .unwrap();
        let mut tail = Vec::new();
        for tick in 1..=120 {
            gpu.dispatch_tick(&device, &queue, tick);
            if tick >= 100 {
                device.poll(wgpu::PollType::wait_indefinitely()).unwrap();
                tail.push(
                    gpu.read_snapshot_transforms(&device, &queue, (tick % 3) as u8)
                        .unwrap()[0]
                        .position[1],
                );
            }
        }
        let movement = tail
            .windows(2)
            .map(|pair| (pair[1] - pair[0]).abs())
            .fold(0.0_f32, f32::max);
        assert!(
            movement < 1.0e-3,
            "settled contact moved {movement} m per tick"
        );
    }

    #[test]
    fn flat_cylinder_face_stays_supported_above_ground() {
        let mut graph = ConstructionGraph::new();
        graph
            .apply(BuildCommand::SpawnCylinder(CylinderSpec::new(
                CylinderDimensions::new(1.0, 0.0, 0.5).unwrap(),
                BuildPose::new(IVec3::new(0, 4, 0), GridRotation::default()),
            )))
            .unwrap();
        let creation = graph.compile().unwrap();
        let Some((snapshot, readback)) = run_ticks(&creation, 120, true) else {
            return;
        };
        assert_eq!(readback.error_flags, 0);
        let position = transform_position(snapshot[0]);
        let rotation = bevy_math::Quat::from_array(snapshot[0].rotation);
        assert!(
            position.y >= 0.245,
            "flat cylinder sank through its 0.25 m half-length to {} m",
            position.y
        );
        assert!((rotation * Vec3::Y).dot(Vec3::Y) > 0.98);
    }

    #[test]
    fn grounded_offset_pendulum_swings_without_detaching() {
        let creation = pendulum_creation(true);
        let Some((snapshot, readback)) = run_ticks(&creation, 30, false) else {
            return;
        };
        assert_eq!(readback.error_flags, 0);
        assert!(snapshot[1].rotation[0].abs() > 1.0e-3);
        let root = Vec3::from_array(snapshot[0].position[..3].try_into().unwrap());
        assert!(root.abs_diff_eq(creation.compounds[0].root_translation, 1.0e-5));
    }

    #[test]
    fn freely_falling_hinge_has_no_gravity_induced_relative_rotation() {
        let creation = pendulum_creation(false);
        let Some((snapshot, readback)) = run_ticks(&creation, 30, false) else {
            return;
        };
        assert_eq!(readback.error_flags, 0);
        assert!(snapshot[0].position[1] < creation.compounds[0].root_translation.y - 0.5);
        assert!(snapshot[1].rotation[0].abs() < 1.0e-4);
        assert!(snapshot[1].rotation[1].abs() < 1.0e-4);
        assert!(snapshot[1].rotation[2].abs() < 1.0e-4);
    }

    fn cylinder_drop_creation(
        inner_diameter: f32,
        drop_x_half_units: i32,
    ) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let support_spec = CuboidSpec::new(
            [4, 4, 4],
            BuildPose::new(IVec3::new(8, 2, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(support) =
            graph.apply(BuildCommand::Spawn(support_spec)).unwrap()
        else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(support, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        let cylinder_spec = CylinderSpec::new(
            CylinderDimensions::new(1.0, inner_diameter, 1.0).unwrap(),
            BuildPose::new(IVec3::new(0, 12, 0), GridRotation::default()),
        );
        let BuildOutcome::Spawned(cylinder) = graph
            .apply(BuildCommand::SpawnCylinder(cylinder_spec))
            .unwrap()
        else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::RigidLink(RigidLinkSpec {
                first: support,
                second: cylinder,
            }))
            .unwrap();
        let drop_spec = CuboidSpec::new(
            [1, 1, 1],
            BuildPose::from_half_grid(
                IVec3::new(drop_x_half_units, 40, 0),
                GridRotation::default(),
            ),
        )
        .unwrap();
        graph.apply(BuildCommand::Spawn(drop_spec)).unwrap();
        graph.compile().unwrap()
    }

    #[test]
    fn gpu_cylinder_bore_is_passable_and_annular_material_blocks_motion() {
        let hollow = cylinder_drop_creation(0.60, 0);
        let solid = cylinder_drop_creation(0.0, 0);
        let annular = cylinder_drop_creation(0.60, 3);
        let Some((hollow_snapshot, hollow_readback)) = run_ticks(&hollow, 60, true) else {
            return;
        };
        let Some((solid_snapshot, solid_readback)) = run_ticks(&solid, 60, true) else {
            return;
        };
        let Some((annular_snapshot, annular_readback)) = run_ticks(&annular, 60, true) else {
            return;
        };
        assert_eq!(hollow_readback.error_flags, 0);
        assert_eq!(solid_readback.error_flags, 0);
        assert_eq!(annular_readback.error_flags, 0);
        let falling_body = 1;
        assert!(hollow_snapshot[falling_body].position[1] < 2.5);
        assert!(solid_snapshot[falling_body].position[1] > 3.4);
        assert!(
            annular_snapshot[falling_body].position[1] > 3.35,
            "annular drop reached y={} instead of resting on the ring",
            annular_snapshot[falling_body].position[1]
        );
    }

    fn pipe_bend_drop_creation(
        inner_diameter: f32,
        drop_x_half_units: i32,
    ) -> mechanic_core::CompiledCreation {
        let mut graph = ConstructionGraph::new();
        let support_spec = CuboidSpec::new(
            [4, 4, 4],
            BuildPose::new(IVec3::new(8, 2, 0), GridRotation::default()),
        )
        .unwrap();
        let BuildOutcome::Spawned(support) =
            graph.apply(BuildCommand::Spawn(support_spec)).unwrap()
        else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(support, FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        let bend_spec = PipeBendSpec::new(
            PipeBendDimensions::new(1.0, inner_diameter, 1.0).unwrap(),
            BuildPose::from_half_grid(IVec3::new(0, 16, 0), GridRotation::default()),
        );
        let BuildOutcome::Spawned(bend) =
            graph.apply(BuildCommand::SpawnPipeBend(bend_spec)).unwrap()
        else {
            unreachable!()
        };
        graph
            .apply(BuildCommand::RigidLink(RigidLinkSpec {
                first: support,
                second: bend,
            }))
            .unwrap();
        let drop_spec = CuboidSpec::new(
            [1, 1, 1],
            BuildPose::from_half_grid(
                IVec3::new(drop_x_half_units, 32, 0),
                GridRotation::default(),
            ),
        )
        .unwrap();
        graph.apply(BuildCommand::Spawn(drop_spec)).unwrap();
        graph.compile().unwrap()
    }

    #[test]
    fn gpu_pipe_bend_bore_is_passable_and_annular_material_blocks_motion() {
        let hollow = pipe_bend_drop_creation(0.60, 0);
        let solid = pipe_bend_drop_creation(0.0, 0);
        let annular = pipe_bend_drop_creation(0.60, 3);
        let Some((hollow_snapshot, hollow_readback)) = run_ticks(&hollow, 60, true) else {
            return;
        };
        let Some((solid_snapshot, solid_readback)) = run_ticks(&solid, 60, true) else {
            return;
        };
        let Some((annular_snapshot, annular_readback)) = run_ticks(&annular, 60, true) else {
            return;
        };
        assert_eq!(hollow_readback.error_flags, 0);
        assert_eq!(solid_readback.error_flags, 0);
        assert_eq!(annular_readback.error_flags, 0);
        let falling_body = 1;
        assert!(
            hollow_snapshot[falling_body].position[1] < 2.95,
            "centered drop did not enter the bend bore: y={}",
            hollow_snapshot[falling_body].position[1]
        );
        assert!(solid_snapshot[falling_body].position[1] > 3.0);
        assert!(annular_snapshot[falling_body].position[1] > 3.0);
    }

    #[test]
    fn contact_supported_unwelded_tower_drives_welded_arm() {
        let mut graph = ConstructionGraph::new();
        let mut parts = Vec::new();
        for y in [2, 6, 10, 14] {
            let spec = CuboidSpec::new(
                [4, 4, 4],
                BuildPose::new(IVec3::new(0, y, 0), GridRotation::default()),
            )
            .unwrap();
            let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap()
            else {
                unreachable!()
            };
            parts.push(part);
        }
        for z in [0, 4, 8] {
            let spec = CuboidSpec::new(
                [4, 4, 4],
                BuildPose::new(IVec3::new(4, 14, z), GridRotation::default()),
            )
            .unwrap();
            let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap()
            else {
                unreachable!()
            };
            parts.push(part);
        }
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(parts[4], FaceKind::PositiveZ),
                second: FaceRef::part(parts[5], FaceKind::NegativeZ),
            }))
            .unwrap();
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(parts[5], FaceKind::PositiveZ),
                second: FaceRef::part(parts[6], FaceKind::NegativeZ),
            }))
            .unwrap();
        graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(parts[3], FaceKind::PositiveX),
                FaceRef::part(parts[4], FaceKind::NegativeX),
                Vec3::new(0.5, 3.5, 0.0),
                Vec3::X,
            )))
            .unwrap();
        let creation = graph.compile().unwrap();
        let Some((snapshot, readback)) = run_ticks(&creation, 90, true) else {
            return;
        };
        assert_eq!(readback.error_flags, 0);
        let bearing = creation.bearings[0];
        let body_a = bearing.compound_a as usize;
        let body_b = bearing.compound_b as usize;
        let rotation_a = bevy_math::Quat::from_array(snapshot[body_a].rotation);
        let rotation_b = bevy_math::Quat::from_array(snapshot[body_b].rotation);
        let anchor_a = Vec3::from_array(snapshot[body_a].position[..3].try_into().unwrap())
            + rotation_a * bearing.local_anchor_a;
        let anchor_b = Vec3::from_array(snapshot[body_b].position[..3].try_into().unwrap())
            + rotation_b * bearing.local_anchor_b;
        assert!(anchor_a.abs_diff_eq(anchor_b, 1.0e-5));
        assert!(snapshot[body_b].rotation[0].abs() > 1.0e-3);
        assert!(
            snapshot[body_a].position[1] > 0.5,
            "contact-supported body fell to {} m",
            snapshot[body_a].position[1]
        );
    }

    #[test]
    fn double_pendulum_transfers_motion_through_both_bearings() {
        let mut graph = ConstructionGraph::new();
        let mut spawned = Vec::new();
        for units in [
            IVec3::new(0, 2, 0),
            IVec3::new(4, 2, 0),
            IVec3::new(4, 2, 4),
            IVec3::new(8, 2, 0),
            IVec3::new(8, 2, 4),
        ] {
            let spec =
                CuboidSpec::new([4, 4, 4], BuildPose::new(units, GridRotation::default())).unwrap();
            let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap()
            else {
                unreachable!()
            };
            spawned.push(part);
        }
        for (a, b) in [(1, 2), (3, 4)] {
            graph
                .apply(BuildCommand::Weld(WeldSpec {
                    first: FaceRef::part(spawned[a], FaceKind::PositiveZ),
                    second: FaceRef::part(spawned[b], FaceKind::NegativeZ),
                }))
                .unwrap();
        }
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(spawned[0], FaceKind::NegativeY),
                second: FaceRef::ground(),
            }))
            .unwrap();
        for (a, b, x) in [(0, 1, 0.5), (1, 3, 1.5)] {
            graph
                .apply(BuildCommand::AddBearing(BearingSpec::new(
                    FaceRef::part(spawned[a], FaceKind::PositiveX),
                    FaceRef::part(spawned[b], FaceKind::NegativeX),
                    Vec3::new(x, 0.5, 0.0),
                    Vec3::X,
                )))
                .unwrap();
        }
        let creation = graph.compile().unwrap();
        let Some((snapshot, readback)) = run_ticks(&creation, 30, false) else {
            return;
        };
        assert_eq!(readback.error_flags, 0);
        let first = bevy_math::Quat::from_array(snapshot[1].rotation);
        let second = bevy_math::Quat::from_array(snapshot[2].rotation);
        assert!(first.x.abs() > 1.0e-3);
        assert!((first.conjugate() * second).x.abs() > 1.0e-4);
    }

    #[test]
    fn balanced_child_contacts_move_root_without_spurious_joint_motion() {
        let mut graph = ConstructionGraph::new();
        let mut spawned = Vec::new();
        for units in [
            IVec3::new(0, 6, 0),
            IVec3::new(4, 6, 0),
            IVec3::new(4, 2, 0),
            IVec3::new(4, 2, 4),
        ] {
            let spec =
                CuboidSpec::new([4, 4, 4], BuildPose::new(units, GridRotation::default())).unwrap();
            let BuildOutcome::Spawned(part) = graph.apply(BuildCommand::Spawn(spec)).unwrap()
            else {
                unreachable!()
            };
            spawned.push(part);
        }
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(spawned[1], FaceKind::NegativeY),
                second: FaceRef::part(spawned[2], FaceKind::PositiveY),
            }))
            .unwrap();
        graph
            .apply(BuildCommand::Weld(WeldSpec {
                first: FaceRef::part(spawned[2], FaceKind::PositiveZ),
                second: FaceRef::part(spawned[3], FaceKind::NegativeZ),
            }))
            .unwrap();
        graph
            .apply(BuildCommand::AddBearing(BearingSpec::new(
                FaceRef::part(spawned[0], FaceKind::PositiveX),
                FaceRef::part(spawned[1], FaceKind::NegativeX),
                Vec3::new(0.5, 1.5, 0.0),
                Vec3::X,
            )))
            .unwrap();
        let creation = graph.compile().unwrap();
        let Some((free, _)) = run_ticks(&creation, 8, false) else {
            return;
        };
        let Some((contact, readback)) = run_ticks(&creation, 8, true) else {
            return;
        };
        assert_eq!(readback.error_flags, 0);
        let root = creation.bearings[0].compound_a as usize;
        let child = creation.bearings[0].compound_b as usize;
        assert!(contact[root].position[1] > free[root].position[1] + 1.0e-4);
        let root_rotation = bevy_math::Quat::from_array(contact[root].rotation);
        let child_rotation = bevy_math::Quat::from_array(contact[child].rotation);
        assert!((root_rotation.conjugate() * child_rotation).x.abs() < 1.0e-4);
    }
}
