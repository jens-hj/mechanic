//! Smooth search equations only. Original nonsmooth laws decide acceptance.

use super::super::super::{BlockLayout, ConstraintBlock};

pub(super) struct Point {
    pub first: usize,
    pub size: usize,
    pub derivative: Vec<f64>,
}

pub(super) struct Evaluation {
    pub rhs: Vec<f64>,
    pub points: Vec<Point>,
    pub norm: f64,
    pub maximum: f64,
}

pub(super) fn evaluate(
    blocks: &[ConstraintBlock],
    layout: &[BlockLayout],
    modes: &[Vec<bool>],
    impulses: &[f64],
    motion: &[f64],
    epsilon: f64,
) -> Option<Evaluation> {
    let mut rhs = vec![0.0; impulses.len()];
    let mut points = Vec::new();
    let mut norm = 0.0_f64;
    let mut maximum = 0.0_f64;
    for ((block, info), modes) in blocks.iter().zip(layout).zip(modes) {
        let mut first = info.first;
        let width = epsilon / info.scale;
        for (contact, &sliding) in block.contacts.iter().zip(modes) {
            let size = contact.rows();
            let mut at = [0.0; 5];
            for row in 0..size {
                at[row] = impulses[first + row]
                    + (block.target[first + row - info.first] - motion[first + row]) / info.scale;
            }
            let mut projection = [0.0; 5];
            let mut derivative = vec![0.0; size * size];
            let root = at[0].hypot(width);
            // Rationalized negative branch avoids cancellation at released points.
            projection[0] = if at[0] < 0.0 {
                0.5 * width * (width / (root - at[0]))
            } else {
                0.5 * (at[0] + root)
            };
            derivative[0] = projection[0] / root;
            let coefficient = if sliding {
                contact.kinetic_coefficient
            } else {
                contact.static_coefficient
            };
            for (offset, coefficient) in std::iter::once((1, coefficient))
                .chain(contact.rolling_length.map(|length| (3, length)))
            {
                let values = [at[offset], at[offset + 1]];
                let length = values[0].hypot(values[1]);
                let radius = coefficient * projection[0];
                let root = (length - radius).hypot(width);
                let denominator = 0.5 * (radius + length + root);
                let length_derivative = 0.5 * (1.0 + (length - radius) / root);
                let radius_derivative = 1.0 - length_derivative;
                let ratio = radius / denominator;
                for row in 0..2 {
                    projection[offset + row] = values[row] * ratio;
                    derivative[(offset + row) * size] =
                        values[row] * coefficient * (1.0 - ratio * radius_derivative) / denominator
                            * derivative[0];
                    for column in 0..2 {
                        derivative[(offset + row) * size + offset + column] = ratio
                            * (f64::from(row == column)
                                - length_derivative * values[row] / denominator
                                    * if length > 0.0 {
                                        values[column] / length
                                    } else {
                                        0.0
                                    });
                    }
                }
            }
            for row in 0..size {
                rhs[first + row] = projection[row] - impulses[first + row];
                let residual = rhs[first + row] * info.scale;
                maximum = maximum.max(residual.abs());
                norm = norm.hypot(residual);
            }
            points.push(Point {
                first,
                size,
                derivative,
            });
            first += size;
        }
    }
    (norm.is_finite() && rhs.iter().all(|value| value.is_finite())).then_some(Evaluation {
        rhs,
        points,
        norm,
        maximum,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{ContactFriction, ImpulseBounds};

    #[test]
    fn smooth_contact_derivative_matches_central_differences_through_contact_transitions() {
        for rolling in [None, Some(0.1)] {
            let size = if rolling.is_some() { 5 } else { 3 };
            let mut bounds = vec![
                ImpulseBounds {
                    minimum: f64::NEG_INFINITY,
                    maximum: f64::INFINITY
                };
                size
            ];
            bounds[0].minimum = 0.0;
            let blocks = [ConstraintBlock {
                jacobian: vec![vec![0.0]; size],
                target: vec![0.0; size],
                bounds,
                contacts: vec![ContactFriction {
                    static_coefficient: 0.8,
                    kinetic_coefficient: 0.5,
                    sliding: true,
                    rolling_length: rolling,
                }],
            }];
            let layout = [BlockLayout {
                first: 0,
                diagonal: vec![0.0; size * size],
                scale: 1.0,
            }];
            for normal in [-2.0, 0.0, 1.0, 3.0] {
                for tangent in [[0.0, 0.0], [0.3, 0.4], [3.0, -4.0]] {
                    for mode in [false, true] {
                        let at = [normal, tangent[0], tangent[1], 0.06, -0.08];
                        let at = &at[..size];
                        let modes = [vec![mode]];
                        let eval = |v: &[f64]| {
                            evaluate(&blocks, &layout, &modes, v, &vec![0.0; size], 0.01).unwrap()
                        };
                        let original = eval(at);
                        for column in 0..size {
                            let mut plus = at.to_vec();
                            let mut minus = at.to_vec();
                            // The radial map is C1 at a zero tangent. Its central
                            // quotient there has first-order truncation error.
                            let step = if (column == 1 || column == 2) && tangent == [0.0, 0.0] {
                                1e-9
                            } else {
                                1e-6
                            };
                            plus[column] += step;
                            minus[column] -= step;
                            let a = eval(&plus);
                            let b = eval(&minus);
                            for row in 0..size {
                                let actual = (a.rhs[row] + plus[row] - b.rhs[row] - minus[row])
                                    / (2.0 * step);
                                let expected = original.points[0].derivative[row * size + column];
                                assert!(
                                    (actual - expected).abs() < 2e-7,
                                    "row={row} column={column} normal={normal} actual={actual} expected={expected}"
                                );
                            }
                        }
                    }
                }
            }
        }
    }
}
