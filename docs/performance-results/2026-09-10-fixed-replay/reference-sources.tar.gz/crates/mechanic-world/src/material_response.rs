//! Initial game-tuned surface contact properties; these are not measured soil data.

use crate::TerrainMaterial;

/// Surface response supplied to construction/terrain contacts.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TerrainSurfaceResponse {
    /// Static Coulomb friction coefficient.
    pub static_friction: f32,
    /// Sliding Coulomb friction coefficient.
    pub dynamic_friction: f32,
    /// Normal coefficient of restitution.
    pub restitution: f32,
    /// Rolling resistance coefficient.
    pub rolling_resistance: f32,
}

impl TerrainMaterial {
    /// Initial surface tuning. Permanent deformation is a separate response.
    pub const fn surface_response(self) -> TerrainSurfaceResponse {
        let (static_friction, dynamic_friction, rolling_resistance) = match self {
            Self::SurfaceCover => (0.8, 0.65, 0.03),
            Self::Soil => (0.7, 0.55, 0.025),
            Self::Sand => (0.6, 0.5, 0.04),
            Self::Rock => (0.8, 0.6, 0.01),
            Self::Iron => (0.6, 0.45, 0.01),
            Self::Graphite => (0.3, 0.2, 0.01),
        };
        TerrainSurfaceResponse {
            static_friction,
            dynamic_friction,
            restitution: 0.0,
            rolling_resistance,
        }
    }
}
