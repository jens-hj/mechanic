//! CPU experiments for compiled machine dynamics.
//!
//! This crate currently exposes numerical factors and pose-dependent machine
//! response. It is not yet an authoritative world runtime: terrain collision,
//! tick publication, drive integration, and cross-backend acceptance remain open.

mod machine;
mod response;

pub use machine::{BodyPose, MachineDynamics, SpatialMotion};
pub use response::{
    ConstraintBlock, ConstraintSolution, DENSE_CONTACT_ROWS, DynamicsFactor, ImpulseBounds,
    solve_constraints,
};

/// Explicit failures from the compiled dynamics experiment. Failed results must
/// never be published as a completed physics tick.
#[derive(Clone, Debug, thiserror::Error, PartialEq, Eq)]
pub enum PhysicsError {
    /// Malformed or non-positive effective dynamics.
    #[error("effective dynamics are non-finite, asymmetric, or not positive definite")]
    InvalidDynamics,
    /// Invalid constraint dimensions, bounds, or solver settings.
    #[error("invalid constraint rows or solver settings")]
    InvalidConstraints,
    /// Rank-revealing elimination found incompatible dependent equations.
    #[error("dependent constraint rows have inconsistent targets")]
    InconsistentConstraints,
    /// The reference experiment deliberately bounds its dense generalized matrix.
    #[error("dense reference experiment supports at most 512 generalized velocities")]
    ReferenceCapacity,
}
