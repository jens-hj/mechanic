//! Coupled impulse response through factor solves, with bounded contact storage.

use crate::PhysicsError;

/// Largest scalar constraint count for explicit contact-response storage.
pub const DENSE_CONTACT_ROWS: usize = 128;

/// Positive-definite effective dynamics factored once per substep.
#[derive(Clone, Debug)]
pub struct DynamicsFactor {
    size: usize,
    lower: Vec<f64>,
}

impl DynamicsFactor {
    /// Factors a symmetric row-major effective mass matrix. No inverse is formed.
    ///
    /// # Errors
    /// Rejects malformed, non-finite, asymmetric, or non-positive dynamics.
    pub fn new(matrix: &[f64], size: usize) -> Result<Self, PhysicsError> {
        if size.checked_mul(size) != Some(matrix.len()) || matrix.iter().any(|x| !x.is_finite()) {
            return Err(PhysicsError::InvalidDynamics);
        }
        let mut lower = vec![0.0; matrix.len()];
        for row in 0..size {
            for column in 0..=row {
                let a = matrix[row * size + column];
                let b = matrix[column * size + row];
                if (a - b).abs() > 1e-12 * a.abs().max(b.abs()).max(1.0) {
                    return Err(PhysicsError::InvalidDynamics);
                }
                let value = a
                    - (0..column)
                        .map(|k| lower[row * size + k] * lower[column * size + k])
                        .sum::<f64>();
                lower[row * size + column] = if row == column {
                    if value <= 0.0 || !value.is_finite() {
                        return Err(PhysicsError::InvalidDynamics);
                    }
                    value.sqrt()
                } else {
                    value / lower[column * size + column]
                };
            }
        }
        Ok(Self { size, lower })
    }

    /// Applies inverse dynamics in-place to a generalized impulse.
    ///
    /// # Errors
    /// Rejects incorrect row counts or non-finite inputs/results.
    pub fn solve(&self, values: &mut [f64]) -> Result<(), PhysicsError> {
        if values.len() != self.size || values.iter().any(|x| !x.is_finite()) {
            return Err(PhysicsError::InvalidDynamics);
        }
        for row in 0..self.size {
            let previous = (0..row)
                .map(|k| self.lower[row * self.size + k] * values[k])
                .sum::<f64>();
            values[row] = (values[row] - previous) / self.lower[row * self.size + row];
        }
        for row in (0..self.size).rev() {
            let next = (row + 1..self.size)
                .map(|k| self.lower[k * self.size + row] * values[k])
                .sum::<f64>();
            values[row] = (values[row] - next) / self.lower[row * self.size + row];
        }
        if values.iter().any(|x| !x.is_finite()) {
            return Err(PhysicsError::InvalidDynamics);
        }
        Ok(())
    }
}

/// Bounds on one scalar row. Bilateral rows use infinite limits.
#[derive(Clone, Copy, Debug)]
pub struct ImpulseBounds {
    /// Minimum allowed impulse.
    pub minimum: f64,
    /// Maximum allowed impulse.
    pub maximum: f64,
}

/// One coupled contact manifold, drive, stop, or loop block.
#[derive(Clone, Debug)]
pub struct ConstraintBlock {
    /// Generalized Jacobian rows. All rows must match the dynamics dimension.
    pub jacobian: Vec<Vec<f64>>,
    /// Required change in row velocity before constraint impulses.
    pub target: Vec<f64>,
    /// Per-row impulse bounds.
    pub bounds: Vec<ImpulseBounds>,
    /// For contact manifolds, each consecutive triple is normal/tangent/tangent.
    /// Tangential impulses are projected onto a disk of radius μ times normal impulse.
    /// Normal lower bounds must be zero; tangential bounds must be infinite.
    pub friction: Option<f64>,
}

/// Result of a deterministic block projected solve.
#[derive(Clone, Debug)]
pub struct ConstraintSolution {
    /// Generalized velocity change; apply only after checking convergence.
    pub velocity_change: Vec<f64>,
    /// Scalar impulses in block/row order.
    pub impulses: Vec<f64>,
    /// Maximum projected velocity residual.
    pub residual: f64,
    /// Number of completed block sweeps.
    pub iterations: usize,
    /// Whether the residual reached the requested threshold.
    pub converged: bool,
    /// Scalar slots allocated for the explicit response matrix (zero above 128 rows).
    pub response_storage: usize,
    /// Inverse-dynamics applications, including response preparation and final motion.
    pub factor_solves: usize,
}

struct BlockLayout {
    first: usize,
    diagonal: Vec<f64>,
}

/// Solve `J H⁻¹ Jᵀ λ = target` subject to block bounds. Above 128 scalar rows,
/// responses use factor solves and linear scratch storage instead of a dense W.
///
/// # Errors
/// Rejects malformed constraints and inconsistent dependent bilateral rows.
#[allow(clippy::too_many_lines)] // Keep response preparation, sweeps, and final residual in one numerical path.
pub fn solve_constraints(
    factor: &DynamicsFactor,
    blocks: &[ConstraintBlock],
    max_iterations: usize,
    tolerance: f64,
) -> Result<ConstraintSolution, PhysicsError> {
    if max_iterations == 0 || !tolerance.is_finite() || tolerance <= 0.0 {
        return Err(PhysicsError::InvalidConstraints);
    }
    let mut rows = Vec::new();
    let mut layout = Vec::new();
    for block in blocks {
        let count = block.jacobian.len();
        if count == 0
            || count > DENSE_CONTACT_ROWS
            || block.target.len() != count
            || block.bounds.len() != count
            || block
                .jacobian
                .iter()
                .any(|row| row.len() != factor.size || row.iter().any(|x| !x.is_finite()))
            || block.target.iter().any(|x| !x.is_finite())
            || block.bounds.iter().any(|b| {
                b.minimum.is_nan()
                    || b.maximum.is_nan()
                    || b.minimum > b.maximum
                    || b.minimum == f64::INFINITY
                    || b.maximum == f64::NEG_INFINITY
            })
            || block.friction.is_some_and(|mu| {
                !mu.is_finite()
                    || mu < 0.0
                    || !count.is_multiple_of(3)
                    || block.bounds.chunks_exact(3).any(|bounds| {
                        bounds[0].minimum != 0.0
                            || bounds[1..].iter().any(|b| {
                                b.minimum != f64::NEG_INFINITY || b.maximum != f64::INFINITY
                            })
                    })
            })
        {
            return Err(PhysicsError::InvalidConstraints);
        }
        layout.push(BlockLayout {
            first: rows.len(),
            diagonal: vec![0.0; count * count],
        });
        rows.extend(block.jacobian.iter());
    }
    let count = rows.len();
    let mut response = if count <= DENSE_CONTACT_ROWS {
        vec![0.0; count * count]
    } else {
        Vec::new()
    };
    let mut factor_solves = 0;
    let mut scratch = vec![0.0; factor.size];
    for (block, info) in blocks.iter().zip(&mut layout) {
        let size = block.jacobian.len();
        for column in 0..size {
            scratch.copy_from_slice(rows[info.first + column]);
            factor.solve(&mut scratch)?;
            factor_solves += 1;
            for row in 0..size {
                info.diagonal[row * size + column] = dot(rows[info.first + row], &scratch);
            }
            if !response.is_empty() {
                for row in 0..count {
                    response[row * count + info.first + column] = dot(rows[row], &scratch);
                }
            }
        }
    }
    let mut impulses = vec![0.0; count];
    let mut change = vec![0.0; factor.size];
    let mut row_change = vec![0.0; count];
    let mut residual;
    let mut iterations = 0;
    for iteration in 1..=max_iterations {
        for (block, info) in blocks.iter().zip(&layout) {
            let size = block.jacobian.len();
            let rhs = (0..size)
                .map(|row| {
                    block.target[row]
                        - if response.is_empty() {
                            dot(rows[info.first + row], &change)
                        } else {
                            row_change[info.first + row]
                        }
                })
                .collect::<Vec<_>>();
            let delta = block_delta(block, &info.diagonal, &rhs, tolerance)?;
            let mut candidate = (0..size)
                .map(|row| impulses[info.first + row] + delta[row])
                .collect::<Vec<_>>();
            project(block, &mut candidate);
            scratch.fill(0.0);
            for row in 0..size {
                let difference = candidate[row] - impulses[info.first + row];
                impulses[info.first + row] = candidate[row];
                if response.is_empty() {
                    for (out, &j) in scratch.iter_mut().zip(rows[info.first + row]) {
                        *out += j * difference;
                    }
                } else {
                    for (index, out) in row_change.iter_mut().enumerate() {
                        *out += response[index * count + info.first + row] * difference;
                    }
                }
            }
            if response.is_empty() {
                factor.solve(&mut scratch)?;
                factor_solves += 1;
                for (out, &delta) in change.iter_mut().zip(&scratch) {
                    *out += delta;
                }
            }
        }
        // Re-evaluate every block against the final iterate, not the value seen
        // before later blocks changed it. Raw residuals are nonzero at active bounds.
        if response.is_empty() {
            for (out, row) in row_change.iter_mut().zip(&rows) {
                *out = dot(row, &change);
            }
        }
        residual = projected_residual(blocks, &layout, &row_change, &impulses, tolerance)?;
        iterations = iteration;
        if residual <= tolerance {
            break;
        }
    }
    // Reconstruct body motion only after the repeated contact solve. The dense
    // route never propagates a contact impulse through the machine inside a sweep.
    change.fill(0.0);
    for (row, &impulse) in rows.iter().zip(&impulses) {
        for (out, &j) in change.iter_mut().zip(*row) {
            *out += j * impulse;
        }
    }
    factor.solve(&mut change)?;
    factor_solves += 1;
    for (out, row) in row_change.iter_mut().zip(&rows) {
        *out = dot(row, &change);
    }
    residual = projected_residual(blocks, &layout, &row_change, &impulses, tolerance)?;
    Ok(ConstraintSolution {
        velocity_change: change,
        impulses,
        residual,
        iterations,
        converged: residual <= tolerance,
        response_storage: response.len(),
        factor_solves,
    })
}

fn projected_residual(
    blocks: &[ConstraintBlock],
    layout: &[BlockLayout],
    row_change: &[f64],
    impulses: &[f64],
    tolerance: f64,
) -> Result<f64, PhysicsError> {
    let mut residual = 0.0_f64;
    for (block, info) in blocks.iter().zip(layout) {
        let size = block.jacobian.len();
        let rhs = (0..size)
            .map(|row| block.target[row] - row_change[info.first + row])
            .collect::<Vec<_>>();
        let delta = block_delta(block, &info.diagonal, &rhs, tolerance)?;
        let mut candidate = (0..size)
            .map(|row| impulses[info.first + row] + delta[row])
            .collect::<Vec<_>>();
        project(block, &mut candidate);
        let scale = block_scale(&info.diagonal, size);
        for row in 0..size {
            let error = if is_bilateral(block) {
                rhs[row]
            } else {
                scale * (candidate[row] - impulses[info.first + row])
            };
            if !error.is_finite() {
                return Err(PhysicsError::InvalidDynamics);
            }
            residual = residual.max(error.abs());
        }
    }
    Ok(residual)
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(a, b)| a * b).sum()
}

fn is_bilateral(block: &ConstraintBlock) -> bool {
    block.friction.is_none()
        && block
            .bounds
            .iter()
            .all(|bounds| bounds.minimum == f64::NEG_INFINITY && bounds.maximum == f64::INFINITY)
}

fn block_scale(matrix: &[f64], size: usize) -> f64 {
    matrix
        .chunks_exact(size)
        .map(|row| row.iter().map(|x| x.abs()).sum::<f64>())
        .fold(0.0, f64::max)
        .max(1e-30)
}

fn block_delta(
    block: &ConstraintBlock,
    matrix: &[f64],
    rhs: &[f64],
    tolerance: f64,
) -> Result<Vec<f64>, PhysicsError> {
    if is_bilateral(block) {
        return rank_solve(matrix, rhs, tolerance);
    }
    // A scalar step bounded by the block's spectral radius makes Euclidean
    // projection valid. Clipping an unconstrained W^-1 solution is not a bounded
    // block solve: off-diagonal coupling can falsely report convergence.
    let scale = block_scale(matrix, rhs.len());
    Ok(rhs.iter().map(|value| value / scale).collect())
}

fn project(block: &ConstraintBlock, values: &mut [f64]) {
    for (value, bounds) in values.iter_mut().zip(&block.bounds) {
        *value = value.clamp(bounds.minimum, bounds.maximum);
    }
    if let Some(mu) = block.friction {
        for triple in values.chunks_exact_mut(3) {
            triple[0] = triple[0].max(0.0);
            let length = triple[1].hypot(triple[2]);
            let radius = mu * triple[0];
            if length > radius {
                triple[1] *= radius / length;
                triple[2] *= radius / length;
            }
        }
    }
}

// Deterministic complete diagonal pivoting for a positive-semidefinite block.
// Dependent rows are retained and checked for consistency, never regularized.
fn rank_solve(matrix: &[f64], rhs: &[f64], tolerance: f64) -> Result<Vec<f64>, PhysicsError> {
    let n = rhs.len();
    if n == 1 {
        if matrix[0] > 0.0 {
            return Ok(vec![rhs[0] / matrix[0]]);
        }
        if rhs[0].abs() <= tolerance {
            return Ok(vec![0.0]);
        }
        return Err(PhysicsError::InconsistentConstraints);
    }
    let mut a = matrix.to_vec();
    let mut b = rhs.to_vec();
    let mut permutation = (0..n).collect::<Vec<_>>();
    let scale = (0..n).map(|i| a[i * n + i].abs()).fold(0.0, f64::max);
    let mut rank = n;
    for k in 0..n {
        let mut pivot = k;
        for i in k + 1..n {
            if a[i * n + i] > a[pivot * n + pivot] {
                pivot = i;
            }
        }
        if a[pivot * n + pivot] <= scale * 1e-12 {
            rank = k;
            if b[k..].iter().any(|x| x.abs() > tolerance) {
                return Err(PhysicsError::InconsistentConstraints);
            }
            break;
        }
        for j in 0..n {
            a.swap(k * n + j, pivot * n + j);
        }
        for i in 0..n {
            a.swap(i * n + k, i * n + pivot);
        }
        b.swap(k, pivot);
        permutation.swap(k, pivot);
        for i in k + 1..n {
            let multiplier = a[i * n + k] / a[k * n + k];
            for j in k + 1..n {
                a[i * n + j] -= multiplier * a[k * n + j];
            }
            b[i] -= multiplier * b[k];
            a[i * n + k] = 0.0;
        }
    }
    let mut solution = vec![0.0; n];
    for i in (0..rank).rev() {
        solution[i] = (b[i]
            - (i + 1..rank)
                .map(|j| a[i * n + j] * solution[j])
                .sum::<f64>())
            / a[i * n + i];
    }
    let mut output = vec![0.0; n];
    for i in 0..n {
        output[permutation[i]] = solution[i];
    }
    Ok(output)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn bilateral(jacobian: Vec<Vec<f64>>, target: Vec<f64>) -> ConstraintBlock {
        ConstraintBlock {
            bounds: vec![
                ImpulseBounds {
                    minimum: f64::NEG_INFINITY,
                    maximum: f64::INFINITY
                };
                target.len()
            ],
            jacobian,
            target,
            friction: None,
        }
    }

    #[test]
    fn impulse_at_light_wheel_accelerates_the_coupled_chassis() {
        // x is chassis translation; q is wheel displacement relative to chassis.
        let factor = DynamicsFactor::new(&[101.0, 1.0, 1.0, 1.0], 2).unwrap();
        let blocks = [bilateral(
            vec![vec![1.0, 1.0], vec![0.0, 1.0]],
            vec![1.0, 0.0],
        )];
        let result = solve_constraints(&factor, &blocks, 8, 1e-10).unwrap();
        assert!(result.converged);
        assert!((result.velocity_change[0] - 1.0).abs() < 1e-10);
        assert!(result.velocity_change[1].abs() < 1e-10);
        assert!((result.impulses[0] - 101.0).abs() < 1e-9);
    }

    #[test]
    fn duplicate_loop_rows_preserve_response_and_inconsistent_rows_fail() {
        let factor = DynamicsFactor::new(&[2.0], 1).unwrap();
        let mut block = bilateral(vec![vec![1.0], vec![1.0]], vec![3.0, 3.0]);
        let result = solve_constraints(&factor, &[block.clone()], 8, 1e-10).unwrap();
        assert_eq!(result.velocity_change, [3.0]);
        block.target[1] = 4.0;
        assert_eq!(
            solve_constraints(&factor, &[block], 8, 1e-10).unwrap_err(),
            PhysicsError::InconsistentConstraints
        );
    }

    #[test]
    fn unilateral_support_cannot_pull_a_separating_body() {
        let factor = DynamicsFactor::new(&[2.0], 1).unwrap();
        let mut block = bilateral(vec![vec![1.0]], vec![-1.0]);
        block.bounds[0].minimum = 0.0;
        let result = solve_constraints(&factor, &[block], 8, 1e-10).unwrap();
        assert!(result.converged);
        assert_eq!(result.velocity_change, [0.0]);
    }

    #[test]
    fn coupling_to_a_clamped_contact_cannot_falsely_converge() {
        // W = [[2, 1], [1, 2]]. Clipping W^-1 * [-1, 1] gives [0, 1],
        // which leaves a nonzero residual on the active second contact.
        let factor =
            DynamicsFactor::new(&[2.0 / 3.0, -1.0 / 3.0, -1.0 / 3.0, 2.0 / 3.0], 2).unwrap();
        let mut block = bilateral(vec![vec![1.0, 0.0], vec![0.0, 1.0]], vec![-1.0, 1.0]);
        for bounds in &mut block.bounds {
            bounds.minimum = 0.0;
        }
        let result = solve_constraints(&factor, &[block], 128, 1e-10).unwrap();
        assert!(result.converged);
        assert!(result.impulses[0].abs() < 1e-10);
        assert!((result.impulses[1] - 0.5).abs() < 1e-10);
        assert!((result.velocity_change[1] - 1.0).abs() < 1e-10);
    }

    #[test]
    fn friction_impulse_obeys_the_circular_coulomb_bound() {
        let factor =
            DynamicsFactor::new(&[1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0], 3).unwrap();
        let mut block = bilateral(
            vec![
                vec![1.0, 0.0, 0.0],
                vec![0.0, 1.0, 0.0],
                vec![0.0, 0.0, 1.0],
            ],
            vec![2.0, 3.0, 4.0],
        );
        block.friction = Some(0.5);
        block.bounds[0].minimum = 0.0;
        let result = solve_constraints(&factor, &[block], 8, 1e-10).unwrap();
        assert!(result.converged);
        assert!((result.impulses[1].hypot(result.impulses[2]) - 1.0).abs() < 1e-12);
    }

    #[test]
    fn contradictory_friction_bounds_are_rejected_before_projection() {
        let factor = DynamicsFactor::new(&[1.0], 1).unwrap();
        let mut block = bilateral(vec![vec![1.0]; 3], vec![0.0; 3]);
        block.friction = Some(0.5);
        block.bounds[0] = ImpulseBounds {
            minimum: -1.0,
            maximum: -1.0,
        };
        assert_eq!(
            solve_constraints(&factor, &[block], 8, 1e-10).unwrap_err(),
            PhysicsError::InvalidConstraints
        );
    }

    #[test]
    fn large_contact_sets_use_implicit_response_and_repeat_exactly() {
        let factor = DynamicsFactor::new(&[2.0], 1).unwrap();
        for count in [128, 129] {
            let blocks = vec![bilateral(vec![vec![1.0]], vec![1.0]); count];
            let a = solve_constraints(&factor, &blocks, 8, 1e-10).unwrap();
            let b = solve_constraints(&factor, &blocks, 8, 1e-10).unwrap();
            assert!(a.converged);
            if count <= 128 {
                assert_eq!(a.factor_solves, count + 1);
            }
            assert_eq!(
                a.response_storage,
                if count <= 128 { count * count } else { 0 }
            );
            assert_eq!(a.velocity_change, b.velocity_change);
            assert_eq!(a.impulses, b.impulses);
            assert!((a.velocity_change[0] - 1.0).abs() < 1e-12);
        }
    }
}
