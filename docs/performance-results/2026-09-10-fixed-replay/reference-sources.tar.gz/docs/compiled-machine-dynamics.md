# Compiled machine dynamics redesign

Status: baseline repair and a CPU algebra experiment are implemented. The
redesign is **not complete**, and no application, vehicle, or scale acceptance
gate has passed. The existing GPU runtime remains authoritative. No superseded
runtime has been removed.

## Agent execution checkpoint

This document is the durable execution plan. Keep user-facing updates brief;
record implementation details, commands, failures, and acceptance evidence here
or in the linked experiment records. The user reaffirmed the full redesign on
2026-09-10; completing the algebra experiment does not complete that request.

All stages below remain open. Execute them in order, allowing prerequisite
interface work early. Do not replace a physical or integrated gate with a
microbenchmark, relax tolerances, or claim an unexecuted hardware test passed.

1. **Trustworthy application baseline.** Preserve the complete reference outside
   `target` before cleaning. Build the reference app from frozen sources and
   freeze the saved world, starting state, tick-indexed input, terrain, camera,
   resolution, presentation settings, adapter, and binary identity. Complete
   execution accounting within portable binding limits. Record per-stage CPU/GPU
   execution, transfers, publication and presentation latency, critical-path
   latency, allocations, scratch memory, contacts, iterations, and dispatches.
   Exit with reproducible foreground captures and automated detection of drops,
   backlog, incomplete execution, and invalid publications. Existing failing
   trajectories are regression inputs, not physical reference solutions.
2. **Complete CPU tick.** Introduce the minimum shared runtime interface now so
   benchmark and app can exercise the same implementation: state, tick-indexed
   commands, topology/terrain generations, completed snapshots, and diagnostics.
   Implement and verify free motion/orientation and velocity-dependent forces;
   impulses, bounded drives/back-driving, suspension and stops; loop constraints
   and rank deficiency; real manifolds, restitution, static/kinetic friction and
   rolling resistance; split position correction; then validation and bounded
   retries from unchanged pre-tick state. Exit only with analytic/converged
   physical regressions passing and repeatable completed-state hashes.
3. **Actual driven-car decision.** Use the frozen car, real finite terrain,
   materials, and driving script. Cover drops, mass ratios, steering under load,
   suspension limits, braking, and impacts. Compare 1/2/4/8 substeps at 60 Hz;
   choose by physical acceptance, not frame time. Verify small-W iterations do
   no repeated machine factor solves. Exit with foreground A/B/B/A evidence for
   both >=10x lower physics p95 and <=1 ms complete physics p95, including
   collision and validated publication. If it fails, retain evidence, profile
   the bottleneck, and keep this milestone open.
4. **Scaling, collision, residency, and sleeping.** Replace dense generalized
   factors with articulated/sparse operations, checked against the dense
   reference. Reuse symbolic topology and scratch, refresh numerical factors,
   retain the 128-row contact-response storage boundary, and test singular loops
   and changing contacts. Implement the collision/terrain/sleeping work below.
   Exit when 32 vehicles, a 256-joint machine with loops/contacts, and 10,000
   resting bodies through disturbance/waking each pass the <=4 ms physics p95
   and physical gates. Readiness holds count against acceptance.
5. **Application and persistent rendering.** Integrate completed snapshots and
   interpolation, persistent construction transforms, terrain buffers/indirect
   rendering, then frustum and conservative occlusion culling. Evaluate TAA and
   material caching separately against fixed visual comparisons. Bound queued
   rendering and separate presentation waits from publication. Exit first at
   native 60 FPS with equivalent perceived quality; pursue 120 FPS/8.33 ms p95
   as the stretch gate. Reject visually failing candidates.
6. **Portable GPU formulation.** Port the proven dynamics with independent small
   islands, staged large trees, deterministic ordering, and explicit global
   dispatch dependencies. Keep whole-scene backend selection at load time.
   Exit with same-backend repeatability, cross-backend physical-bound agreement,
   complete execution coverage, and serialized recorded hardware results.
7. **Final acceptance and retirement.** Repeat matched integrated runs and the
   unchanged dense_100k, loops_100k, and separate 1080p gates below. Run workspace
   tests, shader validation, Clippy, and formatting; report existing failures
   explicitly. Remove superseded paths only after replacements pass.

Each stage must retain reviewable source, exact reproducible commands, raw
measurements, physical errors, and an explicit pass/fail decision. Update this
checkpoint as work advances. The immediate next work is stage 1, then the
complete CPU tick and actual-car proof; no application speedup is established.

Stage 1 continuation (2026-09-10): the complete original reference is now copied
and hash-verified at `.physics-reference/2026-09-09/`, outside Cargo's cleanable
directory. The original application has also been rebuilt from that archive;
`app-rebuilt-identity.json` identifies its executable. It retains the historical
background capture protocol, so it is not the repaired foreground baseline.

The repaired baseline harness adds explicit foreground capture, isolated world
stores, source/binary/asset/world identities, per-dispatched-tick driving input,
initial camera/state identity, completed-state hashes, and terrain-readiness hold
events. Foreground warm-up renders the loaded state without advancing physics;
the unchanged script then includes 180 settling ticks before throttle. This is
an explicit workload change from historical wall-time warm-up and must be used
on both sides of future comparisons. The sequencer's automatic gearbox still
uses available published speeds; completed-state repeatability must be measured,
not inferred from deterministic input scheduling.

Use `scripts/build-performance-reference.py --output .physics-reference/NAME`
to copy sources and build that copy with locked offline dependencies. Use the
resulting executable, `identity.json`, and `source/crates/mechanic-app` asset root
with `scripts/run-background-capture.py --foreground --drive --identity ...`.
The launcher rejects lost focus, dimension/presentation changes, mismatched
assets or binaries, and missing per-tick scripted inputs. Passing this capture
protocol does not establish full kernel coverage or physical acceptance.

Two source-matched foreground car runs are now retained in the
[foreground baseline record](performance-results/2026-09-10-foreground-baseline/README.md).
They meet the focus/resolution capture protocol but run at approximately 14.2
FPS and 24 physics TPS, with 35.7-36.1 ms GPU physics p95, over 1,300 dropped
ticks, and over 350 terrain-readiness hold events each. The same initial state
and camera produce different completed-state hashes at tick 12, before throttle
or the first dropped tick. Initial resident terrain identity is not yet captured,
so the source of that divergence remains open. Every combined render GPU sample
is partial/reversed; affected spans are unavailable. No acceptance gate passed.

Immediate stage-1 follow-up: finish capture closing/draining and fixed-simulated-
duration replay, identify initial terrain and effective drive rows, isolate the
tick-12 divergence, and complete kernel coverage evidence. Preserve the old
solver's failures as replacement regressions; do not require it to become a
physically correct reference trajectory. Source-matched builds must use fresh
isolated target directories after the observed shared-cache stale-artifact failure.

Fixed-duration replay continuation: capture schema 3 closes submissions at a frame
boundary and records subsequent readbacks/publications in a drain phase. It
finishes only after the target tick is published and the readback ring is empty;
a ten-second drain deadline invalidates an incomplete capture. Renderer samples
from drain are separated from measurement, while replay throughput includes the
drain's wall time. Historical schema-2 evidence retains its archived tools.
`--foreground --drive --replay-ticks N` requests 1..3600 contiguous ticks at the
same 60 Hz external clock. Replay retains overdue ticks and counts real elapsed
time during terrain holds; slow runs therefore expose growing backlog instead
of silently changing the physical workload. Normal application scheduling is
unchanged. Initial packed-terrain and device-layout fingerprints, plus effective
drive-row hashes for each tick, help localize the earlier divergence. Verification
of this continuation is in progress; no physical/performance gate is implied.

## Preserved reference

The dirty worktree was frozen before edits. The source archive, per-file hashes,
world hashes, commands, and reproduced failures are in
[the experiment record](performance-results/2026-09-10-compiled-dynamics/README.md).
The complete worktree and binaries are also retained locally under
`target/physics-reference/2026-09-09/`. That directory must be preserved before
running `cargo clean`; the smaller source archive in the experiment record
survives a clean. Existing app binaries are identified but their correspondence
to the frozen sources is unverified; the benchmark binary was rebuilt from the
frozen worktree before any source edits.

The new capture schema records a contiguous submission sequence separately from
the scheduler's possibly discontinuous tick number. Completions carry the
sequence from submission, including submissions before capture. Scheduler drops
are recorded as exact tick ranges. The summarizer validates each stream and
overlapping submission/completion identities; submitted gaps must match their
drop ranges. Boundary readbacks, pending submissions, completed-interval skipped
ticks, and drops during capture are separate quantities. Old captures cannot
prove this accounting and are explicitly rejected; no compatibility reader was
added. Asynchronous publication now waits for the oldest pending mapping rather
than allowing a later callback to overtake it.

GPU diagnostics grow from 32 to 48 bytes, with the per-body contact-count tail
moving from word 8 to word 12. Rust and WGSL change together. Device-written
stage markers and integration, bearing-validation, and published-body counters
replace inference from scenario names. Stage entry is only partial evidence:
the fused contact kernel already consumes the portable eight-storage-buffer
limit and has no diagnostic binding. Internal tree/closure kernels are also not
individually instrumented. `kernel_coverage_complete` therefore remains false
for all scenarios, including smoke; the benchmark reports measurements but
returns a failed gate until complete execution coverage can be proven. This
deliberately removes the old small-scenario allowlist. Instrumentation costs are
included in candidate timings; old and instrumented timings are not a solver A/B.
Timestamp readback accounting now includes all 28 returned timestamp words.

## CPU experiment

`CompiledCreation::dynamics` contains direct body/joint lookups, component ranges,
forward and reverse traversals, local spatial inertia, generalized velocity
ranges, and a compressed elimination tree. Loop sparsity is represented by two
ancestor-chain heads per closure. Symbolic storage is linear; it does not expand
long paths or allocate a dense matrix for 100,000-body constructions.

`mechanic-physics` reconstructs tree poses and point Jacobians, assembles coupled
generalized inertia in double precision, projects uniform gravity, and factors
positive-definite effective dynamics. A caller can include an implicit diagonal
`dt*c + dt²*k`. It does not yet compute velocity-dependent forces, drive budgets,
spring forces, or integrate and validate a tick. Its dense generalized matrix is
explicitly limited to 512 velocities; this is a reference implementation, not the
eventual articulated factorization for large machines.

The constraint experiment constructs `W = J H⁻¹ Jᵀ` using factor solves. Through
128 scalar rows it retains W and changes only constraint-space values during
the repeated solve, reconstructing generalized motion once afterward. Above
128 rows it applies response through factor solves without allocating W.
Individual block diagonals are retained (each block is bounded to 128 rows), so
total block scratch is linear in the number of rows, with that fixed bound.
Bounded blocks use a deterministic projected gradient with a spectral-radius
bound; bilateral blocks use rank-revealing elimination and reject inconsistent
dependent equations. Friction supports a circular Coulomb disk with one supplied
coefficient; static/kinetic transitions and rolling resistance remain open.
Residuals are projected constraint residuals, not just absence of numeric flags.

The saved car fixture comes from the frozen world's generation 11. The
`compiled-response` benchmark uses its authored bind pose with synthetic
horizontal support probes. It times assembly, factorization, row construction,
and impulse solving, and checks repeated response hashes. It **does not** measure
collision detection, terrain, actual support manifolds, motion, commands, or
publication. Its timings cannot establish the 1 ms physics-tick gate or a car
speedup. The first variant and its non-converged result are retained in the
experiment record.

Run the algebra experiment with:

```sh
cargo run -p mechanic-bench --bin compiled-response --release --offline -- \
  crates/mechanic-bench/tests/fixtures/driven_car_instance.ron
```

An optional second argument bounds block sweeps (default 256). A failure emits
the measured record and exits unsuccessfully. The physical gate stays false
even when the algebra converges.

The formulation follows the established generalized-inertia and constraint
elimination descriptions in [Featherstone's spatial dynamics overview](https://royfeatherstone.org/spatial/v2/)
and [MuJoCo's computation documentation](https://mujoco.readthedocs.io/en/stable/computation/index.html).
Substeps with persistent anchors remain an experiment motivated by
[Box2D's solver comparisons](https://box2d.org/posts/2024/02/solver2d/).
No external solver implementation was copied.

## Delivery and acceptance still required

1. Finish baseline coverage instrumentation; freeze a source-matched driven-car
   foreground baseline with terrain, input, camera, native resolution, and
   presentation settings. Preserve car-drop, four-bar, and dense growth fixtures.
2. Complete the CPU tick experiment: coupled velocity-dependent forces, bounded
   drives and stops, implicit spring/damper forces, loop constraints, friction
   transitions, rolling resistance, real manifolds, split position correction,
   persistent contacts, and one/two/four/eight substep comparisons. Retry failed
   unpublished ticks at bounded finer substeps, retaining the last valid snapshot
   after final failure. Then prove the actual driven-car improvement.
3. Add compound broadphase/local BVHs, static/sleeping/moving partitions, moving
   refits, deterministic GPU radix rebuilds with scene-relative quantization,
   incremental terrain-chunk hierarchy/generations, swept residency including
   angular reach/preparation latency, readiness holds, and whole-island sleeping
   with deterministic waking. Preserve finite terrain, holes, seams, and materials.
4. Add `PhysicsWorld`, explicit whole-scene backend selection, tick-indexed drives
   and impulses, topology/terrain generations, completed snapshots, diagnostics,
   and application integration. Implement persistent construction/terrain rendering
   and interpolation. Test frustum then conservative occlusion culling, native TAA
   with motion/history invalidation and unfiltered UI, and bounded chunk-local
   unlit material caching. Keep normal contributions and verify seams/mips.
   Separate publication latency from presentation waits and bound queued work.
5. Implement the same formulation on portable GPU: independent small islands in
   workgroups, staged large trees, deterministic batches/reductions, no device-wide
   dependencies hidden behind workgroup barriers, and no per-tick backend migration.
6. Run matched foreground A/B/B/A acceptance and visual comparisons. Remove old
   paths only when replacements pass; retain failures with milestones open.

The external physics clock stays at 60 Hz. All physics targets include collision,
solving, and validated publication, with CPU/GPU work, transfers, and publication
latency reported separately:

| Workload | Required target |
| --- | --- |
| Existing driven car on streamed terrain | ≥10× improvement and ≤1 ms physics p95 |
| 32 interacting vehicles | ≤4 ms physics p95 |
| One 256-joint machine with contacts and representative loops | ≤4 ms physics p95 |
| 10,000 mostly resting bodies with disturbance/waking | ≤4 ms physics p95 |
| Native 4112×2524 application, equivalent perceived quality | 60 FPS intermediate; 120 FPS and ≤8.33 ms frame p95 stretch |

Physical proof must cover free motion, momentum, torque/back-driving, spring
equilibrium/damping/stops, static/kinetic friction, restitution and rolling
resistance against analytic or converged references. Preserve 0.01 mm anchor and
0.001° axis limits and applicable rigid-terrain impact limits of 5 mm maximum and
2 mm settling penetration. Include fast/rotational impacts, wheel/chassis mass
ratios, singular loops, seams, delays, origin rebases, edits, and waking. Repeated
fixed-input state hashes must match within each backend, with physical-bound
agreement across CPU and GPU. Algebra response hashes alone do not establish it.

Integrated acceptance requires sustained 60 TPS, zero dropped ticks, no growing
backlog, and zero invalid publications. Terrain readiness holds count as missed
performance acceptance. Native visual checks include driving, disocclusion, thin
geometry, transitions, close terrain, and editing for blur/ghosting/shimmer/popping.
`dense_100k` and `loops_100k` retain their exact active counts, sleeping restrictions,
complete execution coverage, 5-second warm-up/30-second measurement, 60 TPS and
≤16.67 ms GPU p95. The separate 1080p ≤5 ms integrated frame gate remains intact.
