//! Coupled impulse response through factor solves, with bounded contact storage.

use crate::PhysicsError;
mod newton;

/// Largest scalar constraint count for explicit contact-response storage.
pub const DENSE_CONTACT_ROWS: usize = 128;

/// Positive-definite effective dynamics factored once per substep.
#[derive(Clone, Debug)]
pub struct DynamicsFactor {
    size: usize,
    lower: Vec<f64>,
}

impl DynamicsFactor {
    /// Factors a symmetric row-major effective mass matrix. No inverse is formed.
    ///
    /// # Errors
    /// Rejects malformed, non-finite, asymmetric, or non-positive dynamics.
    pub fn new(matrix: &[f64], size: usize) -> Result<Self, PhysicsError> {
        if size.checked_mul(size) != Some(matrix.len()) || matrix.iter().any(|x| !x.is_finite()) {
            return Err(PhysicsError::InvalidDynamics);
        }
        let mut lower = vec![0.0; matrix.len()];
        for row in 0..size {
            for column in 0..=row {
                let a = matrix[row * size + column];
                let b = matrix[column * size + row];
                if (a - b).abs() > 1e-12 * a.abs().max(b.abs()).max(1.0) {
                    return Err(PhysicsError::InvalidDynamics);
                }
                let value = a
                    - (0..column)
                        .map(|k| lower[row * size + k] * lower[column * size + k])
                        .sum::<f64>();
                lower[row * size + column] = if row == column {
                    if value <= 0.0 || !value.is_finite() {
                        return Err(PhysicsError::InvalidDynamics);
                    }
                    value.sqrt()
                } else {
                    value / lower[column * size + column]
                };
            }
        }
        Ok(Self { size, lower })
    }

    /// Applies inverse dynamics in-place to a generalized impulse.
    ///
    /// # Errors
    /// Rejects incorrect row counts or non-finite inputs/results.
    pub fn solve(&self, values: &mut [f64]) -> Result<(), PhysicsError> {
        if values.len() != self.size || values.iter().any(|x| !x.is_finite()) {
            return Err(PhysicsError::InvalidDynamics);
        }
        for row in 0..self.size {
            let previous = (0..row)
                .map(|k| self.lower[row * self.size + k] * values[k])
                .sum::<f64>();
            values[row] = (values[row] - previous) / self.lower[row * self.size + row];
        }
        for row in (0..self.size).rev() {
            let next = (row + 1..self.size)
                .map(|k| self.lower[k * self.size + row] * values[k])
                .sum::<f64>();
            values[row] = (values[row] - next) / self.lower[row * self.size + row];
        }
        if values.iter().any(|x| !x.is_finite()) {
            return Err(PhysicsError::InvalidDynamics);
        }
        Ok(())
    }
}

/// Bounds on one scalar row. Bilateral rows use infinite limits.
#[derive(Clone, Copy, Debug)]
pub struct ImpulseBounds {
    /// Minimum allowed impulse.
    pub minimum: f64,
    /// Maximum allowed impulse.
    pub maximum: f64,
}

/// Coulomb/rolling law for one point in a coupled contact manifold.
#[derive(Clone, Copy, Debug)]
pub struct ContactFriction {
    /// Coefficient available when a contact can remain at rest.
    pub static_coefficient: f64,
    /// Coefficient while sliding, no greater than the static coefficient.
    pub kinetic_coefficient: f64,
    /// Whether the contact is already sliding at the beginning of this solve.
    pub sliding: bool,
    /// Optional rolling-resistance coefficient times effective radius, in metres.
    /// Adds two angular rows after the normal and two tangential rows.
    pub rolling_length: Option<f64>,
}

impl ContactFriction {
    fn rows(self) -> usize {
        if self.rolling_length.is_some() { 5 } else { 3 }
    }
}

/// One coupled contact manifold, drive, stop, or loop block.
#[derive(Clone, Debug)]
pub struct ConstraintBlock {
    /// Generalized Jacobian rows. All rows must match the dynamics dimension.
    pub jacobian: Vec<Vec<f64>>,
    /// Required change in row velocity before constraint impulses.
    pub target: Vec<f64>,
    /// Per-row impulse bounds.
    pub bounds: Vec<ImpulseBounds>,
    /// Ordered contact points, each with normal/tangent/tangent and optionally
    /// two rolling rows. Empty for drives, stops, and bilateral loop blocks.
    /// Normal lower bounds are zero; tangent/rolling bounds are infinite.
    pub contacts: Vec<ContactFriction>,
}

/// Result of a deterministic block projected solve.
#[derive(Clone, Debug)]
pub struct ConstraintSolution {
    /// Safeguarded Newton proposals, separate from block sweeps.
    pub newton_attempts: usize,
    /// Newton proposals accepted within the bounded physical-residual history.
    pub newton_accepts: usize,
    /// Krylov Jacobian applications; each applies the contact response once.
    pub newton_applications: usize,
    /// Attempted 1/3/5-row numerical preconditioner factorizations.
    pub newton_local_factorizations: usize,
    /// Bounded generalized Newton matrix factorizations.
    pub newton_generalized_factorizations: usize,
    /// Peak scalar storage for reduced Newton matrices (at most 64 generalized rows).
    pub newton_reduced_storage: usize,
    /// Bounded dense contact-space Newton factorizations.
    pub newton_contact_factorizations: usize,
    /// Peak scalar storage of the dense contact Newton matrix.
    pub newton_contact_storage: usize,
    /// Candidate residual evaluations during bounded Newton backtracking.
    pub newton_line_searches: usize,
    /// Final sliding state in block/contact-point order.
    pub sliding: Vec<bool>,
    /// Static contacts whose required impulse exceeded the static cone.
    pub friction_transitions: usize,
    /// Generalized velocity change; apply only after checking convergence.
    pub velocity_change: Vec<f64>,
    /// Scalar impulses in block/row order.
    pub impulses: Vec<f64>,
    /// Maximum projected velocity residual.
    pub residual: f64,
    /// Number of completed block sweeps.
    pub iterations: usize,
    /// Whether the residual reached the requested threshold.
    pub converged: bool,
    /// Scalar slots allocated for the explicit response matrix (zero above 128 rows).
    pub response_storage: usize,
    /// Inverse-dynamics applications, including response preparation and final motion.
    pub factor_solves: usize,
}

struct BlockLayout {
    first: usize,
    diagonal: Vec<f64>,
    scale: f64,
}

/// Solve `J H⁻¹ Jᵀ λ = target` subject to block bounds. Above 128 scalar rows,
/// responses use factor solves and linear scratch storage instead of a dense W.
///
/// # Errors
/// Rejects malformed constraints and inconsistent dependent bilateral rows.
pub fn solve_constraints(
    factor: &DynamicsFactor,
    blocks: &[ConstraintBlock],
    max_iterations: usize,
    tolerance: f64,
) -> Result<ConstraintSolution, PhysicsError> {
    let mut prepared = PreparedConstraints::new(factor, blocks)?;
    let targets = blocks
        .iter()
        .flat_map(|b| b.target.iter().copied())
        .collect::<Vec<_>>();
    let mut solution = prepared.solve(&targets, max_iterations, tolerance)?;
    solution.factor_solves += prepared.preparation_factor_solves();
    Ok(solution)
}

/// Pose-local contact/drive/stop response retained across nonlinear force updates.
/// Holds a borrow of its numerical factor, preventing use after refactorization.
/// Jacobians, bounds, and friction are fixed; targets may change between solves.
pub struct PreparedConstraints<'a> {
    factor: &'a DynamicsFactor,
    blocks: Vec<ConstraintBlock>,
    layout: Vec<BlockLayout>,
    response: Vec<f64>,
    preparation_solves: usize,
}

impl<'a> PreparedConstraints<'a> {
    /// Prepares coupled response once, retaining the 128-row dense storage bound.
    ///
    /// # Errors
    /// Rejects malformed blocks or invalid numerical response.
    pub fn new(
        factor: &'a DynamicsFactor,
        blocks: &[ConstraintBlock],
    ) -> Result<Self, PhysicsError> {
        let mut rows = Vec::new();
        let mut layout = Vec::new();
        for block in blocks {
            let count = block.jacobian.len();
            if count == 0
                || count > DENSE_CONTACT_ROWS
                || block.target.len() != count
                || block.bounds.len() != count
                || block
                    .jacobian
                    .iter()
                    .any(|row| row.len() != factor.size || row.iter().any(|x| !x.is_finite()))
                || block.target.iter().any(|x| !x.is_finite())
                || block.bounds.iter().any(|b| {
                    b.minimum.is_nan()
                        || b.maximum.is_nan()
                        || b.minimum > b.maximum
                        || b.minimum == f64::INFINITY
                        || b.maximum == f64::NEG_INFINITY
                })
                || !valid_contacts(block)
            {
                return Err(PhysicsError::InvalidConstraints);
            }
            layout.push(BlockLayout {
                first: rows.len(),
                diagonal: vec![0.0; count * count],
                scale: 0.0,
            });
            rows.extend(block.jacobian.iter());
        }
        let count = rows.len();
        let mut response = if count <= DENSE_CONTACT_ROWS {
            vec![0.0; count * count]
        } else {
            Vec::new()
        };
        let mut factor_solves = 0;
        let mut scratch = vec![0.0; factor.size];
        for (block, info) in blocks.iter().zip(&mut layout) {
            let size = block.jacobian.len();
            for column in 0..size {
                scratch.copy_from_slice(rows[info.first + column]);
                factor.solve(&mut scratch)?;
                factor_solves += 1;
                for row in 0..size {
                    info.diagonal[row * size + column] = dot(rows[info.first + row], &scratch);
                }
                if !response.is_empty() {
                    for row in 0..count {
                        response[row * count + info.first + column] = dot(rows[row], &scratch);
                    }
                }
            }
            info.scale = block_scale(&info.diagonal, size);
        }

        Ok(Self {
            factor,
            blocks: blocks.to_vec(),
            layout,
            response,
            preparation_solves: factor_solves,
        })
    }

    /// Inverse-dynamics applications performed during response preparation.
    pub fn preparation_factor_solves(&self) -> usize {
        self.preparation_solves
    }

    /// Solves with new flattened target row velocities. Returned factor-solve
    /// counts cover this solve only; preparation is reported separately.
    ///
    /// # Errors
    /// Rejects invalid targets/settings or inconsistent dependent equations.
    pub fn solve(
        &mut self,
        targets: &[f64],
        max_iterations: usize,
        tolerance: f64,
    ) -> Result<ConstraintSolution, PhysicsError> {
        self.solve_from(targets, None, max_iterations, tolerance)
    }

    /// Solves from a supplied impulse estimate, projected into the current bounds.
    /// The caller must map contact identities/frames before reuse across geometry
    /// updates. Reusing a result within this immutable pose-local response needs
    /// no geometry remapping. All residuals are recomputed for the new targets.
    ///
    /// # Errors
    /// Rejects invalid targets/settings, malformed warm starts, or inconsistent rows.
    #[allow(clippy::too_many_lines)] // Keep sweep updates and final residual verification together.
    pub fn solve_from(
        &mut self,
        targets: &[f64],
        initial_impulses: Option<&[f64]>,
        max_iterations: usize,
        tolerance: f64,
    ) -> Result<ConstraintSolution, PhysicsError> {
        let count = self.blocks.iter().map(|b| b.target.len()).sum::<usize>();
        if targets.len() != count
            || targets.iter().any(|v| !v.is_finite())
            || initial_impulses.is_some_and(|values| {
                values.len() != count || values.iter().any(|value| !value.is_finite())
            })
            || max_iterations == 0
            || !tolerance.is_finite()
            || tolerance <= 0.0
        {
            return Err(PhysicsError::InvalidConstraints);
        }
        if count == 0 {
            return Ok(ConstraintSolution {
                newton_attempts: 0,
                newton_accepts: 0,
                newton_applications: 0,
                newton_local_factorizations: 0,
                newton_generalized_factorizations: 0,
                newton_reduced_storage: 0,
                newton_contact_factorizations: 0,
                newton_contact_storage: 0,
                newton_line_searches: 0,
                sliding: Vec::new(),
                friction_transitions: 0,
                velocity_change: vec![0.0; self.factor.size],
                impulses: Vec::new(),
                residual: 0.0,
                iterations: 0,
                converged: true,
                response_storage: 0,
                factor_solves: 0,
            });
        }
        let mut cursor = 0;
        for block in &mut self.blocks {
            let length = block.target.len();
            block
                .target
                .copy_from_slice(&targets[cursor..cursor + length]);
            cursor += length;
        }
        let factor = self.factor;
        let blocks = self.blocks.as_slice();
        let layout = &self.layout;
        let response = &self.response;
        let mut sliding = blocks
            .iter()
            .map(|block| {
                block
                    .contacts
                    .iter()
                    .map(|point| point.sliding)
                    .collect::<Vec<_>>()
            })
            .collect::<Vec<_>>();
        let mut friction_transitions = 0;
        let mut pending_mode_solve = false;
        let rows = blocks
            .iter()
            .flat_map(|b| b.jacobian.iter())
            .collect::<Vec<_>>();
        let mut scratch = vec![0.0; factor.size];
        let mut factor_solves = 0;
        let mut impulses = initial_impulses.map_or_else(|| vec![0.0; count], <[f64]>::to_vec);
        let mut change = vec![0.0; factor.size];
        let mut row_change = vec![0.0; count];
        if initial_impulses.is_some() {
            for ((block, info), modes) in blocks.iter().zip(layout).zip(&sliding) {
                project(
                    block,
                    modes,
                    &mut impulses[info.first..info.first + block.jacobian.len()],
                );
            }
            if response.is_empty() {
                (change, row_change) = response_motion(factor, &rows, &impulses)?;
                factor_solves += 1;
            } else {
                for (out, row) in row_change.iter_mut().zip(response.chunks_exact(count)) {
                    *out = dot(row, &impulses);
                }
            }
        }
        let mut residual;
        let mut iterations = 0;
        let mut newton_attempts = 0;
        let mut newton_shift = 1e-3_f64;
        let mut newton_accepts = 0;
        let mut newton_applications = 0;
        let mut newton_local_factorizations = 0;
        let mut newton_generalized_factorizations = 0;
        let mut newton_reduced_storage = 0;
        let mut newton_contact_factorizations = 0;
        let mut newton_contact_storage = 0;
        let mut newton_line_searches = 0;
        let mut residual_history = std::collections::VecDeque::new();
        for iteration in 1..=max_iterations {
            pending_mode_solve = false;
            for ((block, info), modes) in blocks.iter().zip(layout).zip(&sliding) {
                let size = block.jacobian.len();
                let rhs = (0..size)
                    .map(|row| {
                        block.target[row]
                            - if response.is_empty() {
                                dot(rows[info.first + row], &change)
                            } else {
                                row_change[info.first + row]
                            }
                    })
                    .collect::<Vec<_>>();
                let delta = block_delta(block, &info.diagonal, info.scale, &rhs, tolerance)?;
                let mut candidate = (0..size)
                    .map(|row| impulses[info.first + row] + delta[row])
                    .collect::<Vec<_>>();
                project(block, modes, &mut candidate);
                scratch.fill(0.0);
                for row in 0..size {
                    let difference = candidate[row] - impulses[info.first + row];
                    impulses[info.first + row] = candidate[row];
                    if response.is_empty() {
                        for (out, &j) in scratch.iter_mut().zip(rows[info.first + row]) {
                            *out += j * difference;
                        }
                    } else {
                        for (index, out) in row_change.iter_mut().enumerate() {
                            *out += response[index * count + info.first + row] * difference;
                        }
                    }
                }
                if response.is_empty() {
                    factor.solve(&mut scratch)?;
                    factor_solves += 1;
                    for (out, &delta) in change.iter_mut().zip(&scratch) {
                        *out += delta;
                    }
                }
            }
            // Re-evaluate every block against the final iterate, not the value seen
            // before later blocks changed it. Raw residuals are nonzero at active bounds.
            if response.is_empty() {
                for (out, row) in row_change.iter_mut().zip(&rows) {
                    *out = dot(row, &change);
                }
            }
            residual =
                projected_residual(blocks, layout, &row_change, &impulses, &sliding, tolerance)?;
            iterations = iteration;
            if residual > tolerance {
                // A bounded nonmonotone window lets small contact systems cross
                // friction active-set transitions. It never changes the final
                // unshifted residual required for convergence/publication.
                let acceptance_bound = if count <= DENSE_CONTACT_ROWS {
                    residual_history.push_back(residual);
                    if residual_history.len() > 16 {
                        residual_history.pop_front();
                    }
                    residual_history.iter().copied().fold(residual, f64::max)
                } else {
                    residual
                };
                let mut accepted = false;
                for attempt in 0..if count <= DENSE_CONTACT_ROWS { 2 } else { 1 } {
                    newton_attempts += 1;
                    let proposal = newton::direction(
                        factor,
                        blocks,
                        layout,
                        &impulses,
                        &row_change,
                        &sliding,
                        newton_shift,
                        attempt == 1,
                        |trial| {
                            if response.is_empty() {
                                factor_solves += 1;
                                response_motion(factor, &rows, trial)
                                    .ok()
                                    .map(|(_, rows)| rows)
                            } else {
                                Some(
                                    response
                                        .chunks_exact(count)
                                        .map(|row| dot(row, trial))
                                        .collect(),
                                )
                            }
                        },
                    );
                    factor_solves += proposal.factor_solves;
                    newton_contact_factorizations += proposal.contact_factorizations;
                    newton_contact_storage = newton_contact_storage.max(proposal.contact_storage);
                    newton_generalized_factorizations += proposal.generalized_factorizations;
                    newton_reduced_storage = newton_reduced_storage.max(proposal.reduced_storage);
                    newton_applications += proposal.applications;
                    newton_local_factorizations += proposal.local_factorizations;
                    if let Some(direction) = proposal.direction {
                        let mut fraction = 1.0;
                        for backtrack in 0..if count <= DENSE_CONTACT_ROWS { 32 } else { 8 } {
                            newton_line_searches += 1;
                            let mut candidate = impulses
                                .iter()
                                .zip(&direction)
                                .map(|(old, delta)| old + fraction * delta)
                                .collect::<Vec<_>>();
                            for ((block, info), modes) in blocks.iter().zip(layout).zip(&sliding) {
                                project(
                                    block,
                                    modes,
                                    &mut candidate[info.first..info.first + block.jacobian.len()],
                                );
                            }
                            let evaluated = if response.is_empty() {
                                factor_solves += 1;
                                response_motion(factor, &rows, &candidate).ok()
                            } else {
                                Some((
                                    Vec::new(),
                                    response
                                        .chunks_exact(count)
                                        .map(|row| dot(row, &candidate))
                                        .collect(),
                                ))
                            };
                            if let Some((candidate_change, candidate_rows)) = evaluated
                                && let Ok(proposed) = projected_residual(
                                    blocks,
                                    layout,
                                    &candidate_rows,
                                    &candidate,
                                    &sliding,
                                    tolerance,
                                )
                                && proposed < acceptance_bound * (1.0 - 1e-4 * fraction)
                            {
                                impulses = candidate;
                                row_change = candidate_rows;
                                if response.is_empty() {
                                    change = candidate_change;
                                }
                                residual = proposed;
                                newton_accepts += 1;
                                accepted = true;
                                newton_shift = if backtrack == 0 {
                                    (newton_shift * 0.5).max(1e-10)
                                } else {
                                    (newton_shift * 2.0).min(0.1)
                                };
                                break;
                            }
                            fraction *= 0.5;
                        }
                    }
                    if accepted {
                        break;
                    }
                }
                if !accepted {
                    newton_shift = (newton_shift * 10.0).min(0.1);
                }
            }
            if residual <= tolerance {
                // First settle normal loads and the static cones. Switching on
                // an unfinished iterate can falsely declare breakaway merely
                // because support impulses have not yet accumulated.
                let changed = promote_sliding(
                    blocks,
                    layout,
                    &row_change,
                    &impulses,
                    &mut sliding,
                    tolerance,
                );
                friction_transitions += changed;
                pending_mode_solve = changed > 0;
                if changed > 0 {
                    residual_history.clear();
                }
                if changed == 0 {
                    break;
                }
            }
        }
        // Reconstruct body motion only after the repeated contact solve. The dense
        // route never propagates a contact impulse through the machine inside a sweep.
        for ((block, info), modes) in blocks.iter().zip(layout).zip(&sliding) {
            project(
                block,
                modes,
                &mut impulses[info.first..info.first + block.jacobian.len()],
            );
        }
        change.fill(0.0);
        for (row, &impulse) in rows.iter().zip(&impulses) {
            for (out, &j) in change.iter_mut().zip(*row) {
                *out += j * impulse;
            }
        }
        factor.solve(&mut change)?;
        factor_solves += 1;
        for (out, row) in row_change.iter_mut().zip(&rows) {
            *out = dot(row, &change);
        }
        residual = projected_residual(blocks, layout, &row_change, &impulses, &sliding, tolerance)?;
        Ok(ConstraintSolution {
            newton_attempts,
            newton_accepts,
            newton_applications,
            newton_local_factorizations,
            newton_generalized_factorizations,
            newton_reduced_storage,
            newton_contact_factorizations,
            newton_contact_storage,
            newton_line_searches,
            sliding: sliding.into_iter().flatten().collect(),
            friction_transitions,
            velocity_change: change,
            impulses,
            residual,
            iterations,
            converged: residual <= tolerance && !pending_mode_solve,
            response_storage: response.len(),
            factor_solves,
        })
    }
}

fn response_motion(
    factor: &DynamicsFactor,
    rows: &[&Vec<f64>],
    impulses: &[f64],
) -> Result<(Vec<f64>, Vec<f64>), PhysicsError> {
    let mut change = vec![0.0; factor.size];
    for (row, &impulse) in rows.iter().zip(impulses) {
        for (out, &j) in change.iter_mut().zip(*row) {
            *out += j * impulse;
        }
    }
    factor.solve(&mut change)?;
    let row_change = rows.iter().map(|row| dot(row, &change)).collect();
    Ok((change, row_change))
}

fn projected_residual(
    blocks: &[ConstraintBlock],
    layout: &[BlockLayout],
    row_change: &[f64],
    impulses: &[f64],
    sliding: &[Vec<bool>],
    tolerance: f64,
) -> Result<f64, PhysicsError> {
    let mut residual = 0.0_f64;
    for ((block, info), modes) in blocks.iter().zip(layout).zip(sliding) {
        let size = block.jacobian.len();
        let rhs = (0..size)
            .map(|row| block.target[row] - row_change[info.first + row])
            .collect::<Vec<_>>();
        let delta = block_delta(block, &info.diagonal, info.scale, &rhs, tolerance)?;
        let mut candidate = (0..size)
            .map(|row| impulses[info.first + row] + delta[row])
            .collect::<Vec<_>>();
        project(block, modes, &mut candidate);
        for row in 0..size {
            let error = if is_bilateral(block) {
                rhs[row]
            } else {
                info.scale * (candidate[row] - impulses[info.first + row])
            };
            if !error.is_finite() {
                return Err(PhysicsError::InvalidDynamics);
            }
            residual = residual.max(error.abs());
        }
    }
    Ok(residual)
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(a, b)| a * b).sum()
}

fn is_bilateral(block: &ConstraintBlock) -> bool {
    block.contacts.is_empty()
        && block
            .bounds
            .iter()
            .all(|bounds| bounds.minimum == f64::NEG_INFINITY && bounds.maximum == f64::INFINITY)
}

fn block_scale(matrix: &[f64], size: usize) -> f64 {
    matrix
        .chunks_exact(size)
        .map(|row| row.iter().map(|x| x.abs()).sum::<f64>())
        .fold(0.0, f64::max)
        .max(1e-30)
}

fn block_delta(
    block: &ConstraintBlock,
    matrix: &[f64],
    scale: f64,
    rhs: &[f64],
    tolerance: f64,
) -> Result<Vec<f64>, PhysicsError> {
    if is_bilateral(block) {
        return rank_solve(matrix, rhs, tolerance);
    }
    // Reuse the pose-local spectral-radius bound. Clipping an unconstrained
    // W^-1 solution is not a bounded block solve: off-diagonal coupling can
    // falsely report convergence. The contact projection is non-associated
    // Coulomb (normal clamp followed by disks), not an associated cone QP.
    Ok(rhs.iter().map(|value| value / scale).collect())
}

fn valid_contacts(block: &ConstraintBlock) -> bool {
    if block.contacts.is_empty() {
        return true;
    }
    let mut row = 0;
    for law in &block.contacts {
        if !law.static_coefficient.is_finite()
            || !law.kinetic_coefficient.is_finite()
            || law.kinetic_coefficient < 0.0
            || law.static_coefficient < law.kinetic_coefficient
            || law
                .rolling_length
                .is_some_and(|length| !length.is_finite() || length < 0.0)
        {
            return false;
        }
        let count = law.rows();
        let Some(bounds) = block.bounds.get(row..row + count) else {
            return false;
        };
        if bounds[0].minimum != 0.0
            || bounds[1..]
                .iter()
                .any(|b| b.minimum != f64::NEG_INFINITY || b.maximum != f64::INFINITY)
        {
            return false;
        }
        row += count;
    }
    row == block.jacobian.len()
}

fn promote_sliding(
    blocks: &[ConstraintBlock],
    layout: &[BlockLayout],
    row_change: &[f64],
    impulses: &[f64],
    modes: &mut [Vec<bool>],
    tolerance: f64,
) -> usize {
    let mut changed = 0;
    for ((block, info), modes) in blocks.iter().zip(layout).zip(modes) {
        let mut row = 0;
        for (law, sliding) in block.contacts.iter().zip(modes) {
            let remaining_u = block.target[row + 1] - row_change[info.first + row + 1];
            let remaining_v = block.target[row + 2] - row_change[info.first + row + 2];
            if !*sliding
                && impulses[info.first + row] > 0.0
                && remaining_u.hypot(remaining_v) > tolerance * 4.0
            {
                *sliding = true;
                changed += 1;
            }
            row += law.rows();
        }
    }
    changed
}

fn project(block: &ConstraintBlock, sliding: &[bool], values: &mut [f64]) {
    for (value, bounds) in values.iter_mut().zip(&block.bounds) {
        *value = value.clamp(bounds.minimum, bounds.maximum);
    }
    let mut row = 0;
    for (law, &sliding) in block.contacts.iter().zip(sliding) {
        let point = &mut values[row..row + law.rows()];
        let coefficient = if sliding {
            law.kinetic_coefficient
        } else {
            law.static_coefficient
        };
        let normal = point[0].max(0.0);
        project_disk(&mut point[1..3], coefficient * normal);
        if let Some(length) = law.rolling_length {
            project_disk(&mut point[3..5], length * normal);
        }
        row += law.rows();
    }
}

fn project_disk(pair: &mut [f64], radius: f64) {
    let length = pair[0].hypot(pair[1]);
    if length > radius {
        pair[0] *= radius / length;
        pair[1] *= radius / length;
    }
}

// Deterministic complete diagonal pivoting for a positive-semidefinite block.
// Dependent rows are retained and checked for consistency, never regularized.
fn rank_solve(matrix: &[f64], rhs: &[f64], tolerance: f64) -> Result<Vec<f64>, PhysicsError> {
    let n = rhs.len();
    if n == 1 {
        if matrix[0] > 0.0 {
            return Ok(vec![rhs[0] / matrix[0]]);
        }
        if rhs[0].abs() <= tolerance {
            return Ok(vec![0.0]);
        }
        return Err(PhysicsError::InconsistentConstraints);
    }
    let mut a = matrix.to_vec();
    let mut b = rhs.to_vec();
    let mut permutation = (0..n).collect::<Vec<_>>();
    let scale = (0..n).map(|i| a[i * n + i].abs()).fold(0.0, f64::max);
    let mut rank = n;
    for k in 0..n {
        let mut pivot = k;
        for i in k + 1..n {
            if a[i * n + i] > a[pivot * n + pivot] {
                pivot = i;
            }
        }
        if a[pivot * n + pivot] <= scale * 1e-12 {
            rank = k;
            if b[k..].iter().any(|x| x.abs() > tolerance) {
                return Err(PhysicsError::InconsistentConstraints);
            }
            break;
        }
        for j in 0..n {
            a.swap(k * n + j, pivot * n + j);
        }
        for i in 0..n {
            a.swap(i * n + k, i * n + pivot);
        }
        b.swap(k, pivot);
        permutation.swap(k, pivot);
        for i in k + 1..n {
            let multiplier = a[i * n + k] / a[k * n + k];
            for j in k + 1..n {
                a[i * n + j] -= multiplier * a[k * n + j];
            }
            b[i] -= multiplier * b[k];
            a[i * n + k] = 0.0;
        }
    }
    let mut solution = vec![0.0; n];
    for i in (0..rank).rev() {
        solution[i] = (b[i]
            - (i + 1..rank)
                .map(|j| a[i * n + j] * solution[j])
                .sum::<f64>())
            / a[i * n + i];
    }
    let mut output = vec![0.0; n];
    for i in 0..n {
        output[permutation[i]] = solution[i];
    }
    Ok(output)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn bilateral(jacobian: Vec<Vec<f64>>, target: Vec<f64>) -> ConstraintBlock {
        ConstraintBlock {
            bounds: vec![
                ImpulseBounds {
                    minimum: f64::NEG_INFINITY,
                    maximum: f64::INFINITY
                };
                target.len()
            ],
            jacobian,
            target,
            contacts: Vec::new(),
        }
    }

    #[test]
    fn impulse_at_light_wheel_accelerates_the_coupled_chassis() {
        // x is chassis translation; q is wheel displacement relative to chassis.
        let factor = DynamicsFactor::new(&[101.0, 1.0, 1.0, 1.0], 2).unwrap();
        let blocks = [bilateral(
            vec![vec![1.0, 1.0], vec![0.0, 1.0]],
            vec![1.0, 0.0],
        )];
        let result = solve_constraints(&factor, &blocks, 8, 1e-10).unwrap();
        assert!(result.converged);
        assert!((result.velocity_change[0] - 1.0).abs() < 1e-10);
        assert!(result.velocity_change[1].abs() < 1e-10);
        assert!((result.impulses[0] - 101.0).abs() < 1e-9);
    }

    #[test]
    fn duplicate_loop_rows_preserve_response_and_inconsistent_rows_fail() {
        let factor = DynamicsFactor::new(&[2.0], 1).unwrap();
        let mut block = bilateral(vec![vec![1.0], vec![1.0]], vec![3.0, 3.0]);
        let result = solve_constraints(&factor, &[block.clone()], 8, 1e-10).unwrap();
        assert_eq!(result.velocity_change, [3.0]);
        block.target[1] = 4.0;
        assert_eq!(
            solve_constraints(&factor, &[block], 8, 1e-10).unwrap_err(),
            PhysicsError::InconsistentConstraints
        );
    }

    #[test]
    fn unilateral_support_cannot_pull_a_separating_body() {
        let factor = DynamicsFactor::new(&[2.0], 1).unwrap();
        let mut block = bilateral(vec![vec![1.0]], vec![-1.0]);
        block.bounds[0].minimum = 0.0;
        let result = solve_constraints(&factor, &[block], 8, 1e-10).unwrap();
        assert!(result.converged);
        assert_eq!(result.velocity_change, [0.0]);
    }

    #[test]
    fn nearly_coincident_supports_transfer_load_to_the_outer_contact() {
        let factor = identity_factor(2);
        // Incoming [vertical, angular] velocity is [-1, -2]. Only the outer
        // point remains in contact: impulse 1.5 leaves velocity [0.5, -0.5].
        // The other normal rows are dependent and must shed their initial load.
        for count in [3, 129] {
            let blocks = (0..count)
                .map(|index| {
                    let x = if index == count - 1 { 1.0 } else { 0.999 };
                    let mut block = bilateral(vec![vec![1.0, x]], vec![1.0 + 2.0 * x]);
                    block.bounds[0].minimum = 0.0;
                    block
                })
                .collect::<Vec<_>>();
            let result = solve_constraints(&factor, &blocks, 256, 1e-10).unwrap();
            assert!(
                result.converged,
                "rows={count} residual={}",
                result.residual
            );
            assert!((result.impulses[count - 1] - 1.5).abs() < 1e-9);
            assert!(
                result.impulses[..count - 1]
                    .iter()
                    .all(|value| value.abs() < 1e-9)
            );
            assert!((result.velocity_change[0] - 1.5).abs() < 1e-9);
            assert!((result.velocity_change[1] - 1.5).abs() < 1e-9);
            if count > DENSE_CONTACT_ROWS {
                assert_eq!(result.response_storage, 0);
            }
        }
    }

    #[test]
    fn warm_impulses_reuse_an_implicit_response_and_are_revalidated_for_new_targets() {
        let factor = identity_factor(2);
        let blocks = (0..129)
            .map(|index| {
                let x = if index == 128 { 1.0 } else { 0.999 };
                let mut block = bilateral(vec![vec![1.0, x]], vec![1.0 + 2.0 * x]);
                block.bounds[0].minimum = 0.0;
                block
            })
            .collect::<Vec<_>>();
        let targets = blocks
            .iter()
            .flat_map(|block| block.target.iter().copied())
            .collect::<Vec<_>>();
        let mut prepared = PreparedConstraints::new(&factor, &blocks).unwrap();
        let cold = prepared.solve(&targets, 256, 1e-9).unwrap();
        assert!(cold.converged);
        let warm = prepared
            .solve_from(&targets, Some(&cold.impulses), 1, 1e-9)
            .unwrap();
        assert!(warm.converged);
        assert_eq!(warm.iterations, 1);
        assert!(warm.factor_solves < cold.factor_solves);
        assert_eq!(warm.response_storage, 0);
        let changed = targets
            .iter()
            .map(|target| target * 1.01)
            .collect::<Vec<_>>();
        let changed_warm = prepared
            .solve_from(&changed, Some(&warm.impulses), 256, 1e-9)
            .unwrap();
        assert!(changed_warm.converged);
        assert!((changed_warm.impulses[128] - 1.515).abs() < 1e-8);
        assert_eq!(prepared.preparation_factor_solves(), 129);
        for invalid in [vec![0.0], vec![f64::NAN; 129]] {
            assert!(matches!(
                prepared.solve_from(&targets, Some(&invalid), 256, 1e-9),
                Err(PhysicsError::InvalidConstraints)
            ));
        }
    }

    #[test]
    fn coupling_to_a_clamped_contact_cannot_falsely_converge() {
        // W = [[2, 1], [1, 2]]. Clipping W^-1 * [-1, 1] gives [0, 1],
        // which leaves a nonzero residual on the active second contact.
        let factor =
            DynamicsFactor::new(&[2.0 / 3.0, -1.0 / 3.0, -1.0 / 3.0, 2.0 / 3.0], 2).unwrap();
        let mut block = bilateral(vec![vec![1.0, 0.0], vec![0.0, 1.0]], vec![-1.0, 1.0]);
        for bounds in &mut block.bounds {
            bounds.minimum = 0.0;
        }
        let result = solve_constraints(&factor, &[block], 128, 1e-10).unwrap();
        assert!(result.converged);
        assert!(result.impulses[0].abs() < 1e-10);
        assert!((result.impulses[1] - 0.5).abs() < 1e-10);
        assert!((result.velocity_change[1] - 1.0).abs() < 1e-10);
    }

    #[test]
    fn friction_impulse_obeys_the_circular_coulomb_bound() {
        let factor =
            DynamicsFactor::new(&[1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0], 3).unwrap();
        let mut block = bilateral(
            vec![
                vec![1.0, 0.0, 0.0],
                vec![0.0, 1.0, 0.0],
                vec![0.0, 0.0, 1.0],
            ],
            vec![2.0, 3.0, 4.0],
        );
        block.contacts = vec![ContactFriction {
            static_coefficient: 0.5,
            kinetic_coefficient: 0.5,
            sliding: false,
            rolling_length: None,
        }];
        block.bounds[0].minimum = 0.0;
        let result = solve_constraints(&factor, &[block], 8, 1e-10).unwrap();
        assert!(result.converged);
        assert!((result.impulses[1].hypot(result.impulses[2]) - 1.0).abs() < 1e-12);
    }

    #[test]
    fn contradictory_friction_bounds_are_rejected_before_projection() {
        let factor = DynamicsFactor::new(&[1.0], 1).unwrap();
        let mut block = bilateral(vec![vec![1.0]; 3], vec![0.0; 3]);
        block.contacts = vec![ContactFriction {
            static_coefficient: 0.5,
            kinetic_coefficient: 0.5,
            sliding: false,
            rolling_length: None,
        }];
        block.bounds[0] = ImpulseBounds {
            minimum: -1.0,
            maximum: -1.0,
        };
        assert_eq!(
            solve_constraints(&factor, &[block], 8, 1e-10).unwrap_err(),
            PhysicsError::InvalidConstraints
        );
    }

    fn contact_block(
        target: Vec<f64>,
        sliding: bool,
        rolling_length: Option<f64>,
    ) -> ConstraintBlock {
        let size = target.len();
        let mut block = bilateral(
            (0..size)
                .map(|row| {
                    let mut values = vec![0.0; size];
                    values[row] = 1.0;
                    values
                })
                .collect(),
            target,
        );
        block.bounds[0].minimum = 0.0;
        block.contacts = vec![ContactFriction {
            static_coefficient: 0.8,
            kinetic_coefficient: 0.5,
            sliding,
            rolling_length,
        }];
        block
    }

    fn identity_factor(size: usize) -> DynamicsFactor {
        let mut matrix = vec![0.0; size * size];
        for row in 0..size {
            matrix[row * size + row] = 1.0;
        }
        DynamicsFactor::new(&matrix, size).unwrap()
    }

    #[test]
    fn static_support_and_initial_sliding_use_distinct_physical_friction_limits() {
        let factor = identity_factor(3);
        let held = solve_constraints(
            &factor,
            &[contact_block(vec![1.0, 0.6, 0.0], false, None)],
            16,
            1e-12,
        )
        .unwrap();
        assert!(held.converged);
        assert!((held.impulses[1] - 0.6).abs() < 1e-12);
        assert_eq!(held.sliding, [false]);
        assert_eq!(held.friction_transitions, 0);
        let moving = solve_constraints(
            &factor,
            &[contact_block(vec![1.0, 0.6, 0.0], true, None)],
            16,
            1e-12,
        )
        .unwrap();
        assert!(moving.converged);
        assert!((moving.impulses[1] - 0.5).abs() < 1e-12);
        assert_eq!(moving.sliding, [true]);
        // Free tangential speed was -0.6; kinetic friction leaves -0.1.
        assert!((moving.velocity_change[1] - 0.6 + 0.1).abs() < 1e-12);
    }

    #[test]
    fn large_generalized_systems_keep_dense_and_krylov_storage_bounded() {
        let size = 65;
        let mut mass = vec![0.0; size * size];
        for row in 0..size {
            mass[row * size + row] = 1.0;
        }
        mass[1] = -0.9;
        mass[size] = -0.9;
        let factor = DynamicsFactor::new(&mass, size).unwrap();
        let mut expected = vec![0.0; size];
        expected[0] = 1.0;
        expected[1] = 0.6;
        factor.solve(&mut expected).unwrap();
        let mut block = contact_block(expected[..3].to_vec(), false, None);
        for row in &mut block.jacobian {
            row.resize(size, 0.0);
        }
        for copies in [1, 43] {
            let solution =
                solve_constraints(&factor, &vec![block.clone(); copies], 256, 1e-10).unwrap();
            assert!(solution.converged);
            if copies == 1 {
                assert!(solution.newton_contact_factorizations > 0);
                assert_eq!(solution.newton_contact_storage, 9);
                assert_eq!(solution.newton_applications, 0);
            } else {
                assert!(solution.newton_applications > 0);
                assert_eq!(solution.newton_contact_storage, 0);
                assert_eq!(solution.response_storage, 0);
            }
            assert_eq!(solution.newton_generalized_factorizations, 0);
            assert_eq!(solution.newton_reduced_storage, 0);
            for (actual, expected) in solution.velocity_change.iter().zip(&expected) {
                assert!((actual - expected).abs() < 1e-9);
            }
        }
    }

    #[test]
    fn static_breakaway_reuses_response_and_cannot_pass_an_exhausted_solve() {
        let factor = identity_factor(3);
        let block = contact_block(vec![1.0, 1.0, 0.0], false, None);
        let mut prepared = PreparedConstraints::new(&factor, &[block]).unwrap();
        assert_eq!(prepared.preparation_factor_solves(), 3);
        let limited = prepared.solve(&[1.0, 1.0, 0.0], 1, 1e-12).unwrap();
        assert!(!limited.converged);
        assert_eq!(limited.friction_transitions, 1);
        let broken_away = prepared.solve(&[1.0, 1.0, 0.0], 16, 1e-12).unwrap();
        assert!(broken_away.converged);
        assert_eq!(broken_away.sliding, [true]);
        assert_eq!(broken_away.friction_transitions, 1);
        assert_eq!(
            broken_away.factor_solves, 1,
            "switching cones must reuse prepared W"
        );
        assert!((broken_away.impulses[1] - 0.5).abs() < 1e-12);
    }

    #[test]
    fn coupled_normal_iterations_do_not_falsely_trigger_static_breakaway() {
        let factor =
            DynamicsFactor::new(&[1.0, -0.9, 0.0, -0.9, 1.0, 0.0, 0.0, 0.0, 1.0], 3).unwrap();
        // W is H^-1. The prescribed static solution is [1, 0.6, 0].
        let mut target = vec![1.0, 0.6, 0.0];
        factor.solve(&mut target).unwrap();
        let solution =
            solve_constraints(&factor, &[contact_block(target, false, None)], 1024, 1e-10).unwrap();
        assert!(solution.converged, "{}", solution.residual);
        assert_eq!(solution.friction_transitions, 0);
        assert_eq!(solution.sliding, [false]);
        assert!((solution.impulses[1] - 0.6).abs() < 1e-8);
    }

    #[test]
    fn rolling_resistance_obeys_the_normal_load_radius_bound_and_dissipates_spin() {
        let factor = identity_factor(5);
        let solution = solve_constraints(
            &factor,
            &[contact_block(
                vec![2.0, 0.1, 0.0, 3.0, 4.0],
                false,
                Some(0.1),
            )],
            16,
            1e-12,
        )
        .unwrap();
        assert!(solution.converged);
        assert!((solution.impulses[3] - 0.12).abs() < 1e-12);
        assert!((solution.impulses[4] - 0.16).abs() < 1e-12);
        assert!((solution.impulses[3].hypot(solution.impulses[4]) - 0.2).abs() < 1e-12);
        let remaining =
            (-3.0 + solution.velocity_change[3]).hypot(-4.0 + solution.velocity_change[4]);
        assert!((remaining - 4.8).abs() < 1e-12);
    }

    #[test]
    fn large_contact_sets_use_implicit_response_and_repeat_exactly() {
        let factor = DynamicsFactor::new(&[2.0], 1).unwrap();
        for count in [128, 129] {
            let blocks = vec![bilateral(vec![vec![1.0]], vec![1.0]); count];
            let a = solve_constraints(&factor, &blocks, 8, 1e-10).unwrap();
            let b = solve_constraints(&factor, &blocks, 8, 1e-10).unwrap();
            assert!(a.converged);
            if count <= 128 {
                assert_eq!(a.factor_solves, count + 1);
            }
            assert_eq!(
                a.response_storage,
                if count <= 128 { count * count } else { 0 }
            );
            assert_eq!(a.velocity_change, b.velocity_change);
            assert_eq!(a.impulses, b.impulses);
            assert!((a.velocity_change[0] - 1.0).abs() < 1e-12);
        }
    }
}
