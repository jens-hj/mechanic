use super::*;

#[test]
fn shallow_first_impact_is_held_even_when_its_depth_envelope_passes() {
    let (creation, geometry, _) = cube();
    let mut initial = MachineState::at_rest(&creation);
    initial.poses[0].position.y = 0.5001;
    initial.velocities[1] = -0.012;
    let scene = scene();
    let terrain = context(&scene, &geometry, 7);
    let displacement = initial
        .velocities
        .iter()
        .map(|v| v * TICK_SECONDS)
        .collect::<Vec<_>>();
    let motion = crate::MachineMotion::new(&creation, 7, &initial, &displacement).unwrap();
    assert_eq!(
        scene
            .validate_penetration(&geometry, &motion, DVec3::ZERO, 0.002, 128)
            .unwrap()
            .outcome,
        crate::TerrainPathOutcome::Bounded
    );
    let mut world = CpuJointMachine::new(creation, 7, initial).unwrap();
    let before = world.snapshot().clone();
    assert_eq!(
        world.step_candidate(
            DVec3::ZERO,
            JointTickSettings::default(),
            &[],
            &[],
            Some(&terrain)
        ),
        Err(PhysicsError::NotConverged)
    );
    assert_eq!(world.snapshot(), &before);
    assert_eq!(world.diagnostics().terrain_impact_holds, 4);
    assert_eq!(world.diagnostics().attempts, 4);
    assert!(!world.diagnostics().published);
}

#[test]
fn existing_floor_support_does_not_hide_a_new_finite_wall_impact() {
    use mechanic_world::{TerrainTriangleGroupMask, TriangleBvhTriangle};
    let (creation, geometry, poses) = cube();
    let mut initial = MachineState {
        poses,
        ..MachineState::at_rest(&creation)
    };
    initial.velocities[0] = 0.012;
    let mut chunk = terrain([TerrainMaterial::Rock; 2]);
    let changed = std::sync::Arc::make_mut(&mut chunk);
    changed
        .vertices
        .extend([[0.5001, 0.0, -1.0], [0.5001, 0.0, 1.0], [0.5001, 1.0, 0.0]]);
    changed.indices.extend([6, 7, 8]);
    changed
        .material_weights
        .extend([changed.material_weights[0]; 3]);
    changed.bounds.maximum.0.y = 1.0;
    changed.triangle_bvh.bounds = changed.bounds;
    changed.triangle_bvh.nodes[0].bounds = changed.bounds;
    changed.triangle_bvh.nodes[0].triangle_count = 3;
    changed.triangle_bvh.triangles.push(TriangleBvhTriangle {
        indices: [6, 7, 8],
        group_mask: TerrainTriangleGroupMask::REGULAR,
    });
    let mut scene = TerrainContactScene::default();
    scene.publish(1, &[chunk], &[]).unwrap();
    let terrain = context(&scene, &geometry, 7);
    let contacts = scene
        .contacts(&geometry, &initial.poses, DVec3::ZERO)
        .unwrap();
    assert!(
        contacts
            .contacts
            .iter()
            .all(|point| point.feature.triangle < 2)
    );
    assert!(!contacts.contacts.is_empty());
    let displacement = initial
        .velocities
        .iter()
        .map(|v| v * TICK_SECONDS)
        .collect::<Vec<_>>();
    let motion = crate::MachineMotion::new(&creation, 7, &initial, &displacement).unwrap();
    assert_eq!(
        scene
            .validate_penetration(&geometry, &motion, DVec3::ZERO, 0.002, 128)
            .unwrap()
            .outcome,
        crate::TerrainPathOutcome::Bounded
    );
    let sweep = scene
        .sweep_new_contacts(&geometry, &motion, DVec3::ZERO, 1e-12, 128)
        .unwrap();
    let crate::TerrainSweepOutcome::Impact(hit) = sweep.outcome else {
        panic!("{:?}", sweep.outcome)
    };
    assert_eq!(hit.triangle, 2);
    assert_eq!(sweep.supported_pairs, 2);
    let mut world = CpuJointMachine::new(creation, 7, initial).unwrap();
    let before = world.snapshot().clone();
    assert_eq!(
        world.step_candidate(
            DVec3::ZERO,
            JointTickSettings::default(),
            &[],
            &[],
            Some(&terrain)
        ),
        Err(PhysicsError::NotConverged)
    );
    assert_eq!(world.snapshot(), &before);
    assert_eq!(world.diagnostics().terrain_impact_holds, 4);
}
